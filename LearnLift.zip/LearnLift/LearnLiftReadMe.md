# LearnLift

**Lifting education beyond limitations with offline-first learning.**

LearnLift is an offline-first education platform designed to support students in underserved or low-connectivity environments. It allows learners to download lessons, study offline, take quizzes without internet access, and sync progress when connectivity is restored.

---

## 🌍 Problem
Many digital learning platforms assume constant internet access, leaving students in low-resource communities behind. This digital divide limits learning continuity and academic progress.

---

## 💡 Solution
LearnLift provides:
- Offline access to learning materials
- Downloadable lessons and quizzes
- Automatic data syncing when internet returns
- A lightweight, low-bandwidth-friendly experience

---

## 🚀 Features
### Student
- Offline lesson access
- Downloadable learning materials
- Offline quizzes with auto-sync
- Study planner

### Admin / Educator
- Upload and manage lessons
- Create quizzes
- Monitor student progress

---

## 🧰 Tech Stack
- HTML5
- CSS3
- JavaScript (Vanilla)
- PHP (PDO)
- MySQL
- Service Workers & IndexedDB (Offline Support)

---

## 🔐 Security
- PDO prepared statements
- Password hashing
- CSRF protection
- Input validation
- Role-based access control

---

## 🖥️ Setup Instructions
1. Clone the repository
2. Move the project to your XAMPP `htdocs` folder
3. Import `database/learnlift.sql` into MySQL
4. Update database credentials in `includes/db.php`
5. Start Apache & MySQL
6. Visit `localhost/learnlift`

---

## 📽️ Demo
Demo video link will be added.

---

## 📌 Hackathon
Built for **Aethra Global Hackathon 2025**  
Theme: **Tech for Change**