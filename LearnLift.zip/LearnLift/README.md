# LearnLift - Offline-First Education Platform

LearnLift is a production-ready web platform designed to help students in low-internet or underserved environments access learning materials, study offline, take quizzes, and sync progress when internet is available.

## 🌟 Features

### For Students

- 📚 **Offline Learning**: Download lessons and access them without internet
- ✅ **Offline Quizzes**: Take quizzes offline and auto-sync results
- 📅 **Study Planner**: Organize daily study tasks
- 🔄 **Auto Sync**: Automatic synchronization when connection is restored
- 📊 **Progress Tracking**: View quiz results and learning progress

### For Educators

- 📝 **Lesson Management**: Upload and manage learning materials (PDF, text, video)
- 🎯 **Quiz Creation**: Create quizzes with multiple-choice questions
- 📈 **Student Progress**: View student quiz results and engagement
- 🔐 **Content Control**: Publish/unpublish lessons

### For Admins

- 👥 **User Management**: Manage students, educators, and admins
- 📊 **System Analytics**: Platform-wide statistics and metrics
- 🛡️ **Content Moderation**: Oversee all lessons and quizzes
- ⚙️ **System Control**: Full platform administration

## 🛠️ Technology Stack

- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **Backend**: PHP 7.4+ with PDO
- **Database**: MySQL 5.7+
- **Offline**: Service Workers, IndexedDB
- **Server**: Apache (XAMPP)

## 📋 Prerequisites

- XAMPP (or similar LAMP/WAMP stack)
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Modern web browser (Chrome, Firefox, Edge)

## 🚀 Installation

### Step 1: Clone/Download

Place the LearnLift folder in your `htdocs` directory:

```
C:\xampp\htdocs\LearnLift\
```

### Step 2: Database Setup

1. Start XAMPP and ensure Apache and MySQL are running
2. Open phpMyAdmin: `http://localhost/phpmyadmin`
3. Import the database schema:
   - Click "Import" tab
   - Choose file: `database/schema.sql`
   - Click "Go"
4. Import demo data (optional):
   - Choose file: `database/demo_data.sql`
   - Click "Go"

**OR** use command line:

```bash
mysql -u root -p < database/schema.sql
mysql -u root -p < database/demo_data.sql
```

### Step 3: Configuration

The default database configuration is:

- **Host**: localhost
- **Database**: learnlift
- **Username**: root
- **Password**: (empty)

To change these, edit `config/database.php`

### Step 4: File Permissions

Ensure the uploads directory is writable:

```
LearnLift/assets/uploads/
```

### Step 5: Access the Platform

Open your browser and navigate to:

```
http://localhost/LearnLift
```

## 👤 Demo Accounts

After importing demo data, you can login with:

### Admin Account

- **Email**: admin@learnlift.com
- **Password**: password123

### Educator Account

- **Email**: educator@learnlift.com
- **Password**: password123

### Student Account

- **Email**: student@learnlift.com
- **Password**: password123

## 📁 Project Structure

```
LearnLift/
├── api/                    # Backend API endpoints
│   ├── auth.php
│   ├── lessons.php
│   ├── quizzes.php
│   ├── planner.php
│   └── sync.php
├── admin/                  # Admin dashboard
│   ├── dashboard.php
│   ├── users.php
│   ├── lessons.php
│   ├── quizzes.php
│   └── analytics.php
├── educator/               # Educator dashboard
│   ├── dashboard.php
│   ├── lessons.php
│   ├── quizzes.php
│   └── students.php
├── student/                # Student dashboard
│   ├── dashboard.php
│   ├── lessons.php
│   ├── quiz.php
│   └── planner.php
├── assets/                 # Frontend assets
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   ├── main.js
│   │   ├── offline.js
│   │   └── sync.js
│   └── uploads/           # User-uploaded files
├── config/                 # Configuration
│   └── database.php
├── database/              # Database files
│   ├── schema.sql
│   └── demo_data.sql
├── includes/              # PHP includes
│   ├── functions.php
│   └── auth.php
├── index.php              # Landing page
├── auth.php               # Login/Register
├── sw.js                  # Service Worker
├── offline.html           # Offline fallback
└── README.md
```

## 🔒 Security Features

- ✅ Password hashing with `password_hash()`
- ✅ CSRF token protection on all forms
- ✅ Prepared statements (no raw SQL)
- ✅ Input validation and sanitization
- ✅ Session-based authentication
- ✅ Role-based access control
- ✅ XSS protection

## 📱 Offline Functionality

### How It Works

1. **Service Worker**: Caches static assets and pages
2. **IndexedDB**: Stores quiz answers, study plans, and downloaded lessons
3. **Auto Sync**: Detects internet reconnection and syncs offline data
4. **Background Sync**: Uses Background Sync API when available

### Testing Offline Mode

1. Open Chrome DevTools (F12)
2. Go to Application → Service Workers
3. Verify Service Worker is registered
4. Go to Network tab
5. Check "Offline" checkbox
6. Navigate the site and take quizzes
7. Uncheck "Offline" to go back online
8. Data will automatically sync

## 🎯 Usage Guide

### For Students

1. **Register**: Create account as "Student"
2. **Browse Lessons**: View available lessons
3. **Download**: Click download button to save for offline
4. **Study Offline**: Access downloaded lessons anytime
5. **Take Quizzes**: Complete quizzes online or offline
6. **Plan Studies**: Use study planner to organize tasks

### For Educators

1. **Register**: Create account as "Educator"
2. **Upload Lessons**: Add learning materials
3. **Create Quizzes**: Design quizzes with questions
4. **Publish Content**: Make lessons available to students
5. **Track Progress**: View student quiz results

### For Admins

1. **Login**: Use admin credentials
2. **Manage Users**: Add/edit/deactivate users
3. **Moderate Content**: Review and manage all lessons
4. **View Analytics**: Monitor platform usage

## 🐛 Troubleshooting

### Database Connection Error

- Ensure MySQL is running in XAMPP
- Check database credentials in `config/database.php`
- Verify database `learnlift` exists

### Service Worker Not Registering

- Service Workers require HTTPS in production (localhost works for development)
- Clear browser cache and reload
- Check browser console for errors

### File Upload Fails

- Check PHP upload limits in `php.ini`:
  ```
  upload_max_filesize = 50M
  post_max_size = 50M
  ```
- Ensure `assets/uploads/` directory exists and is writable

### Offline Sync Not Working

- Check browser console for errors
- Verify IndexedDB is supported
- Ensure you're online when testing sync

## 📊 Browser Support

- ✅ Chrome 67+
- ✅ Firefox 61+
- ✅ Edge 79+
- ✅ Safari 11.1+
- ❌ Internet Explorer (not supported)

## 🔄 Future Enhancements

- Push notifications for new lessons
- Video streaming with offline caching
- Peer-to-peer lesson sharing
- Mobile app (PWA)
- Multi-language support
- Advanced analytics dashboard

## 📝 License

This project is open-source and available for educational purposes.

## 🤝 Contributing

This is a hackathon MVP. Contributions and improvements are welcome!

## 📧 Support

For issues or questions, please check the troubleshooting section or review the code comments.

## 🎓 Credits

Built with ❤️ for students in underserved communities.

---

**LearnLift** - Empowering education for all, everywhere.
