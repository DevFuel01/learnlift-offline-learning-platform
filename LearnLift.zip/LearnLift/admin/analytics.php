<?php

/**
 * Admin Analytics Dashboard
 * LearnLift - Offline-First Education Platform
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireAdmin();

// Platform Overview
try {
    // User Stats
    $stmt = $pdo->query("SELECT role, COUNT(*) as count FROM users GROUP BY role");
    $userStats = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

    // Content Stats
    $totalLessons = $pdo->query("SELECT COUNT(*) FROM lessons")->fetchColumn();
    $totalQuizzes = $pdo->query("SELECT COUNT(*) FROM quizzes")->fetchColumn();
    $totalQuestions = $pdo->query("SELECT COUNT(*) FROM quiz_questions")->fetchColumn();

    // Engagement Stats
    $totalDownloads = $pdo->query("SELECT COUNT(*) FROM downloaded_lessons")->fetchColumn();
    $totalAttempts = $pdo->query("SELECT COUNT(*) FROM quiz_results")->fetchColumn();
    $avgScore = $pdo->query("SELECT AVG(percentage) FROM quiz_results")->fetchColumn();
    $offlineSyncs = $pdo->query("SELECT COUNT(*) FROM quiz_results WHERE synced_from_offline = 1")->fetchColumn();

    // Top Educators
    $stmt = $pdo->query("
        SELECT u.name, COUNT(l.id) as lesson_count, 
               (SELECT COUNT(*) FROM quizzes q WHERE q.educator_id = u.id) as quiz_count,
               (SELECT COUNT(*) FROM quiz_results qr 
                JOIN quizzes q ON qr.quiz_id = q.id 
                WHERE q.educator_id = u.id) as total_interactions
        FROM users u 
        JOIN lessons l ON u.id = l.educator_id 
        WHERE u.role = 'educator' 
        GROUP BY u.id 
        ORDER BY total_interactions DESC 
        LIMIT 5
    ");
    $topEducators = $stmt->fetchAll();

    // Top Students
    $stmt = $pdo->query("
        SELECT u.name, COUNT(qr.id) as quizzes_taken, AVG(qr.percentage) as avg_score
        FROM users u
        JOIN quiz_results qr ON u.id = qr.student_id
        WHERE u.role = 'student'
        GROUP BY u.id
        ORDER BY quizzes_taken DESC
        LIMIT 5
    ");
    $topStudents = $stmt->fetchAll();

    // Daily Activity (Last 7 Days)
    $stmt = $pdo->query("
        SELECT DATE(submitted_at) as date, COUNT(*) as count 
        FROM quiz_results 
        WHERE submitted_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
        GROUP BY DATE(submitted_at)
        ORDER BY date ASC
    ");
    $dailyActivity = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
} catch (PDOException $e) {
    error_log("Analytics error: " . $e->getMessage());
    $error = "Failed to load analytics data";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics - LearnLift</title>
    <link rel="stylesheet" href="/LearnLift/assets/css/style.css">
    <style>
        .metric-card {
            background: var(--white);
            padding: var(--spacing-lg);
            border-radius: var(--radius-md);
            box-shadow: var(--shadow-sm);
            margin-bottom: var(--spacing-md);
            border-left: 4px solid var(--primary);
        }

        .metric-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--text-dark);
            margin-bottom: var(--spacing-xs);
        }

        .metric-label {
            color: var(--gray);
            font-size: 0.875rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .chart-bar {
            background: var(--gray-lighter);
            height: 24px;
            border-radius: var(--radius-sm);
            overflow: hidden;
            margin-bottom: var(--spacing-xs);
            position: relative;
        }

        .chart-fill {
            height: 100%;
            background: var(--gradient-primary);
            display: flex;
            align-items: center;
            padding-left: var(--spacing-sm);
            color: var(--white);
            font-size: 0.75rem;
            min-width: 30px;
        }

        .section-title {
            margin-top: var(--spacing-xl);
            margin-bottom: var(--spacing-md);
            border-bottom: 2px solid var(--gray-lighter);
            padding-bottom: var(--spacing-sm);
        }
    </style>
</head>

<body>
    <nav class="navbar">
        <div class="container navbar-container">
            <a href="/LearnLift/" class="navbar-brand">LearnLift</a>
            <button class="navbar-toggle" aria-label="Toggle navigation">☰</button>
            <ul class="navbar-menu">
                <li><a href="/LearnLift/admin/dashboard.php">Dashboard</a></li>
                <li><a href="/LearnLift/admin/users.php">Users</a></li>
                <li><a href="/LearnLift/admin/lessons.php">Lessons</a></li>
                <li><a href="/LearnLift/admin/quizzes.php">Quizzes</a></li>
                <li><a href="/LearnLift/admin/analytics.php" class="active">Analytics</a></li>
                <li><a href="/LearnLift/profile.php">Profile</a></li>
                <li><span id="online-status" class="status-indicator"></span></li>
                <li><button class="btn btn-sm btn-outline theme-toggle" title="Toggle Dark Mode" style="margin-right: 10px;">🌙</button></li>
                <li><a href="/LearnLift/api/auth.php?action=logout">Logout</a></li>
            </ul>
        </div>
    </nav>

    <div class="container" style="margin-top: var(--spacing-xl);">
        <h1>Platform Analytics</h1>
        <p class="mb-4">Comprehensive usage statistics and performance metrics.</p>

        <!-- Platform Usage -->
        <h2 class="section-title">Platform Overview</h2>
        <div class="row">
            <div class="col-3">
                <div class="metric-card" style="border-color: var(--primary);">
                    <div class="metric-value"><?php echo array_sum($userStats); ?></div>
                    <div class="metric-label">Total Users</div>
                </div>
            </div>
            <div class="col-3">
                <div class="metric-card" style="border-color: var(--secondary);">
                    <div class="metric-value"><?php echo $totalLessons; ?></div>
                    <div class="metric-label">Total Lessons</div>
                </div>
            </div>
            <div class="col-3">
                <div class="metric-card" style="border-color: var(--success);">
                    <div class="metric-value"><?php echo $totalQuizzes; ?></div>
                    <div class="metric-label">Total Quizzes</div>
                </div>
            </div>
            <div class="col-3">
                <div class="metric-card" style="border-color: var(--warning);">
                    <div class="metric-value"><?php echo $totalDownloads; ?></div>
                    <div class="metric-label">Offline Downloads</div>
                </div>
            </div>
        </div>

        <!-- Student Engagement -->
        <h2 class="section-title">Student Engagement</h2>
        <div class="row">
            <div class="col-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Engagement Metrics</h3>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label>Total Quiz Attempts</label>
                            <div class="progress-bar-container">
                                <strong><?php echo $totalAttempts; ?></strong> attempts across all students
                            </div>
                        </div>
                        <div class="mb-3">
                            <label>Average Score</label>
                            <div class="chart-bar">
                                <div class="chart-fill" style="width: <?php echo $avgScore; ?>%;">
                                    <?php echo round($avgScore, 1); ?>%
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label>Offline Activity</label>
                            <p style="color: var(--gray);">
                                <strong><?php echo $offlineSyncs; ?></strong> quiz results synced from offline mode
                                (<?php echo $totalAttempts > 0 ? round(($offlineSyncs / $totalAttempts) * 100, 1) : 0; ?>% of total)
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Top Performing Students</h3>
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Student</th>
                                    <th>Quizzes</th>
                                    <th>Avg Score</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($topStudents as $student): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($student['name']); ?></td>
                                        <td><?php echo $student['quizzes_taken']; ?></td>
                                        <td>
                                            <span class="badge <?php echo $student['avg_score'] >= 70 ? 'badge-success' : 'badge-warning'; ?>">
                                                <?php echo round($student['avg_score'], 1); ?>%
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Educator Performance -->
        <h2 class="section-title">Educator Performance</h2>
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Top Educators (by Student Interaction)</h3>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Educator</th>
                            <th>Lessons Created</th>
                            <th>Quizzes Created</th>
                            <th>Total Student Interactions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($topEducators as $educator): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($educator['name']); ?></strong></td>
                                <td><?php echo $educator['lesson_count']; ?></td>
                                <td><?php echo $educator['quiz_count']; ?></td>
                                <td>
                                    <?php echo $educator['total_interactions']; ?>
                                    <small style="color: var(--gray);">(quiz attempts)</small>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Quiz Submissions (Last 7 Days) -->
        <h2 class="section-title">Activity (Last 7 Days)</h2>
        <div class="card">
            <div class="card-body">
                <?php
                if (empty($dailyActivity)) {
                    echo "<p class='text-center mt-3 mb-3'>No activity in the last 7 days.</p>";
                } else {
                    $maxCount = max($dailyActivity);
                    foreach ($dailyActivity as $date => $count) {
                        $width = ($count / $maxCount) * 100;
                        echo "<div style='display: flex; align-items: center; margin-bottom: 8px;'>";
                        echo "<div style='width: 100px; font-size: 0.875rem; color: var(--gray);'>" . date('M j', strtotime($date)) . "</div>";
                        echo "<div class='chart-bar' style='flex: 1; margin: 0;'>";
                        echo "<div class='chart-fill' style='width: {$width}%;'>{$count}</div>";
                        echo "</div>";
                        echo "</div>";
                    }
                }
                ?>
            </div>
        </div>
    </div>

    <script src="/LearnLift/assets/js/main.js"></script>
    <script src="/LearnLift/assets/js/main.js"></script>
</body>

</html>