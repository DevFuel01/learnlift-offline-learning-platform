<?php

/**
 * Admin Dashboard
 * LearnLift - Offline-First Education Platform
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireAdmin();

$userName = getCurrentUserName();

// Get system statistics
try {
    // User counts
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM users WHERE role = 'student'");
    $totalStudents = $stmt->fetch()['count'];

    $stmt = $pdo->query("SELECT COUNT(*) as count FROM users WHERE role = 'educator'");
    $totalEducators = $stmt->fetch()['count'];

    $stmt = $pdo->query("SELECT COUNT(*) as count FROM users WHERE is_active = 1");
    $activeUsers = $stmt->fetch()['count'];

    // Content counts
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM lessons");
    $totalLessons = $stmt->fetch()['count'];

    $stmt = $pdo->query("SELECT COUNT(*) as count FROM lessons WHERE is_published = 1");
    $publishedLessons = $stmt->fetch()['count'];

    $stmt = $pdo->query("SELECT COUNT(*) as count FROM quizzes");
    $totalQuizzes = $stmt->fetch()['count'];

    $stmt = $pdo->query("SELECT COUNT(*) as count FROM quiz_results");
    $totalQuizResults = $stmt->fetch()['count'];

    $stmt = $pdo->query("SELECT COUNT(*) as count FROM study_plans");
    $totalStudyPlans = $stmt->fetch()['count'];

    // Recent activity
    $stmt = $pdo->query("
        SELECT u.name, u.email, u.role, u.created_at
        FROM users u
        ORDER BY u.created_at DESC
        LIMIT 10
    ");
    $recentUsers = $stmt->fetchAll();

    $stmt = $pdo->query("
        SELECT l.title, u.name as educator_name, l.created_at, l.is_published
        FROM lessons l
        JOIN users u ON l.educator_id = u.id
        ORDER BY l.created_at DESC
        LIMIT 10
    ");
    $recentLessons = $stmt->fetchAll();

    // Platform health
    $stmt = $pdo->query("SELECT AVG(percentage) as avg FROM quiz_results");
    $platformAvgScore = round($stmt->fetch()['avg'] ?? 0, 1);

    $stmt = $pdo->query("
        SELECT COUNT(*) as count FROM quiz_results
        WHERE synced_from_offline = 1
    ");
    $offlineSyncs = $stmt->fetch()['count'];
} catch (PDOException $e) {
    error_log("Admin dashboard error: " . $e->getMessage());
    $error = "Failed to load dashboard data";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - LearnLift</title>
    <link rel="stylesheet" href="/LearnLift/assets/css/style.css">
</head>

<body>
    <nav class="navbar">
        <div class="container navbar-container">
            <a href="/LearnLift/" class="navbar-brand">LearnLift</a>
            <button class="navbar-toggle" aria-label="Toggle navigation">☰</button>
            <ul class="navbar-menu">
                <li><a href="/LearnLift/admin/dashboard.php" class="active">Dashboard</a></li>
                <li><a href="/LearnLift/admin/users.php">Users</a></li>
                <li><a href="/LearnLift/admin/lessons.php">Lessons</a></li>
                <li><a href="/LearnLift/admin/quizzes.php">Quizzes</a></li>
                <li><a href="/LearnLift/admin/analytics.php">Analytics</a></li>
                <li><a href="/LearnLift/profile.php">Profile</a></li>
                <li><span id="online-status" class="status-indicator"></span></li>
                <li><button class="btn btn-sm btn-outline theme-toggle" title="Toggle Dark Mode" style="margin-right: 10px;">🌙</button></li>
                <li><a href="/LearnLift/api/auth.php?action=logout">Logout</a></li>
            </ul>
        </div>
    </nav>

    <div style="background: var(--gradient-primary); color: var(--white); padding: var(--spacing-xl) 0; margin-bottom: var(--spacing-xl);">
        <div class="container">
            <h1>Admin Dashboard 🛡️</h1>
            <p>System overview and management</p>
        </div>
    </div>

    <div class="container">
        <!-- User Statistics -->
        <h2>User Statistics</h2>
        <div class="row mb-4">
            <div class="col-3">
                <div class="card text-center">
                    <div class="card-body">
                        <div style="font-size: 2.5rem; font-weight: 700; color: var(--primary);">
                            <?php echo $totalStudents; ?>
                        </div>
                        <div style="color: var(--gray); font-size: 0.875rem; text-transform: uppercase;">
                            Students
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-3">
                <div class="card text-center">
                    <div class="card-body">
                        <div style="font-size: 2.5rem; font-weight: 700; color: var(--secondary);">
                            <?php echo $totalEducators; ?>
                        </div>
                        <div style="color: var(--gray); font-size: 0.875rem; text-transform: uppercase;">
                            Educators
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-3">
                <div class="card text-center">
                    <div class="card-body">
                        <div style="font-size: 2.5rem; font-weight: 700; color: var(--success);">
                            <?php echo $activeUsers; ?>
                        </div>
                        <div style="color: var(--gray); font-size: 0.875rem; text-transform: uppercase;">
                            Active Users
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-3">
                <div class="card text-center">
                    <div class="card-body">
                        <div style="font-size: 2.5rem; font-weight: 700; color: var(--info);">
                            <?php echo $totalStudents + $totalEducators; ?>
                        </div>
                        <div style="color: var(--gray); font-size: 0.875rem; text-transform: uppercase;">
                            Total Users
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Content Statistics -->
        <h2>Content Statistics</h2>
        <div class="row mb-4">
            <div class="col-3">
                <div class="card text-center">
                    <div class="card-body">
                        <div style="font-size: 2.5rem; font-weight: 700; color: var(--primary);">
                            <?php echo $totalLessons; ?>
                        </div>
                        <div style="color: var(--gray); font-size: 0.875rem; text-transform: uppercase;">
                            Total Lessons
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-3">
                <div class="card text-center">
                    <div class="card-body">
                        <div style="font-size: 2.5rem; font-weight: 700; color: var(--success);">
                            <?php echo $publishedLessons; ?>
                        </div>
                        <div style="color: var(--gray); font-size: 0.875rem; text-transform: uppercase;">
                            Published
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-3">
                <div class="card text-center">
                    <div class="card-body">
                        <div style="font-size: 2.5rem; font-weight: 700; color: var(--secondary);">
                            <?php echo $totalQuizzes; ?>
                        </div>
                        <div style="color: var(--gray); font-size: 0.875rem; text-transform: uppercase;">
                            Quizzes
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-3">
                <div class="card text-center">
                    <div class="card-body">
                        <div style="font-size: 2.5rem; font-weight: 700; color: var(--info);">
                            <?php echo $totalQuizResults; ?>
                        </div>
                        <div style="color: var(--gray); font-size: 0.875rem; text-transform: uppercase;">
                            Quiz Attempts
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Platform Health -->
        <h2>Platform Health</h2>
        <div class="row mb-4">
            <div class="col-4">
                <div class="card text-center">
                    <div class="card-body">
                        <div style="font-size: 2.5rem; font-weight: 700; color: var(--success);">
                            <?php echo $platformAvgScore; ?>%
                        </div>
                        <div style="color: var(--gray); font-size: 0.875rem; text-transform: uppercase;">
                            Platform Avg Score
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-4">
                <div class="card text-center">
                    <div class="card-body">
                        <div style="font-size: 2.5rem; font-weight: 700; color: var(--primary);">
                            <?php echo $offlineSyncs; ?>
                        </div>
                        <div style="color: var(--gray); font-size: 0.875rem; text-transform: uppercase;">
                            Offline Syncs
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-4">
                <div class="card text-center">
                    <div class="card-body">
                        <div style="font-size: 2.5rem; font-weight: 700; color: var(--secondary);">
                            <?php echo $totalStudyPlans; ?>
                        </div>
                        <div style="color: var(--gray); font-size: 0.875rem; text-transform: uppercase;">
                            Study Plans
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Recent Users -->
            <div class="col-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Recent User Registrations</h3>
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Role</th>
                                    <th>Joined</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentUsers as $user): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($user['name']); ?></td>
                                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                                        <td><span class="badge badge-primary"><?php echo $user['role']; ?></span></td>
                                        <td><?php echo timeAgo($user['created_at']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer">
                        <a href="/LearnLift/admin/users.php" class="btn btn-outline btn-block">
                            Manage Users
                        </a>
                    </div>
                </div>
            </div>

            <!-- Recent Lessons -->
            <div class="col-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Recent Lessons</h3>
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Educator</th>
                                    <th>Status</th>
                                    <th>Created</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentLessons as $lesson): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($lesson['title']); ?></td>
                                        <td><?php echo htmlspecialchars($lesson['educator_name']); ?></td>
                                        <td>
                                            <?php if ($lesson['is_published']): ?>
                                                <span class="badge badge-success">Published</span>
                                            <?php else: ?>
                                                <span class="badge badge-warning">Draft</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo timeAgo($lesson['created_at']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="card-footer">
                        <a href="/LearnLift/admin/lessons.php" class="btn btn-outline btn-block">
                            Manage Lessons
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="/LearnLift/assets/js/main.js"></script>
    <script src="/LearnLift/assets/js/offline.js"></script>
    <script src="/LearnLift/assets/js/sync.js"></script>
</body>

</html>