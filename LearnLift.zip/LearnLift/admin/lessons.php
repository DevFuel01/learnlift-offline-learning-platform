<?php

/**
 * Admin Lesson Oversight
 * LearnLift - Offline-First Education Platform
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireAdmin();

$error = '';
$success = '';

// Handle lesson update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_lesson'])) {
    $lessonId = (int)$_POST['lesson_id'];
    $title = sanitize($_POST['title'] ?? '');
    $description = sanitize($_POST['description'] ?? '');
    $content = sanitize($_POST['content'] ?? '');
    $isPublished = isset($_POST['is_published']) ? 1 : 0;
    $csrfToken = $_POST['csrf_token'] ?? '';

    if (!verifyCSRFToken($csrfToken)) {
        $error = 'Invalid security token';
    } elseif (empty($title)) {
        $error = 'Title is required';
    } else {
        try {
            $stmt = $pdo->prepare("
                UPDATE lessons 
                SET title = ?, description = ?, content = ?, is_published = ?
                WHERE id = ?
            ");
            $stmt->execute([$title, $description, $content, $isPublished, $lessonId]);

            $success = 'Lesson updated successfully!';
        } catch (PDOException $e) {
            error_log("Lesson update error: " . $e->getMessage());
            $error = 'Failed to update lesson';
        }
    }
}

// Handle lesson deletion
if (isset($_GET['delete']) && isset($_GET['confirm'])) {
    $lessonId = (int)$_GET['delete'];

    try {
        // Get file path
        $stmt = $pdo->prepare("SELECT file_path FROM lessons WHERE id = ?");
        $stmt->execute([$lessonId]);
        $lesson = $stmt->fetch();

        if ($lesson) {
            // Delete file if exists
            if ($lesson['file_path'] && file_exists(__DIR__ . '/../' . $lesson['file_path'])) {
                unlink(__DIR__ . '/../' . $lesson['file_path']);
            }

            // Delete lesson
            $stmt = $pdo->prepare("DELETE FROM lessons WHERE id = ?");
            $stmt->execute([$lessonId]);

            $success = 'Lesson deleted successfully!';
        }
    } catch (PDOException $e) {
        error_log("Lesson deletion error: " . $e->getMessage());
        $error = 'Failed to delete lesson';
    }
}

// Handle publish/unpublish toggle
if (isset($_GET['toggle_publish'])) {
    $lessonId = (int)$_GET['toggle_publish'];

    try {
        $stmt = $pdo->prepare("SELECT is_published FROM lessons WHERE id = ?");
        $stmt->execute([$lessonId]);
        $lesson = $stmt->fetch();

        if ($lesson) {
            $newStatus = $lesson['is_published'] ? 0 : 1;
            $stmt = $pdo->prepare("UPDATE lessons SET is_published = ? WHERE id = ?");
            $stmt->execute([$newStatus, $lessonId]);

            $success = $newStatus ? 'Lesson published!' : 'Lesson unpublished!';
        }
    } catch (PDOException $e) {
        error_log("Toggle publish error: " . $e->getMessage());
        $error = 'Failed to update lesson status';
    }
}

// Get all lessons with filters
$educatorFilter = $_GET['educator'] ?? 'all';
$statusFilter = $_GET['status'] ?? 'all';
$search = $_GET['search'] ?? '';

try {
    $sql = "
        SELECT l.*, u.name as educator_name,
               (SELECT COUNT(*) FROM downloaded_lessons WHERE lesson_id = l.id) as download_count,
               (SELECT COUNT(*) FROM quizzes WHERE lesson_id = l.id) as quiz_count
        FROM lessons l
        JOIN users u ON l.educator_id = u.id
        WHERE 1=1
    ";
    $params = [];

    if ($educatorFilter !== 'all') {
        $sql .= " AND l.educator_id = ?";
        $params[] = (int)$educatorFilter;
    }

    if ($statusFilter === 'published') {
        $sql .= " AND l.is_published = 1";
    } elseif ($statusFilter === 'draft') {
        $sql .= " AND l.is_published = 0";
    }

    if (!empty($search)) {
        $sql .= " AND (l.title LIKE ? OR l.description LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
    }

    $sql .= " ORDER BY l.created_at DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $lessons = $stmt->fetchAll();

    // Get educators for filter
    $stmt = $pdo->query("SELECT id, name FROM users WHERE role = 'educator' ORDER BY name");
    $educators = $stmt->fetchAll();

    // Get statistics
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM lessons");
    $totalLessons = $stmt->fetch()['count'];

    $stmt = $pdo->query("SELECT COUNT(*) as count FROM lessons WHERE is_published = 1");
    $publishedLessons = $stmt->fetch()['count'];

    $stmt = $pdo->query("SELECT COUNT(*) as count FROM lessons WHERE is_published = 0");
    $draftLessons = $stmt->fetch()['count'];
} catch (PDOException $e) {
    error_log("Lessons fetch error: " . $e->getMessage());
    $error = "Failed to load lessons";
}

$csrfToken = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lesson Oversight - LearnLift</title>
    <link rel="stylesheet" href="/LearnLift/assets/css/style.css">
    <style>
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 9999;
            align-items: center;
            justify-content: center;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: var(--white);
            padding: var(--spacing-xl);
            border-radius: var(--radius-lg);
            max-width: 700px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
        }

        .filters {
            display: flex;
            gap: var(--spacing-md);
            margin-bottom: var(--spacing-lg);
            flex-wrap: wrap;
        }
    </style>
</head>

<body>
    <nav class="navbar">
        <div class="container navbar-container">
            <a href="/LearnLift/" class="navbar-brand">LearnLift</a>
            <button class="navbar-toggle" aria-label="Toggle navigation">☰</button>
            <ul class="navbar-menu">
                <li><a href="/LearnLift/admin/dashboard.php">Dashboard</a></li>
                <li><a href="/LearnLift/admin/users.php">Users</a></li>
                <li><a href="/LearnLift/admin/lessons.php" class="active">Lessons</a></li>
                <li><a href="/LearnLift/admin/quizzes.php">Quizzes</a></li>
                <li><a href="/LearnLift/admin/analytics.php">Analytics</a></li>
                <li><a href="/LearnLift/profile.php">Profile</a></li>
                <li><span id="online-status" class="status-indicator"></span></li>
                <li><button class="btn btn-sm btn-outline theme-toggle" title="Toggle Dark Mode" style="margin-right: 10px;">🌙</button></li>
                <li><a href="/LearnLift/api/auth.php?action=logout">Logout</a></li>
            </ul>
        </div>
    </nav>

    <div class="container" style="margin-top: var(--spacing-xl);">
        <h1>Lesson Oversight</h1>
        <p class="mb-4">Manage all lessons across the platform</p>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>

        <!-- Statistics -->
        <div class="row mb-4">
            <div class="col-4">
                <div class="card text-center">
                    <div class="card-body">
                        <div style="font-size: 2rem; font-weight: 700; color: var(--primary);">
                            <?php echo $totalLessons; ?>
                        </div>
                        <div style="color: var(--gray); font-size: 0.875rem;">Total Lessons</div>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="card text-center">
                    <div class="card-body">
                        <div style="font-size: 2rem; font-weight: 700; color: var(--success);">
                            <?php echo $publishedLessons; ?>
                        </div>
                        <div style="color: var(--gray); font-size: 0.875rem;">Published</div>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="card text-center">
                    <div class="card-body">
                        <div style="font-size: 2rem; font-weight: 700; color: var(--warning);">
                            <?php echo $draftLessons; ?>
                        </div>
                        <div style="color: var(--gray); font-size: 0.875rem;">Drafts</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filters -->
        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" class="filters">
                    <div>
                        <label class="form-label">Educator</label>
                        <select name="educator" class="form-control" onchange="this.form.submit()">
                            <option value="all" <?php echo $educatorFilter === 'all' ? 'selected' : ''; ?>>All Educators</option>
                            <?php foreach ($educators as $educator): ?>
                                <option value="<?php echo $educator['id']; ?>"
                                    <?php echo $educatorFilter == $educator['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($educator['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label class="form-label">Status</label>
                        <select name="status" class="form-control" onchange="this.form.submit()">
                            <option value="all" <?php echo $statusFilter === 'all' ? 'selected' : ''; ?>>All Status</option>
                            <option value="published" <?php echo $statusFilter === 'published' ? 'selected' : ''; ?>>Published</option>
                            <option value="draft" <?php echo $statusFilter === 'draft' ? 'selected' : ''; ?>>Draft</option>
                        </select>
                    </div>

                    <div style="flex: 1;">
                        <label class="form-label">Search</label>
                        <input type="text" name="search" class="form-control" placeholder="Title or description..."
                            value="<?php echo htmlspecialchars($search); ?>">
                    </div>

                    <div style="display: flex; align-items: flex-end; gap: var(--spacing-xs);">
                        <button type="submit" class="btn btn-primary">Filter</button>
                        <a href="?" class="btn btn-outline">Clear</a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Lessons Table -->
        <div class="card">
            <div class="card-body">
                <?php if (empty($lessons)): ?>
                    <div class="text-center" style="padding: var(--spacing-2xl);">
                        <h3>No Lessons Found</h3>
                        <p>No lessons match your filters.</p>
                    </div>
                <?php else: ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Educator</th>
                                <th>Status</th>
                                <th>Downloads</th>
                                <th>Quizzes</th>
                                <th>Created</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($lessons as $lesson): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars($lesson['title']); ?></strong>
                                        <?php if ($lesson['description']): ?>
                                            <div style="font-size: 0.875rem; color: var(--gray);">
                                                <?php echo htmlspecialchars(substr($lesson['description'], 0, 80)); ?>
                                                <?php echo strlen($lesson['description']) > 80 ? '...' : ''; ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($lesson['educator_name']); ?></td>
                                    <td>
                                        <?php if ($lesson['is_published']): ?>
                                            <span class="badge badge-success">Published</span>
                                        <?php else: ?>
                                            <span class="badge badge-warning">Draft</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo $lesson['download_count']; ?></td>
                                    <td><?php echo $lesson['quiz_count']; ?></td>
                                    <td><?php echo formatDate($lesson['created_at']); ?></td>
                                    <td>
                                        <div style="display: flex; gap: var(--spacing-xs);">
                                            <a href="?toggle_publish=<?php echo $lesson['id']; ?>"
                                                class="btn btn-sm <?php echo $lesson['is_published'] ? 'btn-warning' : 'btn-success'; ?>"
                                                title="<?php echo $lesson['is_published'] ? 'Unpublish' : 'Publish'; ?>">
                                                <?php echo $lesson['is_published'] ? '👁️' : '📢'; ?>
                                            </a>
                                            <button onclick="openEditModal(<?php echo htmlspecialchars(json_encode($lesson)); ?>)"
                                                class="btn btn-sm btn-primary" title="Edit">
                                                ✏️
                                            </button>
                                            <button onclick="confirmDelete(<?php echo $lesson['id']; ?>, '<?php echo htmlspecialchars($lesson['title']); ?>')"
                                                class="btn btn-sm btn-danger" title="Delete">
                                                🗑️
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Edit Lesson Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <h2>Edit Lesson</h2>
            <form method="POST">
                <input type="hidden" name="update_lesson" value="1">
                <input type="hidden" name="lesson_id" id="edit_lesson_id">
                <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">

                <div class="form-group">
                    <label class="form-label">Title *</label>
                    <input type="text" name="title" id="edit_title" class="form-control" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Description</label>
                    <textarea name="description" id="edit_description" class="form-control" rows="3"></textarea>
                </div>

                <div class="form-group">
                    <label class="form-label">Content *</label>
                    <textarea name="content" id="edit_content" class="form-control" rows="8" required></textarea>
                </div>

                <div class="form-check">
                    <input type="checkbox" name="is_published" id="edit_published" class="form-check-input">
                    <label for="edit_published">Published</label>
                </div>

                <div style="display: flex; gap: var(--spacing-md); margin-top: var(--spacing-lg);">
                    <button type="submit" class="btn btn-primary">Update Lesson</button>
                    <button type="button" onclick="closeEditModal()" class="btn btn-outline">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <script src="/LearnLift/assets/js/main.js"></script>
    <script>
        function openEditModal(lesson) {
            document.getElementById('edit_lesson_id').value = lesson.id;
            document.getElementById('edit_title').value = lesson.title;
            document.getElementById('edit_description').value = lesson.description || '';
            document.getElementById('edit_content').value = lesson.content || '';
            document.getElementById('edit_published').checked = lesson.is_published == 1;
            document.getElementById('editModal').classList.add('active');
        }

        function closeEditModal() {
            document.getElementById('editModal').classList.remove('active');
        }

        function confirmDelete(id, title) {
            if (confirm(`Are you sure you want to delete "${title}"?\n\nThis will also delete all associated quizzes and student progress.\n\nThis action cannot be undone.`)) {
                window.location.href = '?delete=' + id + '&confirm=1';
            }
        }

        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.classList.remove('active');
            }
        }
    </script>
    <script src="/LearnLift/assets/js/main.js"></script>
</body>

</html>