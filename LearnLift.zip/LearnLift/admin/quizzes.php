<?php

/**
 * Admin Quiz Oversight
 * LearnLift - Offline-First Education Platform
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireAdmin();

$error = '';
$success = '';

// Handle quiz update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_quiz'])) {
    $quizId = (int)$_POST['quiz_id'];
    $title = sanitize($_POST['title'] ?? '');
    $description = sanitize($_POST['description'] ?? '');
    $timeLimit = (int)($_POST['time_limit'] ?? 0);
    $passPercentage = (int)($_POST['pass_percentage'] ?? 70);
    $csrfToken = $_POST['csrf_token'] ?? '';

    if (!verifyCSRFToken($csrfToken)) {
        $error = 'Invalid security token';
    } elseif (empty($title)) {
        $error = 'Title is required';
    } else {
        try {
            $stmt = $pdo->prepare("
                UPDATE quizzes 
                SET title = ?, description = ?, time_limit = ?, pass_percentage = ?
                WHERE id = ?
            ");
            $stmt->execute([$title, $description, $timeLimit, $passPercentage, $quizId]);

            $success = 'Quiz updated successfully!';
        } catch (PDOException $e) {
            error_log("Quiz update error: " . $e->getMessage());
            $error = 'Failed to update quiz';
        }
    }
}

// Handle quiz deletion
if (isset($_GET['delete']) && isset($_GET['confirm'])) {
    $quizId = (int)$_GET['delete'];

    try {
        $stmt = $pdo->prepare("DELETE FROM quizzes WHERE id = ?");
        $stmt->execute([$quizId]);

        $success = 'Quiz deleted successfully!';
    } catch (PDOException $e) {
        error_log("Quiz deletion error: " . $e->getMessage());
        $error = 'Failed to delete quiz';
    }
}

// Get all quizzes with filters
$educatorFilter = $_GET['educator'] ?? 'all';
$search = $_GET['search'] ?? '';

try {
    $sql = "
        SELECT q.*, l.title as lesson_title, u.name as educator_name,
               (SELECT COUNT(*) FROM quiz_questions WHERE quiz_id = q.id) as question_count,
               (SELECT COUNT(*) FROM quiz_results WHERE quiz_id = q.id) as attempt_count
        FROM quizzes q
        JOIN lessons l ON q.lesson_id = l.id
        JOIN users u ON q.educator_id = u.id
        WHERE 1=1
    ";
    $params = [];

    if ($educatorFilter !== 'all') {
        $sql .= " AND q.educator_id = ?";
        $params[] = (int)$educatorFilter;
    }

    if (!empty($search)) {
        $sql .= " AND (q.title LIKE ? OR q.description LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
    }

    $sql .= " ORDER BY q.created_at DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $quizzes = $stmt->fetchAll();

    // Get educators for filter
    $stmt = $pdo->query("SELECT id, name FROM users WHERE role = 'educator' ORDER BY name");
    $educators = $stmt->fetchAll();

    // Get statistics
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM quizzes");
    $totalQuizzes = $stmt->fetch()['count'];

    $stmt = $pdo->query("SELECT SUM(percentage) / COUNT(*) as avg FROM quiz_results");
    $avgScore = round($stmt->fetch()['avg'] ?? 0, 1);

    $stmt = $pdo->query("SELECT COUNT(*) as count FROM quiz_results");
    $totalAttempts = $stmt->fetch()['count'];
} catch (PDOException $e) {
    error_log("Quizzes fetch error: " . $e->getMessage());
    $error = "Failed to load quizzes";
}

$csrfToken = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quiz Oversight - LearnLift</title>
    <link rel="stylesheet" href="/LearnLift/assets/css/style.css">
    <style>
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 9999;
            align-items: center;
            justify-content: center;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: var(--white);
            padding: var(--spacing-xl);
            border-radius: var(--radius-lg);
            max-width: 600px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
        }

        .filters {
            display: flex;
            gap: var(--spacing-md);
            margin-bottom: var(--spacing-lg);
            flex-wrap: wrap;
        }
    </style>
</head>

<body>
    <nav class="navbar">
        <div class="container navbar-container">
            <a href="/LearnLift/" class="navbar-brand">LearnLift</a>
            <button class="navbar-toggle" aria-label="Toggle navigation">☰</button>
            <ul class="navbar-menu">
                <li><a href="/LearnLift/admin/dashboard.php">Dashboard</a></li>
                <li><a href="/LearnLift/admin/users.php">Users</a></li>
                <li><a href="/LearnLift/admin/lessons.php">Lessons</a></li>
                <li><a href="/LearnLift/admin/quizzes.php" class="active">Quizzes</a></li>
                <li><a href="/LearnLift/admin/analytics.php">Analytics</a></li>
                <li><a href="/LearnLift/profile.php">Profile</a></li>
                <li><span id="online-status" class="status-indicator"></span></li>
                <li><button class="btn btn-sm btn-outline theme-toggle" title="Toggle Dark Mode" style="margin-right: 10px;">🌙</button></li>
                <li><a href="/LearnLift/api/auth.php?action=logout">Logout</a></li>
            </ul>
        </div>
    </nav>

    <div class="container" style="margin-top: var(--spacing-xl);">
        <h1>Quiz Oversight</h1>
        <p class="mb-4">Manage all quizzes across the platform</p>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>

        <!-- Statistics -->
        <div class="row mb-4">
            <div class="col-4">
                <div class="card text-center">
                    <div class="card-body">
                        <div style="font-size: 2rem; font-weight: 700; color: var(--primary);">
                            <?php echo $totalQuizzes; ?>
                        </div>
                        <div style="color: var(--gray); font-size: 0.875rem;">Total Quizzes</div>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="card text-center">
                    <div class="card-body">
                        <div style="font-size: 2rem; font-weight: 700; color: var(--success);">
                            <?php echo $totalAttempts; ?>
                        </div>
                        <div style="color: var(--gray); font-size: 0.875rem;">Total Attempts</div>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="card text-center">
                    <div class="card-body">
                        <div style="font-size: 2rem; font-weight: 700; color: var(--info);">
                            <?php echo $avgScore; ?>%
                        </div>
                        <div style="color: var(--gray); font-size: 0.875rem;">Global Avg Score</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filters -->
        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" class="filters">
                    <div>
                        <label class="form-label">Educator</label>
                        <select name="educator" class="form-control" onchange="this.form.submit()">
                            <option value="all" <?php echo $educatorFilter === 'all' ? 'selected' : ''; ?>>All Educators</option>
                            <?php foreach ($educators as $educator): ?>
                                <option value="<?php echo $educator['id']; ?>"
                                    <?php echo $educatorFilter == $educator['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($educator['name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div style="flex: 1;">
                        <label class="form-label">Search</label>
                        <input type="text" name="search" class="form-control" placeholder="Quiz title..."
                            value="<?php echo htmlspecialchars($search); ?>">
                    </div>

                    <div style="display: flex; align-items: flex-end; gap: var(--spacing-xs);">
                        <button type="submit" class="btn btn-primary">Filter</button>
                        <a href="?" class="btn btn-outline">Clear</a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Quizzes Table -->
        <div class="card">
            <div class="card-body">
                <?php if (empty($quizzes)): ?>
                    <div class="text-center" style="padding: var(--spacing-2xl);">
                        <h3>No Quizzes Found</h3>
                        <p>No quizzes match your filters.</p>
                    </div>
                <?php else: ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Educator</th>
                                <th>Lesson</th>
                                <th>Questions</th>
                                <th>Attempts</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($quizzes as $quiz): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars($quiz['title']); ?></strong>
                                        <?php if ($quiz['description']): ?>
                                            <div style="font-size: 0.875rem; color: var(--gray);">
                                                <?php echo htmlspecialchars(substr($quiz['description'], 0, 80)); ?>
                                                <?php echo strlen($quiz['description']) > 80 ? '...' : ''; ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($quiz['educator_name']); ?></td>
                                    <td><?php echo htmlspecialchars($quiz['lesson_title']); ?></td>
                                    <td>
                                        <span class="badge badge-info">
                                            <?php echo $quiz['question_count']; ?>
                                        </span>
                                    </td>
                                    <td><?php echo $quiz['attempt_count']; ?></td>
                                    <td>
                                        <div style="display: flex; gap: var(--spacing-xs);">
                                            <button onclick="openEditModal(<?php echo htmlspecialchars(json_encode($quiz)); ?>)"
                                                class="btn btn-sm btn-primary" title="Edit Metadata">
                                                ✏️
                                            </button>
                                            <button onclick="confirmDelete(<?php echo $quiz['id']; ?>, '<?php echo htmlspecialchars($quiz['title']); ?>')"
                                                class="btn btn-sm btn-danger" title="Delete">
                                                🗑️
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Edit Quiz Metadata Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <h2>Edit Quiz Metadata</h2>
            <form method="POST">
                <input type="hidden" name="update_quiz" value="1">
                <input type="hidden" name="quiz_id" id="edit_quiz_id">
                <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">

                <div class="form-group">
                    <label class="form-label">Title *</label>
                    <input type="text" name="title" id="edit_title" class="form-control" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Description</label>
                    <textarea name="description" id="edit_description" class="form-control" rows="3"></textarea>
                </div>

                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-label">Time Limit (mins)</label>
                            <input type="number" name="time_limit" id="edit_time_limit" class="form-control" min="0">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-label">Pass Percentage</label>
                            <input type="number" name="pass_percentage" id="edit_pass_percentage" class="form-control" min="0" max="100">
                        </div>
                    </div>
                </div>

                <div style="display: flex; gap: var(--spacing-md); margin-top: var(--spacing-lg);">
                    <button type="submit" class="btn btn-primary">Update Quiz</button>
                    <button type="button" onclick="closeEditModal()" class="btn btn-outline">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <script src="/LearnLift/assets/js/main.js"></script>
    <script>
        function openEditModal(quiz) {
            document.getElementById('edit_quiz_id').value = quiz.id;
            document.getElementById('edit_title').value = quiz.title;
            document.getElementById('edit_description').value = quiz.description || '';
            document.getElementById('edit_time_limit').value = quiz.time_limit;
            document.getElementById('edit_pass_percentage').value = quiz.pass_percentage;
            document.getElementById('editModal').classList.add('active');
        }

        function closeEditModal() {
            document.getElementById('editModal').classList.remove('active');
        }

        function confirmDelete(id, title) {
            if (confirm(`Are you sure you want to delete "${title}"?\n\nThis will also delete ALL questions and student results associated with this quiz.\n\nThis action cannot be undone.`)) {
                window.location.href = '?delete=' + id + '&confirm=1';
            }
        }

        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.classList.remove('active');
            }
        }
    </script>
    <script src="/LearnLift/assets/js/main.js"></script>
</body>

</html>