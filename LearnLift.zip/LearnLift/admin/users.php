<?php

/**
 * Admin User Management
 * LearnLift - Offline-First Education Platform
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireAdmin();

$error = '';
$success = '';

// Handle user creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_user'])) {
    $name = sanitize($_POST['name'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? 'student';
    $isActive = isset($_POST['is_active']) ? 1 : 0;
    $csrfToken = $_POST['csrf_token'] ?? '';

    if (!verifyCSRFToken($csrfToken)) {
        $error = 'Invalid security token';
    } elseif (empty($name) || empty($email) || empty($password)) {
        $error = 'All fields are required';
    } elseif (!validateEmail($email)) {
        $error = 'Invalid email format';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters';
    } else {
        try {
            // Check if email exists
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);

            if ($stmt->fetch()) {
                $error = 'Email already exists';
            } else {
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("
                    INSERT INTO users (name, email, password, role, is_active)
                    VALUES (?, ?, ?, ?, ?)
                ");
                $stmt->execute([$name, $email, $hashedPassword, $role, $isActive]);

                $success = 'User created successfully!';
            }
        } catch (PDOException $e) {
            error_log("User creation error: " . $e->getMessage());
            $error = 'Failed to create user';
        }
    }
}

// Handle user update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_user'])) {
    $userId = (int)$_POST['user_id'];
    $name = sanitize($_POST['name'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $role = $_POST['role'] ?? 'student';
    $isActive = isset($_POST['is_active']) ? 1 : 0;
    $csrfToken = $_POST['csrf_token'] ?? '';

    if (!verifyCSRFToken($csrfToken)) {
        $error = 'Invalid security token';
    } elseif (empty($name) || empty($email)) {
        $error = 'Name and email are required';
    } elseif (!validateEmail($email)) {
        $error = 'Invalid email format';
    } else {
        try {
            // Check if email exists for another user
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
            $stmt->execute([$email, $userId]);

            if ($stmt->fetch()) {
                $error = 'Email already exists';
            } else {
                $stmt = $pdo->prepare("
                    UPDATE users 
                    SET name = ?, email = ?, role = ?, is_active = ?
                    WHERE id = ?
                ");
                $stmt->execute([$name, $email, $role, $isActive, $userId]);

                $success = 'User updated successfully!';
            }
        } catch (PDOException $e) {
            error_log("User update error: " . $e->getMessage());
            $error = 'Failed to update user';
        }
    }
}

// Handle password reset
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reset_password'])) {
    $userId = (int)$_POST['user_id'];
    $newPassword = $_POST['new_password'] ?? '';
    $csrfToken = $_POST['csrf_token'] ?? '';

    if (!verifyCSRFToken($csrfToken)) {
        $error = 'Invalid security token';
    } elseif (strlen($newPassword) < 6) {
        $error = 'Password must be at least 6 characters';
    } else {
        try {
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->execute([$hashedPassword, $userId]);

            $success = 'Password reset successfully!';
        } catch (PDOException $e) {
            error_log("Password reset error: " . $e->getMessage());
            $error = 'Failed to reset password';
        }
    }
}

// Handle user deletion
if (isset($_GET['delete']) && isset($_GET['confirm'])) {
    $userId = (int)$_GET['delete'];

    // Prevent deleting yourself
    if ($userId == getCurrentUserId()) {
        $error = 'You cannot delete your own account';
    } else {
        try {
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$userId]);

            $success = 'User deleted successfully!';
        } catch (PDOException $e) {
            error_log("User deletion error: " . $e->getMessage());
            $error = 'Failed to delete user';
        }
    }
}

// Handle toggle active status
if (isset($_GET['toggle_active'])) {
    $userId = (int)$_GET['toggle_active'];

    if ($userId == getCurrentUserId()) {
        $error = 'You cannot deactivate your own account';
    } else {
        try {
            $stmt = $pdo->prepare("SELECT is_active FROM users WHERE id = ?");
            $stmt->execute([$userId]);
            $user = $stmt->fetch();

            if ($user) {
                $newStatus = $user['is_active'] ? 0 : 1;
                $stmt = $pdo->prepare("UPDATE users SET is_active = ? WHERE id = ?");
                $stmt->execute([$newStatus, $userId]);

                $success = $newStatus ? 'User activated!' : 'User deactivated!';
            }
        } catch (PDOException $e) {
            error_log("Toggle active error: " . $e->getMessage());
            $error = 'Failed to update user status';
        }
    }
}

// Get all users with filters
$roleFilter = $_GET['role'] ?? 'all';
$statusFilter = $_GET['status'] ?? 'all';
$search = $_GET['search'] ?? '';

try {
    $sql = "SELECT * FROM users WHERE 1=1";
    $params = [];

    if ($roleFilter !== 'all') {
        $sql .= " AND role = ?";
        $params[] = $roleFilter;
    }

    if ($statusFilter === 'active') {
        $sql .= " AND is_active = 1";
    } elseif ($statusFilter === 'inactive') {
        $sql .= " AND is_active = 0";
    }

    if (!empty($search)) {
        $sql .= " AND (name LIKE ? OR email LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
    }

    $sql .= " ORDER BY created_at DESC";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $users = $stmt->fetchAll();

    // Get user counts
    $stmt = $pdo->query("SELECT role, COUNT(*) as count FROM users GROUP BY role");
    $roleCounts = [];
    while ($row = $stmt->fetch()) {
        $roleCounts[$row['role']] = $row['count'];
    }
} catch (PDOException $e) {
    error_log("Users fetch error: " . $e->getMessage());
    $error = "Failed to load users";
}

$csrfToken = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management - LearnLift</title>
    <link rel="stylesheet" href="/LearnLift/assets/css/style.css">
    <style>
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 9999;
            align-items: center;
            justify-content: center;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: var(--white);
            padding: var(--spacing-xl);
            border-radius: var(--radius-lg);
            max-width: 600px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
        }

        .filters {
            display: flex;
            gap: var(--spacing-md);
            margin-bottom: var(--spacing-lg);
            flex-wrap: wrap;
        }
    </style>
</head>

<body>
    <nav class="navbar">
        <div class="container navbar-container">
            <a href="/LearnLift/" class="navbar-brand">LearnLift</a>
            <button class="navbar-toggle" aria-label="Toggle navigation">☰</button>
            <ul class="navbar-menu">
                <li><a href="/LearnLift/admin/dashboard.php">Dashboard</a></li>
                <li><a href="/LearnLift/admin/users.php" class="active">Users</a></li>
                <li><a href="/LearnLift/admin/lessons.php">Lessons</a></li>
                <li><a href="/LearnLift/admin/quizzes.php">Quizzes</a></li>
                <li><a href="/LearnLift/admin/analytics.php">Analytics</a></li>
                <li><a href="/LearnLift/profile.php">Profile</a></li>
                <li><span id="online-status" class="status-indicator"></span></li>
                <li><button class="btn btn-sm btn-outline theme-toggle" title="Toggle Dark Mode" style="margin-right: 10px;">🌙</button></li>
                <li><a href="/LearnLift/api/auth.php?action=logout">Logout</a></li>
            </ul>
        </div>
    </nav>

    <div class="container" style="margin-top: var(--spacing-xl);">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: var(--spacing-xl);">
            <h1>User Management</h1>
            <button onclick="openCreateModal()" class="btn btn-primary">
                ➕ Create New User
            </button>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>

        <!-- Statistics -->
        <div class="row mb-4">
            <div class="col-3">
                <div class="card text-center">
                    <div class="card-body">
                        <div style="font-size: 2rem; font-weight: 700; color: var(--primary);">
                            <?php echo $roleCounts['student'] ?? 0; ?>
                        </div>
                        <div style="color: var(--gray); font-size: 0.875rem;">Students</div>
                    </div>
                </div>
            </div>
            <div class="col-3">
                <div class="card text-center">
                    <div class="card-body">
                        <div style="font-size: 2rem; font-weight: 700; color: var(--secondary);">
                            <?php echo $roleCounts['educator'] ?? 0; ?>
                        </div>
                        <div style="color: var(--gray); font-size: 0.875rem;">Educators</div>
                    </div>
                </div>
            </div>
            <div class="col-3">
                <div class="card text-center">
                    <div class="card-body">
                        <div style="font-size: 2rem; font-weight: 700; color: var(--danger);">
                            <?php echo $roleCounts['admin'] ?? 0; ?>
                        </div>
                        <div style="color: var(--gray); font-size: 0.875rem;">Admins</div>
                    </div>
                </div>
            </div>
            <div class="col-3">
                <div class="card text-center">
                    <div class="card-body">
                        <div style="font-size: 2rem; font-weight: 700; color: var(--info);">
                            <?php echo count($users); ?>
                        </div>
                        <div style="color: var(--gray); font-size: 0.875rem;">Total Users</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filters -->
        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" class="filters">
                    <div>
                        <label class="form-label">Role</label>
                        <select name="role" class="form-control" onchange="this.form.submit()">
                            <option value="all" <?php echo $roleFilter === 'all' ? 'selected' : ''; ?>>All Roles</option>
                            <option value="student" <?php echo $roleFilter === 'student' ? 'selected' : ''; ?>>Students</option>
                            <option value="educator" <?php echo $roleFilter === 'educator' ? 'selected' : ''; ?>>Educators</option>
                            <option value="admin" <?php echo $roleFilter === 'admin' ? 'selected' : ''; ?>>Admins</option>
                        </select>
                    </div>

                    <div>
                        <label class="form-label">Status</label>
                        <select name="status" class="form-control" onchange="this.form.submit()">
                            <option value="all" <?php echo $statusFilter === 'all' ? 'selected' : ''; ?>>All Status</option>
                            <option value="active" <?php echo $statusFilter === 'active' ? 'selected' : ''; ?>>Active</option>
                            <option value="inactive" <?php echo $statusFilter === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                        </select>
                    </div>

                    <div style="flex: 1;">
                        <label class="form-label">Search</label>
                        <input type="text" name="search" class="form-control" placeholder="Name or email..."
                            value="<?php echo htmlspecialchars($search); ?>">
                    </div>

                    <div style="display: flex; align-items: flex-end; gap: var(--spacing-xs);">
                        <button type="submit" class="btn btn-primary">Filter</button>
                        <a href="?" class="btn btn-outline">Clear</a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Users Table -->
        <div class="card">
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Status</th>
                            <th>Joined</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($users as $user): ?>
                            <tr>
                                <td><strong><?php echo htmlspecialchars($user['name']); ?></strong></td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td>
                                    <span class="badge badge-<?php
                                                                echo $user['role'] === 'admin' ? 'danger' : ($user['role'] === 'educator' ? 'secondary' : 'primary');
                                                                ?>">
                                        <?php echo ucfirst($user['role']); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($user['is_active']): ?>
                                        <span class="badge badge-success">Active</span>
                                    <?php else: ?>
                                        <span class="badge badge-warning">Inactive</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo formatDate($user['created_at']); ?></td>
                                <td>
                                    <div style="display: flex; gap: var(--spacing-xs);">
                                        <?php if ($user['id'] != getCurrentUserId()): ?>
                                            <a href="?toggle_active=<?php echo $user['id']; ?>"
                                                class="btn btn-sm <?php echo $user['is_active'] ? 'btn-warning' : 'btn-success'; ?>"
                                                title="<?php echo $user['is_active'] ? 'Deactivate' : 'Activate'; ?>">
                                                <?php echo $user['is_active'] ? '🔒' : '🔓'; ?>
                                            </a>
                                        <?php endif; ?>
                                        <button onclick="openEditModal(<?php echo htmlspecialchars(json_encode($user)); ?>)"
                                            class="btn btn-sm btn-primary" title="Edit">
                                            ✏️
                                        </button>
                                        <button onclick="openPasswordModal(<?php echo $user['id']; ?>, '<?php echo htmlspecialchars($user['name']); ?>')"
                                            class="btn btn-sm btn-secondary" title="Reset Password">
                                            🔑
                                        </button>
                                        <?php if ($user['id'] != getCurrentUserId()): ?>
                                            <button onclick="confirmDelete(<?php echo $user['id']; ?>, '<?php echo htmlspecialchars($user['name']); ?>')"
                                                class="btn btn-sm btn-danger" title="Delete">
                                                🗑️
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Create User Modal -->
    <div id="createModal" class="modal">
        <div class="modal-content">
            <h2>Create New User</h2>
            <form method="POST">
                <input type="hidden" name="create_user" value="1">
                <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">

                <div class="form-group">
                    <label class="form-label">Name *</label>
                    <input type="text" name="name" class="form-control" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Email *</label>
                    <input type="email" name="email" class="form-control" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Password *</label>
                    <input type="password" name="password" class="form-control" minlength="6" required>
                    <small style="color: var(--gray);">Minimum 6 characters</small>
                </div>

                <div class="form-group">
                    <label class="form-label">Role *</label>
                    <select name="role" class="form-control" required>
                        <option value="student">Student</option>
                        <option value="educator">Educator</option>
                        <option value="admin">Admin</option>
                    </select>
                </div>

                <div class="form-check">
                    <input type="checkbox" name="is_active" id="create_active" class="form-check-input" checked>
                    <label for="create_active">Active</label>
                </div>

                <div style="display: flex; gap: var(--spacing-md); margin-top: var(--spacing-lg);">
                    <button type="submit" class="btn btn-primary">Create User</button>
                    <button type="button" onclick="closeCreateModal()" class="btn btn-outline">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit User Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <h2>Edit User</h2>
            <form method="POST">
                <input type="hidden" name="update_user" value="1">
                <input type="hidden" name="user_id" id="edit_user_id">
                <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">

                <div class="form-group">
                    <label class="form-label">Name *</label>
                    <input type="text" name="name" id="edit_name" class="form-control" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Email *</label>
                    <input type="email" name="email" id="edit_email" class="form-control" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Role *</label>
                    <select name="role" id="edit_role" class="form-control" required>
                        <option value="student">Student</option>
                        <option value="educator">Educator</option>
                        <option value="admin">Admin</option>
                    </select>
                </div>

                <div class="form-check">
                    <input type="checkbox" name="is_active" id="edit_active" class="form-check-input">
                    <label for="edit_active">Active</label>
                </div>

                <div style="display: flex; gap: var(--spacing-md); margin-top: var(--spacing-lg);">
                    <button type="submit" class="btn btn-primary">Update User</button>
                    <button type="button" onclick="closeEditModal()" class="btn btn-outline">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Password Reset Modal -->
    <div id="passwordModal" class="modal">
        <div class="modal-content">
            <h2>Reset Password</h2>
            <p id="password_user_name"></p>
            <form method="POST">
                <input type="hidden" name="reset_password" value="1">
                <input type="hidden" name="user_id" id="password_user_id">
                <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">

                <div class="form-group">
                    <label class="form-label">New Password *</label>
                    <input type="password" name="new_password" class="form-control" minlength="6" required>
                    <small style="color: var(--gray);">Minimum 6 characters</small>
                </div>

                <div style="display: flex; gap: var(--spacing-md); margin-top: var(--spacing-lg);">
                    <button type="submit" class="btn btn-primary">Reset Password</button>
                    <button type="button" onclick="closePasswordModal()" class="btn btn-outline">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <script src="/LearnLift/assets/js/main.js"></script>
    <script>
        function openCreateModal() {
            document.getElementById('createModal').classList.add('active');
        }

        function closeCreateModal() {
            document.getElementById('createModal').classList.remove('active');
        }

        function openEditModal(user) {
            document.getElementById('edit_user_id').value = user.id;
            document.getElementById('edit_name').value = user.name;
            document.getElementById('edit_email').value = user.email;
            document.getElementById('edit_role').value = user.role;
            document.getElementById('edit_active').checked = user.is_active == 1;
            document.getElementById('editModal').classList.add('active');
        }

        function closeEditModal() {
            document.getElementById('editModal').classList.remove('active');
        }

        function openPasswordModal(userId, userName) {
            document.getElementById('password_user_id').value = userId;
            document.getElementById('password_user_name').textContent = 'Reset password for: ' + userName;
            document.getElementById('passwordModal').classList.add('active');
        }

        function closePasswordModal() {
            document.getElementById('passwordModal').classList.remove('active');
        }

        function confirmDelete(id, name) {
            if (confirm(`Are you sure you want to delete "${name}"?\n\nThis will also delete all their associated data.\n\nThis action cannot be undone.`)) {
                window.location.href = '?delete=' + id + '&confirm=1';
            }
        }

        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.classList.remove('active');
            }
        }
    </script>
    <script src="/LearnLift/assets/js/main.js"></script>
</body>

</html>