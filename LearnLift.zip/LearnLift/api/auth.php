<?php

/**
 * Authentication API
 * LearnLift - Offline-First Education Platform
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

// Handle logout
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_start();
    session_destroy();
    redirect('/LearnLift/index.php');
}

// For other auth operations, return JSON
header('Content-Type: application/json');

// Get request method
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $action = $input['action'] ?? '';

    switch ($action) {
        case 'check_auth':
            checkAuth();
            break;

        default:
            errorResponse('Unknown action');
    }
} else {
    errorResponse('Method not allowed', 405);
}

/**
 * Check if user is authenticated
 */
function checkAuth()
{
    if (isLoggedIn()) {
        successResponse([
            'authenticated' => true,
            'user' => [
                'id' => getCurrentUserId(),
                'name' => getCurrentUserName(),
                'role' => getCurrentUserRole()
            ]
        ]);
    } else {
        successResponse(['authenticated' => false]);
    }
}
