<?php

/**
 * Lessons API
 * LearnLift - Offline-First Education Platform
 */

header('Content-Type: application/json');

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireAuth();

$method = $_SERVER['REQUEST_METHOD'];
$userId = getCurrentUserId();
$userRole = getCurrentUserRole();

// GET - Retrieve lessons
if ($method === 'GET') {
    if (isset($_GET['id'])) {
        // Get single lesson
        $lessonId = (int)$_GET['id'];

        try {
            $stmt = $pdo->prepare("
                SELECT l.*, u.name as educator_name
                FROM lessons l
                JOIN users u ON l.educator_id = u.id
                WHERE l.id = ? AND (l.is_published = 1 OR l.educator_id = ? OR ? = 'admin')
            ");
            $stmt->execute([$lessonId, $userId, $userRole]);
            $lesson = $stmt->fetch();

            if ($lesson) {
                successResponse(['data' => $lesson]);
            } else {
                errorResponse('Lesson not found', 404);
            }
        } catch (PDOException $e) {
            error_log("Lesson fetch error: " . $e->getMessage());
            errorResponse('Failed to fetch lesson');
        }
    } elseif (isset($_GET['action']) && $_GET['action'] === 'mark_downloaded') {
        // Mark lesson as downloaded
        $lessonId = (int)$_GET['id'];

        try {
            $stmt = $pdo->prepare("
                INSERT IGNORE INTO downloaded_lessons (student_id, lesson_id)
                VALUES (?, ?)
            ");
            $stmt->execute([$userId, $lessonId]);
            successResponse(['message' => 'Lesson marked as downloaded']);
        } catch (PDOException $e) {
            error_log("Download mark error: " . $e->getMessage());
            errorResponse('Failed to mark as downloaded');
        }
    } else {
        // Get all lessons
        try {
            if ($userRole === 'student') {
                $stmt = $pdo->prepare("
                    SELECT l.*, u.name as educator_name
                    FROM lessons l
                    JOIN users u ON l.educator_id = u.id
                    WHERE l.is_published = 1
                    ORDER BY l.created_at DESC
                ");
                $stmt->execute();
            } elseif ($userRole === 'educator') {
                $stmt = $pdo->prepare("
                    SELECT l.*, u.name as educator_name
                    FROM lessons l
                    JOIN users u ON l.educator_id = u.id
                    WHERE l.educator_id = ?
                    ORDER BY l.created_at DESC
                ");
                $stmt->execute([$userId]);
            } else {
                // Admin sees all
                $stmt = $pdo->prepare("
                    SELECT l.*, u.name as educator_name
                    FROM lessons l
                    JOIN users u ON l.educator_id = u.id
                    ORDER BY l.created_at DESC
                ");
                $stmt->execute();
            }

            $lessons = $stmt->fetchAll();
            successResponse(['data' => $lessons]);
        } catch (PDOException $e) {
            error_log("Lessons fetch error: " . $e->getMessage());
            errorResponse('Failed to fetch lessons');
        }
    }
}

// POST - Create lesson
elseif ($method === 'POST') {
    requireEducatorOrAdmin();

    $input = json_decode(file_get_contents('php://input'), true);

    $title = sanitize($input['title'] ?? '');
    $description = sanitize($input['description'] ?? '');
    $content = sanitize($input['content'] ?? '');
    $isPublished = (int)($input['is_published'] ?? 0);

    if (empty($title)) {
        errorResponse('Title is required');
    }

    try {
        $stmt = $pdo->prepare("
            INSERT INTO lessons (title, description, content, educator_id, is_published)
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([$title, $description, $content, $userId, $isPublished]);

        successResponse([
            'message' => 'Lesson created successfully',
            'lesson_id' => $pdo->lastInsertId()
        ]);
    } catch (PDOException $e) {
        error_log("Lesson creation error: " . $e->getMessage());
        errorResponse('Failed to create lesson');
    }
}

// PUT - Update lesson
elseif ($method === 'PUT') {
    requireEducatorOrAdmin();

    $lessonId = (int)($_GET['id'] ?? 0);
    $input = json_decode(file_get_contents('php://input'), true);

    // Verify ownership or admin
    $stmt = $pdo->prepare("SELECT educator_id FROM lessons WHERE id = ?");
    $stmt->execute([$lessonId]);
    $lesson = $stmt->fetch();

    if (!$lesson) {
        errorResponse('Lesson not found', 404);
    }

    if ($userRole !== 'admin' && $lesson['educator_id'] != $userId) {
        errorResponse('Access denied', 403);
    }

    // Build update query
    $updates = [];
    $params = [];

    if (isset($input['title'])) {
        $updates[] = "title = ?";
        $params[] = sanitize($input['title']);
    }

    if (isset($input['description'])) {
        $updates[] = "description = ?";
        $params[] = sanitize($input['description']);
    }

    if (isset($input['content'])) {
        $updates[] = "content = ?";
        $params[] = sanitize($input['content']);
    }

    if (isset($input['is_published'])) {
        $updates[] = "is_published = ?";
        $params[] = (int)$input['is_published'];
    }

    if (empty($updates)) {
        errorResponse('No fields to update');
    }

    $params[] = $lessonId;

    try {
        $sql = "UPDATE lessons SET " . implode(', ', $updates) . " WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        successResponse(['message' => 'Lesson updated successfully']);
    } catch (PDOException $e) {
        error_log("Lesson update error: " . $e->getMessage());
        errorResponse('Failed to update lesson');
    }
}

// DELETE - Delete lesson
elseif ($method === 'DELETE') {
    requireEducatorOrAdmin();

    $lessonId = (int)($_GET['id'] ?? 0);

    // Verify ownership or admin
    $stmt = $pdo->prepare("SELECT educator_id FROM lessons WHERE id = ?");
    $stmt->execute([$lessonId]);
    $lesson = $stmt->fetch();

    if (!$lesson) {
        errorResponse('Lesson not found', 404);
    }

    if ($userRole !== 'admin' && $lesson['educator_id'] != $userId) {
        errorResponse('Access denied', 403);
    }

    try {
        $stmt = $pdo->prepare("DELETE FROM lessons WHERE id = ?");
        $stmt->execute([$lessonId]);

        successResponse(['message' => 'Lesson deleted successfully']);
    } catch (PDOException $e) {
        error_log("Lesson deletion error: " . $e->getMessage());
        errorResponse('Failed to delete lesson');
    }
} else {
    errorResponse('Method not allowed', 405);
}
