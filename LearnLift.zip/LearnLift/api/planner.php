<?php

/**
 * Study Planner API
 * LearnLift - Offline-First Education Platform
 */

header('Content-Type: application/json');

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireStudent();

$method = $_SERVER['REQUEST_METHOD'];
$userId = getCurrentUserId();

// GET - Retrieve study plans
if ($method === 'GET') {
    try {
        if (isset($_GET['id'])) {
            $planId = (int)$_GET['id'];
            $stmt = $pdo->prepare("SELECT * FROM study_plans WHERE id = ? AND student_id = ?");
            $stmt->execute([$planId, $userId]);
            $plan = $stmt->fetch();

            if ($plan) {
                successResponse(['data' => $plan]);
            } else {
                errorResponse('Study plan not found', 404);
            }
        } else {
            // Get all plans for user
            $stmt = $pdo->prepare("
                SELECT * FROM study_plans
                WHERE student_id = ?
                ORDER BY task_date DESC, created_at DESC
            ");
            $stmt->execute([$userId]);
            $plans = $stmt->fetchAll();

            successResponse(['data' => $plans]);
        }
    } catch (PDOException $e) {
        error_log("Planner fetch error: " . $e->getMessage());
        errorResponse('Failed to fetch study plans');
    }
}

// POST - Create study plan
elseif ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);

    $taskTitle = sanitize($input['task_title'] ?? '');
    $taskDescription = sanitize($input['task_description'] ?? '');
    $taskDate = $input['task_date'] ?? date('Y-m-d');
    $isCompleted = (int)($input['is_completed'] ?? 0);

    if (empty($taskTitle)) {
        errorResponse('Task title is required');
    }

    try {
        $stmt = $pdo->prepare("
            INSERT INTO study_plans (student_id, task_title, task_description, task_date, is_completed)
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([$userId, $taskTitle, $taskDescription, $taskDate, $isCompleted]);

        successResponse([
            'message' => 'Study plan created successfully',
            'plan_id' => $pdo->lastInsertId()
        ]);
    } catch (PDOException $e) {
        error_log("Planner creation error: " . $e->getMessage());
        errorResponse('Failed to create study plan');
    }
}

// PUT - Update study plan
elseif ($method === 'PUT') {
    $planId = (int)($_GET['id'] ?? 0);
    $input = json_decode(file_get_contents('php://input'), true);

    // Verify ownership
    $stmt = $pdo->prepare("SELECT id FROM study_plans WHERE id = ? AND student_id = ?");
    $stmt->execute([$planId, $userId]);

    if (!$stmt->fetch()) {
        errorResponse('Study plan not found or access denied', 404);
    }

    // Build update query
    $updates = [];
    $params = [];

    if (isset($input['task_title'])) {
        $updates[] = "task_title = ?";
        $params[] = sanitize($input['task_title']);
    }

    if (isset($input['task_description'])) {
        $updates[] = "task_description = ?";
        $params[] = sanitize($input['task_description']);
    }

    if (isset($input['task_date'])) {
        $updates[] = "task_date = ?";
        $params[] = $input['task_date'];
    }

    if (isset($input['is_completed'])) {
        $updates[] = "is_completed = ?";
        $params[] = (int)$input['is_completed'];

        if ($input['is_completed']) {
            $updates[] = "completed_at = NOW()";
        } else {
            $updates[] = "completed_at = NULL";
        }
    }

    if (empty($updates)) {
        errorResponse('No fields to update');
    }

    $params[] = $planId;

    try {
        $sql = "UPDATE study_plans SET " . implode(', ', $updates) . " WHERE id = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        successResponse(['message' => 'Study plan updated successfully']);
    } catch (PDOException $e) {
        error_log("Planner update error: " . $e->getMessage());
        errorResponse('Failed to update study plan');
    }
}

// DELETE - Delete study plan
elseif ($method === 'DELETE') {
    $planId = (int)($_GET['id'] ?? 0);

    // Verify ownership
    $stmt = $pdo->prepare("SELECT id FROM study_plans WHERE id = ? AND student_id = ?");
    $stmt->execute([$planId, $userId]);

    if (!$stmt->fetch()) {
        errorResponse('Study plan not found or access denied', 404);
    }

    try {
        $stmt = $pdo->prepare("DELETE FROM study_plans WHERE id = ?");
        $stmt->execute([$planId]);

        successResponse(['message' => 'Study plan deleted successfully']);
    } catch (PDOException $e) {
        error_log("Planner deletion error: " . $e->getMessage());
        errorResponse('Failed to delete study plan');
    }
} else {
    errorResponse('Method not allowed', 405);
}
