<?php

/**
 * Sync API - Handle offline data synchronization
 * LearnLift - Offline-First Education Platform
 */

header('Content-Type: application/json');

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

// Require authentication
requireAuth();

// Only handle POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    errorResponse('Method not allowed', 405);
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['type']) || !isset($input['data'])) {
    errorResponse('Invalid request format');
}

$type = $input['type'];
$data = $input['data'];
$userId = getCurrentUserId();

try {
    switch ($type) {
        case 'quiz_result':
            syncQuizResult($pdo, $userId, $data);
            break;

        case 'study_plan':
            syncStudyPlan($pdo, $userId, $data);
            break;

        case 'study_plan_update':
            updateStudyPlan($pdo, $userId, $data);
            break;

        default:
            errorResponse('Unknown sync type');
    }
} catch (Exception $e) {
    error_log("Sync error: " . $e->getMessage());
    errorResponse('Sync failed: ' . $e->getMessage());
}

/**
 * Sync quiz result
 */
function syncQuizResult($pdo, $userId, $data)
{
    // Validate required fields
    if (!isset($data['quiz_id']) || !isset($data['answers']) || !isset($data['score'])) {
        errorResponse('Missing required fields');
    }

    $quizId = (int)$data['quiz_id'];
    $answers = $data['answers'];
    $score = (float)$data['score'];
    $totalPoints = (int)($data['total_points'] ?? 0);
    $percentage = (float)($data['percentage'] ?? 0);
    $timeTaken = (int)($data['time_taken'] ?? 0);
    $submittedAt = $data['submitted_at'] ?? date('Y-m-d H:i:s');

    // Verify quiz exists
    $stmt = $pdo->prepare("SELECT id FROM quizzes WHERE id = ?");
    $stmt->execute([$quizId]);
    if (!$stmt->fetch()) {
        errorResponse('Quiz not found');
    }

    // Check if result already exists (prevent duplicates)
    $stmt = $pdo->prepare("
        SELECT id FROM quiz_results 
        WHERE quiz_id = ? AND student_id = ? AND submitted_at = ?
        LIMIT 1
    ");
    $stmt->execute([$quizId, $userId, $submittedAt]);

    if ($stmt->fetch()) {
        successResponse(['message' => 'Quiz result already synced']);
    }

    // Insert quiz result
    $stmt = $pdo->prepare("
        INSERT INTO quiz_results 
        (quiz_id, student_id, answers, score, total_points, percentage, time_taken, submitted_at, synced_from_offline)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
    ");

    $stmt->execute([
        $quizId,
        $userId,
        $answers,
        $score,
        $totalPoints,
        $percentage,
        $timeTaken,
        $submittedAt
    ]);

    successResponse([
        'message' => 'Quiz result synced successfully',
        'result_id' => $pdo->lastInsertId()
    ]);
}

/**
 * Sync study plan
 */
function syncStudyPlan($pdo, $userId, $data)
{
    // Validate required fields
    if (!isset($data['task_title']) || !isset($data['task_date'])) {
        errorResponse('Missing required fields');
    }

    $taskTitle = sanitize($data['task_title']);
    $taskDescription = sanitize($data['task_description'] ?? '');
    $taskDate = $data['task_date'];
    $isCompleted = (int)($data['is_completed'] ?? 0);
    $createdAt = $data['created_at'] ?? date('Y-m-d H:i:s');

    // Check for duplicate
    $stmt = $pdo->prepare("
        SELECT id FROM study_plans 
        WHERE student_id = ? AND task_title = ? AND task_date = ? AND created_at = ?
        LIMIT 1
    ");
    $stmt->execute([$userId, $taskTitle, $taskDate, $createdAt]);

    if ($stmt->fetch()) {
        successResponse(['message' => 'Study plan already synced']);
    }

    // Insert study plan
    $stmt = $pdo->prepare("
        INSERT INTO study_plans 
        (student_id, task_title, task_description, task_date, is_completed, created_at, synced_from_offline)
        VALUES (?, ?, ?, ?, ?, ?, 1)
    ");

    $stmt->execute([
        $userId,
        $taskTitle,
        $taskDescription,
        $taskDate,
        $isCompleted,
        $createdAt
    ]);

    successResponse([
        'message' => 'Study plan synced successfully',
        'plan_id' => $pdo->lastInsertId()
    ]);
}

/**
 * Update study plan
 */
function updateStudyPlan($pdo, $userId, $data)
{
    if (!isset($data['id'])) {
        errorResponse('Plan ID required');
    }

    $planId = (int)$data['id'];

    // Verify ownership
    $stmt = $pdo->prepare("SELECT id FROM study_plans WHERE id = ? AND student_id = ?");
    $stmt->execute([$planId, $userId]);

    if (!$stmt->fetch()) {
        errorResponse('Study plan not found or access denied');
    }

    // Build update query
    $updates = [];
    $params = [];

    if (isset($data['task_title'])) {
        $updates[] = "task_title = ?";
        $params[] = sanitize($data['task_title']);
    }

    if (isset($data['task_description'])) {
        $updates[] = "task_description = ?";
        $params[] = sanitize($data['task_description']);
    }

    if (isset($data['is_completed'])) {
        $updates[] = "is_completed = ?";
        $params[] = (int)$data['is_completed'];

        if ($data['is_completed']) {
            $updates[] = "completed_at = NOW()";
        }
    }

    if (empty($updates)) {
        errorResponse('No fields to update');
    }

    $params[] = $planId;

    $sql = "UPDATE study_plans SET " . implode(', ', $updates) . " WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    successResponse(['message' => 'Study plan updated successfully']);
}
