/**
 * LearnLift - Main JavaScript
 * Core functionality and Service Worker registration
 */

// Register Service Worker
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker
      .register("/LearnLift/sw.js")
      .then((registration) => {
        console.log("Service Worker registered:", registration);
        showToast("Offline mode enabled!", "success");
      })
      .catch((error) => {
        console.log("Service Worker registration failed:", error);
      });
  });
}

// Online/Offline Detection
let isOnline = navigator.onLine;

window.addEventListener("online", () => {
  isOnline = true;
  updateOnlineStatus();
  showToast("You are back online!", "success");
  // Trigger sync
  if (typeof syncOfflineData === "function") {
    syncOfflineData();
  }
});

window.addEventListener("offline", () => {
  isOnline = false;
  updateOnlineStatus();
  showToast(
    "You are offline. Changes will be synced when you reconnect.",
    "warning"
  );
});

// Update online status indicator
function updateOnlineStatus() {
  const statusIndicator = document.getElementById("online-status");
  if (statusIndicator) {
    if (isOnline) {
      statusIndicator.className = "status-indicator status-online";
      statusIndicator.innerHTML = '<span class="status-dot"></span> Online';
    } else {
      statusIndicator.className = "status-indicator status-offline";
      statusIndicator.innerHTML = '<span class="status-dot"></span> Offline';
    }
  }
}

// Initialize online status on page load
document.addEventListener("DOMContentLoaded", () => {
  updateOnlineStatus();

  // Navbar Toggle
  const navToggle = document.querySelector(".navbar-toggle");
  const navMenu = document.querySelector(".navbar-menu");

  if (navToggle && navMenu) {
    navToggle.addEventListener("click", () => {
      navMenu.classList.toggle("active");
    });
  }
});

// Toast Notification System
function showToast(message, type = "info", duration = 3000) {
  const toastContainer = getOrCreateToastContainer();

  const toast = document.createElement("div");
  toast.className = `toast alert alert-${type}`;
  toast.textContent = message;

  toastContainer.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = "0";
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

function getOrCreateToastContainer() {
  let container = document.querySelector(".toast-container");
  if (!container) {
    container = document.createElement("div");
    container.className = "toast-container";
    document.body.appendChild(container);
  }
  return container;
}

// AJAX Helper Functions
async function fetchAPI(url, options = {}) {
  try {
    const defaultOptions = {
      headers: {
        "Content-Type": "application/json",
      },
    };

    const response = await fetch(url, { ...defaultOptions, ...options });
    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "Request failed");
    }

    return data;
  } catch (error) {
    console.error("API Error:", error);
    throw error;
  }
}

async function postAPI(url, data) {
  return fetchAPI(url, {
    method: "POST",
    body: JSON.stringify(data),
  });
}

async function putAPI(url, data) {
  return fetchAPI(url, {
    method: "PUT",
    body: JSON.stringify(data),
  });
}

async function deleteAPI(url) {
  return fetchAPI(url, {
    method: "DELETE",
  });
}

// Form Validation
function validateForm(formId) {
  const form = document.getElementById(formId);
  if (!form) return false;

  const inputs = form.querySelectorAll(
    "input[required], textarea[required], select[required]"
  );
  let isValid = true;

  inputs.forEach((input) => {
    if (!input.value.trim()) {
      isValid = false;
      input.classList.add("is-invalid");
    } else {
      input.classList.remove("is-invalid");
    }
  });

  return isValid;
}

// Email Validation
function validateEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}

// Password Strength Checker
function checkPasswordStrength(password) {
  let strength = 0;

  if (password.length >= 8) strength++;
  if (password.length >= 12) strength++;
  if (/[a-z]/.test(password)) strength++;
  if (/[A-Z]/.test(password)) strength++;
  if (/[0-9]/.test(password)) strength++;
  if (/[^a-zA-Z0-9]/.test(password)) strength++;

  if (strength <= 2) return "weak";
  if (strength <= 4) return "medium";
  return "strong";
}

// Debounce Function
function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

// Format File Size
function formatFileSize(bytes) {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return Math.round((bytes / Math.pow(k, i)) * 100) / 100 + " " + sizes[i];
}

// Format Date
function formatDate(dateString) {
  const date = new Date(dateString);
  const options = { year: "numeric", month: "short", day: "numeric" };
  return date.toLocaleDateString("en-US", options);
}

// Format Time
function formatTime(dateString) {
  const date = new Date(dateString);
  const options = { hour: "2-digit", minute: "2-digit" };
  return date.toLocaleTimeString("en-US", options);
}

// Time Ago
function timeAgo(dateString) {
  const date = new Date(dateString);
  const seconds = Math.floor((new Date() - date) / 1000);

  let interval = seconds / 31536000;
  if (interval > 1) return Math.floor(interval) + " years ago";

  interval = seconds / 2592000;
  if (interval > 1) return Math.floor(interval) + " months ago";

  interval = seconds / 86400;
  if (interval > 1) return Math.floor(interval) + " days ago";

  interval = seconds / 3600;
  if (interval > 1) return Math.floor(interval) + " hours ago";

  interval = seconds / 60;
  if (interval > 1) return Math.floor(interval) + " minutes ago";

  return "just now";
}

// Loading Spinner
function showLoading(elementId) {
  const element = document.getElementById(elementId);
  if (element) {
    element.innerHTML = '<div class="spinner"></div>';
  }
}

function hideLoading(elementId) {
  const element = document.getElementById(elementId);
  if (element) {
    element.innerHTML = "";
  }
}

// Confirm Dialog
function confirmAction(message) {
  return confirm(message);
}

// Copy to Clipboard
async function copyToClipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
    showToast("Copied to clipboard!", "success");
    return true;
  } catch (error) {
    console.error("Failed to copy:", error);
    showToast("Failed to copy to clipboard", "danger");
    return false;
  }
}

// Download File
function downloadFile(url, filename) {
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

// Scroll to Top
function scrollToTop() {
  window.scrollTo({
    top: 0,
    behavior: "smooth",
  });
}

// Scroll to Element
function scrollToElement(elementId) {
  const element = document.getElementById(elementId);
  if (element) {
    element.scrollIntoView({
      behavior: "smooth",
      block: "start",
    });
  }
}

// Local Storage Helpers
const storage = {
  set: (key, value) => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (error) {
      console.error("Storage error:", error);
      return false;
    }
  },

  get: (key, defaultValue = null) => {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : defaultValue;
    } catch (error) {
      console.error("Storage error:", error);
      return defaultValue;
    }
  },

  remove: (key) => {
    try {
      localStorage.removeItem(key);
      return true;
    } catch (error) {
      console.error("Storage error:", error);
      return false;
    }
  },

  clear: () => {
    try {
      localStorage.clear();
      return true;
    } catch (error) {
      console.error("Storage error:", error);
      return false;
    }
  },
};


// Theme Manager
const ThemeManager = {
  init() {
    // Check saved theme or system preference
    const savedTheme = localStorage.getItem('theme');
    const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    
    if (savedTheme === 'dark' || (!savedTheme && systemPrefersDark)) {
      this.enableDarkMode();
    }

    // Add listener for system preference changes
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => {
      if (!localStorage.getItem('theme')) {
        if (e.matches) this.enableDarkMode();
        else this.disableDarkMode();
      }
    });
  },

  enableDarkMode() {
    document.documentElement.setAttribute('data-theme', 'dark');
    localStorage.setItem('theme', 'dark');
    this.updateToggleIcon(true);
  },

  disableDarkMode() {
    document.documentElement.removeAttribute('data-theme');
    localStorage.setItem('theme', 'light');
    this.updateToggleIcon(false);
  },

  toggle() {
    if (document.documentElement.getAttribute('data-theme') === 'dark') {
      this.disableDarkMode();
    } else {
      this.enableDarkMode();
    }
  },

  updateToggleIcon(isDark) {
    const toggleButtons = document.querySelectorAll('.theme-toggle');
    toggleButtons.forEach(btn => {
      btn.innerHTML = isDark ? '☀️' : '🌙';
      btn.title = isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode';
    });
  }
};

// Initialize theme on load
document.addEventListener('DOMContentLoaded', () => {
    ThemeManager.init();
    
    // Attach click handler to toggle buttons
    document.addEventListener('click', (e) => {
        if (e.target.closest('.theme-toggle')) {
            e.preventDefault();
            ThemeManager.toggle();
        }
    });
});

// Export for use in other scripts
window.LearnLift = {
  showToast,
  fetchAPI,
  postAPI,
  putAPI,
  deleteAPI,
  validateForm,
  validateEmail,
  checkPasswordStrength,
  formatFileSize,
  formatDate,
  formatTime,
  timeAgo,
  showLoading,
  hideLoading,
  confirmAction,
  copyToClipboard,
  downloadFile,
  scrollToTop,
  scrollToElement,
  storage,
  ThemeManager,
  isOnline: () => isOnline,
};
