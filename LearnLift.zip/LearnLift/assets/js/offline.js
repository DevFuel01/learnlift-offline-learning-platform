/**
 * LearnLift - IndexedDB Management
 * Handles offline data storage
 */

const DB_NAME = 'LearnLiftDB';
const DB_VERSION = 3;
let db = null;

// Initialize IndexedDB
function initDB() {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open(DB_NAME, DB_VERSION);
        
        request.onerror = () => {
            console.error('IndexedDB error:', request.error);
            reject(request.error);
        };
        
        request.onsuccess = () => {
            db = request.result;
            console.log('IndexedDB initialized');
            resolve(db);
        };
        
        request.onupgradeneeded = (event) => {
            db = event.target.result;
            console.log('IndexedDB upgrade needed, version:', event.oldVersion, '->', event.newVersion);
            
            const transaction = event.target.transaction;
            
            // Create or update object stores
            if (!db.objectStoreNames.contains('quizAnswers')) {
                const quizStore = db.createObjectStore('quizAnswers', { keyPath: 'id', autoIncrement: true });
                quizStore.createIndex('quizId', 'quizId', { unique: false });
                quizStore.createIndex('synced', 'synced', { unique: false });
                quizStore.createIndex('timestamp', 'timestamp', { unique: false });
            } else {
                const quizStore = transaction.objectStore('quizAnswers');
                if (!quizStore.indexNames.contains('synced')) quizStore.createIndex('synced', 'synced', { unique: false });
                if (!quizStore.indexNames.contains('quizId')) quizStore.createIndex('quizId', 'quizId', { unique: false });
                if (!quizStore.indexNames.contains('timestamp')) quizStore.createIndex('timestamp', 'timestamp', { unique: false });
            }
            
            if (!db.objectStoreNames.contains('studyPlans')) {
                const planStore = db.createObjectStore('studyPlans', { keyPath: 'id', autoIncrement: true });
                planStore.createIndex('synced', 'synced', { unique: false });
                planStore.createIndex('date', 'date', { unique: false });
            } else {
                const planStore = transaction.objectStore('studyPlans');
                if (!planStore.indexNames.contains('synced')) planStore.createIndex('synced', 'synced', { unique: false });
                if (!planStore.indexNames.contains('date')) planStore.createIndex('date', 'date', { unique: false });
            }
            
            if (!db.objectStoreNames.contains('downloadedLessons')) {
                const lessonStore = db.createObjectStore('downloadedLessons', { keyPath: 'lessonId' });
                lessonStore.createIndex('downloadedAt', 'downloadedAt', { unique: false });
            }
            
            if (!db.objectStoreNames.contains('syncQueue')) {
                const syncStore = db.createObjectStore('syncQueue', { keyPath: 'id', autoIncrement: true });
                syncStore.createIndex('type', 'type', { unique: false });
                syncStore.createIndex('timestamp', 'timestamp', { unique: false });
            }
        };
    });
}

// Generic DB operation helper
function dbOperation(storeName, mode, operation) {
    return new Promise((resolve, reject) => {
        if (!db) {
            reject(new Error('Database not initialized'));
            return;
        }
        
        try {
            const transaction = db.transaction([storeName], mode);
            const store = transaction.objectStore(storeName);
            const request = operation(store);
            
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        } catch (error) {
            reject(error);
        }
    });
}

// ===== Quiz Answers =====

// Save quiz answers offline
async function saveQuizAnswersOffline(quizId, answers, score, totalPoints, percentage, timeTaken) {
    const data = {
        quizId,
        answers: JSON.stringify(answers),
        score,
        totalPoints,
        percentage,
        timeTaken,
        synced: false,
        timestamp: new Date().toISOString()
    };
    
    try {
        const id = await dbOperation('quizAnswers', 'readwrite', store => store.add(data));
        console.log('Quiz answers saved offline:', id);
        
        // Add to sync queue
        await addToSyncQueue('quiz_result', data);
        
        return id;
    } catch (error) {
        console.error('Failed to save quiz answers:', error);
        throw error;
    }
}

// Get unsynced quiz answers
async function getUnsyncedQuizAnswers() {
    try {
        const results = await dbOperation('quizAnswers', 'readonly', store => store.getAll());
        return results.filter(item => !item.synced);
    } catch (error) {
        console.error('Failed to get unsynced quizzes:', error);
        return [];
    }
}

// Mark quiz answer as synced
async function markQuizAnswerSynced(id) {
    return dbOperation('quizAnswers', 'readwrite', store => {
        const request = store.get(id);
        request.onsuccess = () => {
            const data = request.result;
            if (data) {
                data.synced = true;
                store.put(data);
            }
        };
        return request;
    });
}

// ===== Study Plans =====

// Save study plan offline
async function saveStudyPlanOffline(taskTitle, taskDescription, taskDate, isCompleted = false) {
    const data = {
        taskTitle,
        taskDescription,
        taskDate,
        isCompleted,
        synced: false,
        timestamp: new Date().toISOString()
    };
    
    try {
        const id = await dbOperation('studyPlans', 'readwrite', store => store.add(data));
        console.log('Study plan saved offline:', id);
        
        // Add to sync queue
        await addToSyncQueue('study_plan', data);
        
        return id;
    } catch (error) {
        console.error('Failed to save study plan:', error);
        throw error;
    }
}

// Update study plan offline
async function updateStudyPlanOffline(id, updates) {
    return dbOperation('studyPlans', 'readwrite', store => {
        const request = store.get(id);
        request.onsuccess = () => {
            const data = request.result;
            if (data) {
                Object.assign(data, updates);
                data.synced = 0;
                store.put(data);
                
                // Add to sync queue
                addToSyncQueue('study_plan_update', data);
            }
        };
        return request;
    });
}

// Get unsynced study plans
async function getUnsyncedStudyPlans() {
    try {
        const results = await dbOperation('studyPlans', 'readonly', store => store.getAll());
        return results.filter(item => !item.synced);
    } catch (error) {
        console.error('Failed to get unsynced plans:', error);
        return [];
    }
}

// Mark study plan as synced
async function markStudyPlanSynced(id) {
    return dbOperation('studyPlans', 'readwrite', store => {
        const request = store.get(id);
        request.onsuccess = () => {
            const data = request.result;
            if (data) {
                data.synced = true;
                store.put(data);
            }
        };
        return request;
    });
}

// ===== Downloaded Lessons =====

// Save downloaded lesson
async function saveDownloadedLesson(lessonId, lessonData) {
    const data = {
        lessonId,
        ...lessonData,
        downloadedAt: new Date().toISOString()
    };
    
    try {
        await dbOperation('downloadedLessons', 'readwrite', store => store.put(data));
        console.log('Lesson saved for offline access:', lessonId);
        return true;
    } catch (error) {
        console.error('Failed to save lesson:', error);
        throw error;
    }
}

// Get downloaded lesson
async function getDownloadedLesson(lessonId) {
    return dbOperation('downloadedLessons', 'readonly', store => store.get(lessonId));
}

// Get all downloaded lessons
async function getAllDownloadedLessons() {
    return dbOperation('downloadedLessons', 'readonly', store => store.getAll());
}

// Remove downloaded lesson
async function removeDownloadedLesson(lessonId) {
    return dbOperation('downloadedLessons', 'readwrite', store => store.delete(lessonId));
}

// Check if lesson is downloaded
async function isLessonDownloaded(lessonId) {
    const lesson = await getDownloadedLesson(lessonId);
    return !!lesson;
}

// ===== Sync Queue =====

// Add item to sync queue
async function addToSyncQueue(type, data) {
    const queueItem = {
        type,
        data,
        timestamp: new Date().toISOString()
    };
    
    try {
        const id = await dbOperation('syncQueue', 'readwrite', store => store.add(queueItem));
        console.log('Added to sync queue:', type, id);
        
        // Register background sync if available
        if ('serviceWorker' in navigator && 'sync' in ServiceWorkerRegistration.prototype) {
            const registration = await navigator.serviceWorker.ready;
            await registration.sync.register('sync-offline-data');
        }
        
        return id;
    } catch (error) {
        console.error('Failed to add to sync queue:', error);
        throw error;
    }
}

// Get all sync queue items
async function getSyncQueue() {
    return dbOperation('syncQueue', 'readonly', store => store.getAll());
}

// Remove item from sync queue
async function removeFromSyncQueue(id) {
    return dbOperation('syncQueue', 'readwrite', store => store.delete(id));
}

// Clear sync queue
async function clearSyncQueue() {
    return dbOperation('syncQueue', 'readwrite', store => store.clear());
}

// ===== Utility Functions =====

// Get database stats
async function getDBStats() {
    const stats = {
        unsyncedQuizzes: 0,
        unsyncedPlans: 0,
        downloadedLessons: 0,
        syncQueueSize: 0
    };
    
    try {
        const unsyncedQuizzes = await getUnsyncedQuizAnswers();
        const unsyncedPlans = await getUnsyncedStudyPlans();
        const lessons = await getAllDownloadedLessons();
        const queue = await getSyncQueue();
        
        stats.unsyncedQuizzes = unsyncedQuizzes.length;
        stats.unsyncedPlans = unsyncedPlans.length;
        stats.downloadedLessons = lessons.length;
        stats.syncQueueSize = queue.length;
    } catch (error) {
        console.error('Failed to get DB stats:', error);
    }
    
    return stats;
}

// Clear all offline data
async function clearAllOfflineData() {
    try {
        await dbOperation('quizAnswers', 'readwrite', store => store.clear());
        await dbOperation('studyPlans', 'readwrite', store => store.clear());
        await dbOperation('downloadedLessons', 'readwrite', store => store.clear());
        await dbOperation('syncQueue', 'readwrite', store => store.clear());
        console.log('All offline data cleared');
        return true;
    } catch (error) {
        console.error('Failed to clear offline data:', error);
        throw error;
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', async () => {
    try {
        await initDB();
        console.log('Offline storage ready');
        
        // Display stats if there's a stats element
        const statsElement = document.getElementById('offline-stats');
        if (statsElement) {
            const stats = await getDBStats();
            statsElement.innerHTML = `
                <p>Downloaded Lessons: ${stats.downloadedLessons}</p>
                <p>Unsynced Quizzes: ${stats.unsyncedQuizzes}</p>
                <p>Unsynced Plans: ${stats.unsyncedPlans}</p>
            `;
        }
    } catch (error) {
        console.error('Failed to initialize offline storage:', error);
    }
});

// Export functions
window.OfflineDB = {
    initDB,
    saveQuizAnswersOffline,
    getUnsyncedQuizAnswers,
    markQuizAnswerSynced,
    saveStudyPlanOffline,
    updateStudyPlanOffline,
    getUnsyncedStudyPlans,
    markStudyPlanSynced,
    saveDownloadedLesson,
    getDownloadedLesson,
    getAllDownloadedLessons,
    removeDownloadedLesson,
    isLessonDownloaded,
    addToSyncQueue,
    getSyncQueue,
    removeFromSyncQueue,
    clearSyncQueue,
    getDBStats,
    clearAllOfflineData
};
