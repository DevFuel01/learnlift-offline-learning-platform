/**
 * LearnLift - Sync Manager
 * Handles synchronization of offline data
 */

let isSyncing = false;
let syncInProgress = false;

// Sync all offline data
async function syncOfflineData() {
    if (syncInProgress) {
        console.log('Sync already in progress');
        return;
    }
    
    if (!navigator.onLine) {
        console.log('Cannot sync: offline');
        return;
    }
    
    syncInProgress = true;
    updateSyncStatus('Syncing...', 'info');
    
    try {
        // Sync quiz answers
        await syncQuizAnswers();
        
        // Sync study plans
        await syncStudyPlans();
        
        // Clear sync queue
        await window.OfflineDB.clearSyncQueue();
        
        updateSyncStatus('All data synced!', 'success');
        window.LearnLift.showToast('Offline data synced successfully!', 'success');
        
    } catch (error) {
        console.error('Sync failed:', error);
        const errorMessage = error.message || 'Unknown error';
        updateSyncStatus(`Sync failed: ${errorMessage}`, 'danger');
        window.LearnLift.showToast(`Failed to sync: ${errorMessage}`, 'danger');
    } finally {
        syncInProgress = false;
    }
}

// Sync quiz answers
async function syncQuizAnswers() {
    try {
        const unsyncedQuizzes = await window.OfflineDB.getUnsyncedQuizAnswers();
        
        if (unsyncedQuizzes.length === 0) {
            console.log('No quiz answers to sync');
            return;
        }
        
        console.log(`Syncing ${unsyncedQuizzes.length} quiz answers...`);
        
        for (const quiz of unsyncedQuizzes) {
            try {
                const response = await fetch('/LearnLift/api/sync.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        type: 'quiz_result',
                        data: {
                            quiz_id: quiz.quizId,
                            answers: quiz.answers,
                            score: quiz.score,
                            total_points: quiz.totalPoints,
                            percentage: quiz.percentage,
                            time_taken: quiz.timeTaken,
                            submitted_at: quiz.timestamp
                        }
                    })
                });
                
                const contentType = response.headers.get('content-type');
                if (!response.ok || !contentType || !contentType.includes('application/json')) {
                    const errorText = await response.text();
                    console.error('API Error Response:', errorText);
                    throw new Error(`Server returned ${response.status} ${response.statusText}`);
                }
                
                const result = await response.json();
                
                if (result.success) {
                    await window.OfflineDB.markQuizAnswerSynced(quiz.id);
                    console.log('Quiz answer synced:', quiz.id);
                } else {
                    console.error('Failed to sync quiz answer:', result.error);
                }
            } catch (error) {
                console.error('Error syncing quiz answer:', error);
                throw error; // Re-throw to be caught by syncOfflineData
            }
        }
    } catch (error) {
        console.error('Failed to sync quiz answers:', error);
        throw error;
    }
}

// Sync study plans
async function syncStudyPlans() {
    try {
        const unsyncedPlans = await window.OfflineDB.getUnsyncedStudyPlans();
        
        if (unsyncedPlans.length === 0) {
            console.log('No study plans to sync');
            return;
        }
        
        console.log(`Syncing ${unsyncedPlans.length} study plans...`);
        
        for (const plan of unsyncedPlans) {
            try {
                const response = await fetch('/LearnLift/api/sync.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        type: 'study_plan',
                        data: {
                            task_title: plan.taskTitle,
                            task_description: plan.taskDescription,
                            task_date: plan.taskDate,
                            is_completed: plan.isCompleted,
                            created_at: plan.timestamp
                        }
                    })
                });
                
                const contentType = response.headers.get('content-type');
                if (!response.ok || !contentType || !contentType.includes('application/json')) {
                    const errorText = await response.text();
                    console.error('API Error Response:', errorText);
                    throw new Error(`Server returned ${response.status} ${response.statusText}`);
                }
                
                const result = await response.json();
                
                if (result.success) {
                    await window.OfflineDB.markStudyPlanSynced(plan.id);
                    console.log('Study plan synced:', plan.id);
                } else {
                    console.error('Failed to sync study plan:', result.error);
                }
            } catch (error) {
                console.error('Error syncing study plan:', error);
                throw error; // Re-throw to be caught by syncOfflineData
            }
        }
    } catch (error) {
        console.error('Failed to sync study plans:', error);
        throw error;
    }
}

// Update sync status UI
function updateSyncStatus(message, type = 'info') {
    const statusElement = document.getElementById('sync-status');
    if (statusElement) {
        statusElement.className = `alert alert-${type}`;
        statusElement.textContent = message;
        statusElement.style.display = 'block';
        
        // Hide after 3 seconds for success messages
        if (type === 'success') {
            setTimeout(() => {
                statusElement.style.display = 'none';
            }, 3000);
        }
    }
}

// Manual sync trigger
function triggerManualSync() {
    if (!navigator.onLine) {
        window.LearnLift.showToast('You are offline. Please connect to the internet to sync.', 'warning');
        return;
    }
    
    syncOfflineData();
}

// Listen for online event
window.addEventListener('online', () => {
    console.log('Connection restored, syncing...');
    setTimeout(() => {
        syncOfflineData();
    }, 1000); // Wait 1 second to ensure connection is stable
});

// Listen for Service Worker messages
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.addEventListener('message', (event) => {
        if (event.data.type === 'SYNC_OFFLINE_DATA') {
            console.log('Sync requested by Service Worker');
            syncOfflineData();
        }
    });
}

// Check for pending syncs on page load
document.addEventListener('DOMContentLoaded', async () => {
    try {
        const stats = await window.OfflineDB.getDBStats();
        const pendingItems = stats.unsyncedQuizzes + stats.unsyncedPlans;
        
        if (pendingItems > 0) {
            const syncBadge = document.getElementById('sync-badge');
            if (syncBadge) {
                syncBadge.textContent = pendingItems;
                syncBadge.style.display = 'inline-block';
            }
            
            // Auto-sync if online
            if (navigator.onLine) {
                console.log(`Found ${pendingItems} items to sync`);
                setTimeout(() => {
                    syncOfflineData();
                }, 2000); // Wait 2 seconds after page load
            }
        }
    } catch (error) {
        console.error('Failed to check pending syncs:', error);
    }
});

// Export functions
window.SyncManager = {
    syncOfflineData,
    syncQuizAnswers,
    syncStudyPlans,
    triggerManualSync,
    isSyncing: () => syncInProgress
};
