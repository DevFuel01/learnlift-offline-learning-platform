# Uploads Directory

This directory stores user-uploaded lesson files (PDFs, videos, documents).

## Security Note

- Files are validated before upload
- Only allowed file types can be uploaded
- File names are sanitized and made unique
- Direct access to files is controlled via PHP

## File Structure

```
uploads/
├── lessons/          # Lesson files
├── temp/             # Temporary uploads
└── .htaccess         # Access control
```

## Permissions

Ensure this directory is writable by the web server:

```bash
chmod 755 uploads
```
