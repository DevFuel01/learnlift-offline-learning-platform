-- LearnLift Demo Data
-- Sample users, lessons, quizzes for testing

USE learnlift;

-- Insert demo users
-- Password for all users: password123 (hashed with PASSWORD_HASH)
INSERT INTO users (name, email, password, role) VALUES
('Admin User', 'admin@learnlift.com', '$2y$10$wx1RryoiML0kyJ0YtXtbH.WYQBclWspqdNljIh8WB5RoqcUkcpiku', 'admin'),
('John Educator', 'educator@learnlift.com', '$2y$10$5qXweo7.lvkjDS4uBc2QVeT4P6ZlVAimYnRN5XzkZnJhEXkGZ.lOq', 'educator'),
('Jane Student', 'student@learnlift.com', '$2y$10$/v1QO4A4zrFZXp7cHd7rou0GqmAm0XKxDFkYyq8nBv.hO4SMSvszG', 'student'),
('Mary Teacher', 'mary@learnlift.com', '$2y$10$gfNp/h1axmSwwAc7sRL4eOeIjC5P/94vFng/luNzGseWrGelT2ovK', 'educator'),
('Bob Student', 'bob@learnlift.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'student');

-- Insert sample lessons (educator_id = 2 is John Educator)
INSERT INTO lessons (title, description, content, educator_id, is_published) VALUES
('Introduction to Mathematics', 'Basic mathematical concepts for beginners', 'This lesson covers fundamental mathematics including addition, subtraction, multiplication, and division. Perfect for students starting their math journey.', 2, 1),
('English Grammar Basics', 'Learn the fundamentals of English grammar', 'Master the basics of English grammar including parts of speech, sentence structure, and punctuation. Essential for effective communication.', 2, 1),
('Science: The Water Cycle', 'Understanding how water moves through our environment', 'Explore the fascinating journey of water through evaporation, condensation, precipitation, and collection. Includes diagrams and examples.', 4, 1),
('History: Ancient Civilizations', 'Journey through ancient human societies', 'Discover the great civilizations of ancient Egypt, Mesopotamia, Greece, and Rome. Learn about their contributions to modern society.', 4, 1),
('Computer Basics', 'Introduction to computers and technology', 'Learn about computer hardware, software, and basic operations. Perfect for beginners in the digital age.', 2, 0);

-- Insert sample quizzes
INSERT INTO quizzes (lesson_id, title, description, educator_id, time_limit, pass_percentage) VALUES
(1, 'Mathematics Quiz 1', 'Test your basic math skills', 2, 15, 60),
(2, 'Grammar Fundamentals Test', 'Check your understanding of grammar basics', 2, 20, 70),
(3, 'Water Cycle Assessment', 'Quiz on the water cycle process', 4, 10, 65);

-- Insert quiz questions for Mathematics Quiz
INSERT INTO quiz_questions (quiz_id, question, option_a, option_b, option_c, option_d, correct_answer, points, question_order) VALUES
(1, 'What is 5 + 7?', '10', '11', '12', '13', 'c', 1, 1),
(1, 'What is 15 - 8?', '6', '7', '8', '9', 'b', 1, 2),
(1, 'What is 6 × 4?', '20', '22', '24', '26', 'c', 1, 3),
(1, 'What is 20 ÷ 5?', '3', '4', '5', '6', 'b', 1, 4),
(1, 'What is 9 + 6?', '13', '14', '15', '16', 'c', 1, 5);

-- Insert quiz questions for Grammar Quiz
INSERT INTO quiz_questions (quiz_id, question, option_a, option_b, option_c, option_d, correct_answer, points, question_order) VALUES
(2, 'Which is a noun?', 'Run', 'Happy', 'Dog', 'Quickly', 'c', 1, 1),
(2, 'Which is a verb?', 'Table', 'Beautiful', 'Jump', 'Slowly', 'c', 1, 2),
(2, 'Which sentence is correct?', 'She go to school', 'She goes to school', 'She going to school', 'She gone to school', 'b', 1, 3),
(2, 'What is the plural of "child"?', 'Childs', 'Children', 'Childes', 'Childrens', 'b', 1, 4);

-- Insert quiz questions for Water Cycle Quiz
INSERT INTO quiz_questions (quiz_id, question, option_a, option_b, option_c, option_d, correct_answer, points, question_order) VALUES
(3, 'What is the process of water turning into vapor called?', 'Condensation', 'Precipitation', 'Evaporation', 'Collection', 'c', 1, 1),
(3, 'What happens when water vapor cools and forms clouds?', 'Evaporation', 'Condensation', 'Precipitation', 'Collection', 'b', 1, 2),
(3, 'What is rain, snow, and hail examples of?', 'Evaporation', 'Condensation', 'Precipitation', 'Collection', 'c', 1, 3),
(3, 'Where does water collect after precipitation?', 'In the sky', 'In clouds', 'In oceans, rivers, and lakes', 'In the sun', 'c', 1, 4);

-- Insert sample quiz results (student_id = 3 is Jane Student)
INSERT INTO quiz_results (quiz_id, student_id, answers, score, total_points, percentage, time_taken) VALUES
(1, 3, '{"1":"c","2":"b","3":"c","4":"b","5":"c"}', 5, 5, 100.00, 420),
(2, 3, '{"1":"c","2":"c","3":"b","4":"b"}', 4, 4, 100.00, 380);

-- Insert sample study plans
INSERT INTO study_plans (student_id, task_title, task_description, task_date, is_completed) VALUES
(3, 'Complete Mathematics Quiz', 'Finish the basic mathematics quiz', CURDATE(), 1),
(3, 'Read English Grammar Lesson', 'Study the grammar basics lesson', CURDATE(), 1),
(3, 'Review Water Cycle', 'Go through the water cycle lesson', DATE_ADD(CURDATE(), INTERVAL 1 DAY), 0),
(3, 'Practice Math Problems', 'Solve 10 additional math problems', DATE_ADD(CURDATE(), INTERVAL 1 DAY), 0),
(5, 'Start Computer Basics', 'Begin learning about computers', CURDATE(), 0);
