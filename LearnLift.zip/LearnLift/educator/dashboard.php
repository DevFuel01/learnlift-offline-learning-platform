<?php

/**
 * Educator Dashboard
 * LearnLift - Offline-First Education Platform
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireEducator();

$userId = getCurrentUserId();
$userName = getCurrentUserName();

// Get statistics
try {
    // Count lessons created
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM lessons WHERE educator_id = ?");
    $stmt->execute([$userId]);
    $totalLessons = $stmt->fetch()['count'];

    // Count published lessons
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM lessons WHERE educator_id = ? AND is_published = 1");
    $stmt->execute([$userId]);
    $publishedLessons = $stmt->fetch()['count'];

    // Count quizzes created
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM quizzes WHERE educator_id = ?");
    $stmt->execute([$userId]);
    $totalQuizzes = $stmt->fetch()['count'];

    // Count total quiz attempts
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as count
        FROM quiz_results qr
        JOIN quizzes q ON qr.quiz_id = q.id
        WHERE q.educator_id = ?
    ");
    $stmt->execute([$userId]);
    $quizAttempts = $stmt->fetch()['count'];

    // Get recent lessons
    $stmt = $pdo->prepare("
        SELECT * FROM lessons
        WHERE educator_id = ?
        ORDER BY created_at DESC
        LIMIT 5
    ");
    $stmt->execute([$userId]);
    $recentLessons = $stmt->fetchAll();

    // Get recent quiz results
    $stmt = $pdo->prepare("
        SELECT qr.*, q.title as quiz_title, u.name as student_name
        FROM quiz_results qr
        JOIN quizzes q ON qr.quiz_id = q.id
        JOIN users u ON qr.student_id = u.id
        WHERE q.educator_id = ?
        ORDER BY qr.submitted_at DESC
        LIMIT 10
    ");
    $stmt->execute([$userId]);
    $recentResults = $stmt->fetchAll();

    // Get average quiz scores
    $stmt = $pdo->prepare("
        SELECT AVG(qr.percentage) as avg_score
        FROM quiz_results qr
        JOIN quizzes q ON qr.quiz_id = q.id
        WHERE q.educator_id = ?
    ");
    $stmt->execute([$userId]);
    $avgScore = round($stmt->fetch()['avg_score'] ?? 0, 1);
} catch (PDOException $e) {
    error_log("Dashboard error: " . $e->getMessage());
    $error = "Failed to load dashboard data";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Educator Dashboard - LearnLift</title>
    <link rel="stylesheet" href="/LearnLift/assets/css/style.css">
</head>

<body>
    <nav class="navbar">
        <div class="container navbar-container">
            <a href="/LearnLift/" class="navbar-brand">LearnLift</a>
            <button class="navbar-toggle" aria-label="Toggle navigation">☰</button>
            <ul class="navbar-menu">
                <li><a href="/LearnLift/educator/dashboard.php" class="active">Dashboard</a></li>
                <li><a href="/LearnLift/educator/lessons.php">My Lessons</a></li>
                <li><a href="/LearnLift/educator/quizzes.php">My Quizzes</a></li>
                <li><a href="/LearnLift/educator/students.php">Students</a></li>
                <li><a href="/LearnLift/profile.php">Profile</a></li>
                <li><span id="online-status" class="status-indicator"></span></li>
                <li><button class="btn btn-sm btn-outline theme-toggle" title="Toggle Dark Mode" style="margin-right: 10px;">🌙</button></li>
                <li><a href="/LearnLift/api/auth.php?action=logout">Logout</a></li>
            </ul>
        </div>
    </nav>

    <div style="background: var(--gradient-primary); color: var(--white); padding: var(--spacing-xl) 0; margin-bottom: var(--spacing-xl);">
        <div class="container">
            <h1>Welcome, <?php echo htmlspecialchars($userName); ?>! 👨‍🏫</h1>
            <p>Manage your lessons and track student progress</p>
        </div>
    </div>

    <div class="container">
        <!-- Statistics -->
        <div class="row mb-4">
            <div class="col-3">
                <div class="card text-center">
                    <div class="card-body">
                        <div style="font-size: 2.5rem; font-weight: 700; color: var(--primary);">
                            <?php echo $totalLessons; ?>
                        </div>
                        <div style="color: var(--gray); font-size: 0.875rem; text-transform: uppercase;">
                            Total Lessons
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-3">
                <div class="card text-center">
                    <div class="card-body">
                        <div style="font-size: 2.5rem; font-weight: 700; color: var(--success);">
                            <?php echo $publishedLessons; ?>
                        </div>
                        <div style="color: var(--gray); font-size: 0.875rem; text-transform: uppercase;">
                            Published
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-3">
                <div class="card text-center">
                    <div class="card-body">
                        <div style="font-size: 2.5rem; font-weight: 700; color: var(--secondary);">
                            <?php echo $totalQuizzes; ?>
                        </div>
                        <div style="color: var(--gray); font-size: 0.875rem; text-transform: uppercase;">
                            Quizzes Created
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-3">
                <div class="card text-center">
                    <div class="card-body">
                        <div style="font-size: 2.5rem; font-weight: 700; color: var(--info);">
                            <?php echo $avgScore; ?>%
                        </div>
                        <div style="color: var(--gray); font-size: 0.875rem; text-transform: uppercase;">
                            Avg Student Score
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Recent Lessons -->
            <div class="col-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">My Recent Lessons</h3>
                    </div>
                    <div class="card-body">
                        <?php if (empty($recentLessons)): ?>
                            <p class="text-center" style="color: var(--gray);">No lessons created yet</p>
                        <?php else: ?>
                            <?php foreach ($recentLessons as $lesson): ?>
                                <div style="padding: var(--spacing-md); border-bottom: 1px solid var(--gray-lighter);">
                                    <div style="display: flex; justify-content: space-between; align-items: center;">
                                        <div>
                                            <h4 style="margin-bottom: var(--spacing-xs);">
                                                <?php echo htmlspecialchars($lesson['title']); ?>
                                            </h4>
                                            <div style="font-size: 0.875rem; color: var(--gray);">
                                                <?php echo formatDate($lesson['created_at']); ?>
                                            </div>
                                        </div>
                                        <div>
                                            <?php if ($lesson['is_published']): ?>
                                                <span class="badge badge-success">Published</span>
                                            <?php else: ?>
                                                <span class="badge badge-warning">Draft</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    <div class="card-footer">
                        <a href="/LearnLift/educator/lessons.php" class="btn btn-primary btn-block">
                            Manage Lessons
                        </a>
                    </div>
                </div>
            </div>

            <!-- Recent Quiz Results -->
            <div class="col-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Recent Quiz Results</h3>
                    </div>
                    <div class="card-body">
                        <?php if (empty($recentResults)): ?>
                            <p class="text-center" style="color: var(--gray);">No quiz results yet</p>
                        <?php else: ?>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Student</th>
                                        <th>Quiz</th>
                                        <th>Score</th>
                                        <th>Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recentResults as $result): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($result['student_name']); ?></td>
                                            <td><?php echo htmlspecialchars($result['quiz_title']); ?></td>
                                            <td>
                                                <span class="badge <?php echo $result['percentage'] >= 70 ? 'badge-success' : 'badge-warning'; ?>">
                                                    <?php echo round($result['percentage'], 1); ?>%
                                                </span>
                                            </td>
                                            <td><?php echo timeAgo($result['submitted_at']); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                    <div class="card-footer">
                        <a href="/LearnLift/educator/students.php" class="btn btn-outline btn-block">
                            View All Results
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="card mt-4">
            <div class="card-header">
                <h3 class="card-title">Quick Actions</h3>
            </div>
            <div class="card-body">
                <div style="display: flex; gap: var(--spacing-md); flex-wrap: wrap;">
                    <a href="/LearnLift/educator/lessons.php?action=create" class="btn btn-primary">
                        📝 Create New Lesson
                    </a>
                    <a href="/LearnLift/educator/quizzes.php?action=create" class="btn btn-secondary">
                        ✅ Create New Quiz
                    </a>
                    <a href="/LearnLift/educator/students.php" class="btn btn-info">
                        👥 View Student Progress
                    </a>
                </div>
            </div>
        </div>
    </div>

    <script src="/LearnLift/assets/js/main.js"></script>
    <script src="/LearnLift/assets/js/offline.js"></script>
    <script src="/LearnLift/assets/js/sync.js"></script>
</body>

</html>