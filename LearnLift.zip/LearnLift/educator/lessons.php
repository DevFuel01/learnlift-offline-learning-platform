<?php

/**
 * Educator Lesson Management
 * LearnLift - Offline-First Education Platform
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireEducator();

$userId = getCurrentUserId();
$error = '';
$success = '';

// Handle lesson creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_lesson'])) {
    $title = sanitize($_POST['title'] ?? '');
    $description = sanitize($_POST['description'] ?? '');
    $content = sanitize($_POST['content'] ?? '');
    $isPublished = isset($_POST['is_published']) ? 1 : 0;
    $csrfToken = $_POST['csrf_token'] ?? '';

    if (!verifyCSRFToken($csrfToken)) {
        $error = 'Invalid security token';
    } elseif (empty($title)) {
        $error = 'Title is required';
    } else {
        try {
            // Handle file upload
            $filePath = null;
            $fileType = null;
            $fileSize = null;

            if (isset($_FILES['lesson_file']) && $_FILES['lesson_file']['error'] === UPLOAD_ERR_OK) {
                $allowedTypes = ['pdf', 'doc', 'docx', 'txt', 'mp4', 'mp3', 'jpg', 'jpeg', 'png'];
                $errors = validateFileUpload($_FILES['lesson_file'], $allowedTypes, 50 * 1024 * 1024); // 50MB

                if (empty($errors)) {
                    $uploadDir = __DIR__ . '/../assets/uploads/lessons/';
                    if (!is_dir($uploadDir)) {
                        mkdir($uploadDir, 0755, true);
                    }

                    $fileName = generateUniqueFilename($_FILES['lesson_file']['name']);
                    $uploadPath = $uploadDir . $fileName;

                    if (move_uploaded_file($_FILES['lesson_file']['tmp_name'], $uploadPath)) {
                        $filePath = 'assets/uploads/lessons/' . $fileName;
                        $fileType = strtolower(pathinfo($_FILES['lesson_file']['name'], PATHINFO_EXTENSION));
                        $fileSize = $_FILES['lesson_file']['size'];
                    } else {
                        $error = 'Failed to upload file';
                    }
                } else {
                    $error = implode(', ', $errors);
                }
            }

            if (!$error) {
                $stmt = $pdo->prepare("
                    INSERT INTO lessons (title, description, content, file_path, file_type, file_size, educator_id, is_published)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([$title, $description, $content, $filePath, $fileType, $fileSize, $userId, $isPublished]);

                $success = 'Lesson created successfully!';
            }
        } catch (PDOException $e) {
            error_log("Lesson creation error: " . $e->getMessage());
            $error = 'Failed to create lesson';
        }
    }
}

// Handle lesson update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_lesson'])) {
    $lessonId = (int)$_POST['lesson_id'];
    $title = sanitize($_POST['title'] ?? '');
    $description = sanitize($_POST['description'] ?? '');
    $content = sanitize($_POST['content'] ?? '');
    $isPublished = isset($_POST['is_published']) ? 1 : 0;
    $csrfToken = $_POST['csrf_token'] ?? '';

    if (!verifyCSRFToken($csrfToken)) {
        $error = 'Invalid security token';
    } elseif (empty($title)) {
        $error = 'Title is required';
    } else {
        try {
            // Verify ownership
            $stmt = $pdo->prepare("SELECT id FROM lessons WHERE id = ? AND educator_id = ?");
            $stmt->execute([$lessonId, $userId]);

            if ($stmt->fetch()) {
                $stmt = $pdo->prepare("
                    UPDATE lessons 
                    SET title = ?, description = ?, content = ?, is_published = ?
                    WHERE id = ? AND educator_id = ?
                ");
                $stmt->execute([$title, $description, $content, $isPublished, $lessonId, $userId]);

                $success = 'Lesson updated successfully!';
            } else {
                $error = 'Lesson not found or access denied';
            }
        } catch (PDOException $e) {
            error_log("Lesson update error: " . $e->getMessage());
            $error = 'Failed to update lesson';
        }
    }
}

// Handle lesson deletion
if (isset($_GET['delete']) && isset($_GET['confirm'])) {
    $lessonId = (int)$_GET['delete'];

    try {
        // Verify ownership and get file path
        $stmt = $pdo->prepare("SELECT file_path FROM lessons WHERE id = ? AND educator_id = ?");
        $stmt->execute([$lessonId, $userId]);
        $lesson = $stmt->fetch();

        if ($lesson) {
            // Delete file if exists
            if ($lesson['file_path'] && file_exists(__DIR__ . '/../' . $lesson['file_path'])) {
                unlink(__DIR__ . '/../' . $lesson['file_path']);
            }

            // Delete lesson
            $stmt = $pdo->prepare("DELETE FROM lessons WHERE id = ? AND educator_id = ?");
            $stmt->execute([$lessonId, $userId]);

            $success = 'Lesson deleted successfully!';
        } else {
            $error = 'Lesson not found or access denied';
        }
    } catch (PDOException $e) {
        error_log("Lesson deletion error: " . $e->getMessage());
        $error = 'Failed to delete lesson';
    }
}

// Handle publish/unpublish toggle
if (isset($_GET['toggle_publish'])) {
    $lessonId = (int)$_GET['toggle_publish'];

    try {
        $stmt = $pdo->prepare("SELECT is_published FROM lessons WHERE id = ? AND educator_id = ?");
        $stmt->execute([$lessonId, $userId]);
        $lesson = $stmt->fetch();

        if ($lesson) {
            $newStatus = $lesson['is_published'] ? 0 : 1;
            $stmt = $pdo->prepare("UPDATE lessons SET is_published = ? WHERE id = ? AND educator_id = ?");
            $stmt->execute([$newStatus, $lessonId, $userId]);

            $success = $newStatus ? 'Lesson published!' : 'Lesson unpublished!';
        }
    } catch (PDOException $e) {
        error_log("Toggle publish error: " . $e->getMessage());
        $error = 'Failed to update lesson status';
    }
}

// Get all lessons for this educator
try {
    $stmt = $pdo->prepare("
        SELECT * FROM lessons
        WHERE educator_id = ?
        ORDER BY created_at DESC
    ");
    $stmt->execute([$userId]);
    $lessons = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Lessons fetch error: " . $e->getMessage());
    $error = "Failed to load lessons";
}

// Get lesson for editing
$editLesson = null;
if (isset($_GET['edit'])) {
    $editId = (int)$_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM lessons WHERE id = ? AND educator_id = ?");
    $stmt->execute([$editId, $userId]);
    $editLesson = $stmt->fetch();
}

$csrfToken = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Lessons - LearnLift</title>
    <link rel="stylesheet" href="/LearnLift/assets/css/style.css">
    <style>
        .lesson-table {
            width: 100%;
        }

        .lesson-actions {
            display: flex;
            gap: var(--spacing-xs);
        }

        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 9999;
            align-items: center;
            justify-content: center;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: var(--white);
            padding: var(--spacing-xl);
            border-radius: var(--radius-lg);
            max-width: 600px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
        }
    </style>
</head>

<body>
    <nav class="navbar">
        <div class="container navbar-container">
            <a href="/LearnLift/" class="navbar-brand">LearnLift</a>
            <button class="navbar-toggle" aria-label="Toggle navigation">☰</button>
            <ul class="navbar-menu">
                <li><a href="/LearnLift/educator/dashboard.php">Dashboard</a></li>
                <li><a href="/LearnLift/educator/lessons.php" class="active">My Lessons</a></li>
                <li><a href="/LearnLift/educator/quizzes.php">My Quizzes</a></li>
                <li><a href="/LearnLift/educator/students.php">Students</a></li>
                <li><a href="/LearnLift/profile.php">Profile</a></li>
                <li><button class="btn btn-sm btn-outline theme-toggle" title="Toggle Dark Mode" style="margin-right: 10px;">🌙</button></li>
                <li><a href="/LearnLift/api/auth.php?action=logout">Logout</a></li>
            </ul>
        </div>
    </nav>

    <div class="container" style="margin-top: var(--spacing-xl);">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: var(--spacing-xl);">
            <h1>My Lessons</h1>
            <button onclick="openCreateModal()" class="btn btn-primary">
                ➕ Create New Lesson
            </button>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>

        <!-- Lessons Table -->
        <div class="card">
            <div class="card-body">
                <?php if (empty($lessons)): ?>
                    <div class="text-center" style="padding: var(--spacing-2xl);">
                        <h3>No Lessons Yet</h3>
                        <p>Create your first lesson to get started!</p>
                        <button onclick="openCreateModal()" class="btn btn-primary mt-3">
                            Create Lesson
                        </button>
                    </div>
                <?php else: ?>
                    <table class="table lesson-table">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Status</th>
                                <th>File</th>
                                <th>Created</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($lessons as $lesson): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars($lesson['title']); ?></strong>
                                        <?php if ($lesson['description']): ?>
                                            <div style="font-size: 0.875rem; color: var(--gray);">
                                                <?php echo htmlspecialchars(substr($lesson['description'], 0, 100)); ?>
                                                <?php echo strlen($lesson['description']) > 100 ? '...' : ''; ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($lesson['is_published']): ?>
                                            <span class="badge badge-success">Published</span>
                                        <?php else: ?>
                                            <span class="badge badge-warning">Draft</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($lesson['file_path']): ?>
                                            <span class="badge badge-info">
                                                <?php echo strtoupper($lesson['file_type'] ?? 'file'); ?>
                                            </span>
                                        <?php else: ?>
                                            <span style="color: var(--gray);">No file</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo formatDate($lesson['created_at']); ?></td>
                                    <td>
                                        <div class="lesson-actions">
                                            <a href="?toggle_publish=<?php echo $lesson['id']; ?>"
                                                class="btn btn-sm <?php echo $lesson['is_published'] ? 'btn-warning' : 'btn-success'; ?>"
                                                title="<?php echo $lesson['is_published'] ? 'Unpublish' : 'Publish'; ?>">
                                                <?php echo $lesson['is_published'] ? '👁️' : '📢'; ?>
                                            </a>
                                            <button onclick="openEditModal(<?php echo htmlspecialchars(json_encode($lesson)); ?>)"
                                                class="btn btn-sm btn-primary" title="Edit">
                                                ✏️
                                            </button>
                                            <button onclick="confirmDelete(<?php echo $lesson['id']; ?>, '<?php echo htmlspecialchars($lesson['title']); ?>')"
                                                class="btn btn-sm btn-danger" title="Delete">
                                                🗑️
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Create Lesson Modal -->
    <div id="createModal" class="modal">
        <div class="modal-content">
            <h2>Create New Lesson</h2>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="create_lesson" value="1">
                <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">

                <div class="form-group">
                    <label class="form-label">Title *</label>
                    <input type="text" name="title" class="form-control" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Description</label>
                    <textarea name="description" class="form-control" rows="3"></textarea>
                </div>

                <div class="form-group">
                    <label class="form-label">Content *</label>
                    <textarea name="content" class="form-control" rows="8" required></textarea>
                </div>

                <div class="form-group">
                    <label class="form-label">Attach File (Optional)</label>
                    <input type="file" name="lesson_file" class="form-control"
                        accept=".pdf,.doc,.docx,.txt,.mp4,.mp3,.jpg,.jpeg,.png">
                    <small style="color: var(--gray);">Allowed: PDF, DOC, TXT, MP4, MP3, Images (Max 50MB)</small>
                </div>

                <div class="form-check">
                    <input type="checkbox" name="is_published" id="create_published" class="form-check-input">
                    <label for="create_published">Publish immediately</label>
                </div>

                <div style="display: flex; gap: var(--spacing-md); margin-top: var(--spacing-lg);">
                    <button type="submit" class="btn btn-primary">Create Lesson</button>
                    <button type="button" onclick="closeCreateModal()" class="btn btn-outline">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Lesson Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <h2>Edit Lesson</h2>
            <form method="POST" id="editForm">
                <input type="hidden" name="update_lesson" value="1">
                <input type="hidden" name="lesson_id" id="edit_lesson_id">
                <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">

                <div class="form-group">
                    <label class="form-label">Title *</label>
                    <input type="text" name="title" id="edit_title" class="form-control" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Description</label>
                    <textarea name="description" id="edit_description" class="form-control" rows="3"></textarea>
                </div>

                <div class="form-group">
                    <label class="form-label">Content *</label>
                    <textarea name="content" id="edit_content" class="form-control" rows="8" required></textarea>
                </div>

                <div class="form-check">
                    <input type="checkbox" name="is_published" id="edit_published" class="form-check-input">
                    <label for="edit_published">Published</label>
                </div>

                <div style="display: flex; gap: var(--spacing-md); margin-top: var(--spacing-lg);">
                    <button type="submit" class="btn btn-primary">Update Lesson</button>
                    <button type="button" onclick="closeEditModal()" class="btn btn-outline">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <script src="/LearnLift/assets/js/main.js"></script>
    <script>
        function openCreateModal() {
            document.getElementById('createModal').classList.add('active');
        }

        function closeCreateModal() {
            document.getElementById('createModal').classList.remove('active');
        }

        function openEditModal(lesson) {
            document.getElementById('edit_lesson_id').value = lesson.id;
            document.getElementById('edit_title').value = lesson.title;
            document.getElementById('edit_description').value = lesson.description || '';
            document.getElementById('edit_content').value = lesson.content || '';
            document.getElementById('edit_published').checked = lesson.is_published == 1;
            document.getElementById('editModal').classList.add('active');
        }

        function closeEditModal() {
            document.getElementById('editModal').classList.remove('active');
        }

        function confirmDelete(id, title) {
            if (confirm(`Are you sure you want to delete "${title}"?\n\nThis action cannot be undone.`)) {
                window.location.href = '?delete=' + id + '&confirm=1';
            }
        }

        // Close modals on outside click
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.classList.remove('active');
            }
        }
    </script>
    <script src="/LearnLift/assets/js/main.js"></script>
</body>

</html>