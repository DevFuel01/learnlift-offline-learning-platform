<?php

/**
 * Educator Quiz Management
 * LearnLift - Offline-First Education Platform
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireEducator();

$userId = getCurrentUserId();
$error = '';
$success = '';

// Handle quiz creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_quiz'])) {
    $lessonId = (int)$_POST['lesson_id'];
    $title = sanitize($_POST['title'] ?? '');
    $description = sanitize($_POST['description'] ?? '');
    $timeLimit = (int)($_POST['time_limit'] ?? 0);
    $passPercentage = (int)($_POST['pass_percentage'] ?? 70);
    $csrfToken = $_POST['csrf_token'] ?? '';

    if (!verifyCSRFToken($csrfToken)) {
        $error = 'Invalid security token';
    } elseif (empty($title)) {
        $error = 'Title is required';
    } else {
        try {
            // Verify lesson ownership
            $stmt = $pdo->prepare("SELECT id FROM lessons WHERE id = ? AND educator_id = ?");
            $stmt->execute([$lessonId, $userId]);

            if (!$stmt->fetch()) {
                $error = 'Invalid lesson selected';
            } else {
                // Create quiz
                $stmt = $pdo->prepare("
                    INSERT INTO quizzes (lesson_id, educator_id, title, description, time_limit, pass_percentage)
                    VALUES (?, ?, ?, ?, ?, ?)
                ");
                $stmt->execute([$lessonId, $userId, $title, $description, $timeLimit, $passPercentage]);
                $quizId = $pdo->lastInsertId();

                // Add questions
                if (isset($_POST['questions']) && is_array($_POST['questions'])) {
                    $order = 1;
                    foreach ($_POST['questions'] as $q) {
                        if (!empty($q['question'])) {
                            $stmt = $pdo->prepare("
                                INSERT INTO quiz_questions 
                                (quiz_id, question, option_a, option_b, option_c, option_d, correct_answer, points, question_order)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                            ");
                            $stmt->execute([
                                $quizId,
                                sanitize($q['question']),
                                sanitize($q['option_a'] ?? ''),
                                sanitize($q['option_b'] ?? ''),
                                sanitize($q['option_c'] ?? ''),
                                sanitize($q['option_d'] ?? ''),
                                strtolower($q['correct_answer'] ?? 'a'),
                                (int)($q['points'] ?? 1),
                                $order++
                            ]);
                        }
                    }
                }

                $success = 'Quiz created successfully!';
            }
        } catch (PDOException $e) {
            error_log("Quiz creation error: " . $e->getMessage());
            $error = 'Failed to create quiz';
        }
    }
}

// Handle quiz update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_quiz'])) {
    $quizId = (int)$_POST['quiz_id'];
    $title = sanitize($_POST['title'] ?? '');
    $description = sanitize($_POST['description'] ?? '');
    $timeLimit = (int)($_POST['time_limit'] ?? 0);
    $passPercentage = (int)($_POST['pass_percentage'] ?? 70);
    $csrfToken = $_POST['csrf_token'] ?? '';

    if (!verifyCSRFToken($csrfToken)) {
        $error = 'Invalid security token';
    } elseif (empty($title)) {
        $error = 'Title is required';
    } else {
        try {
            // Verify ownership
            $stmt = $pdo->prepare("SELECT id FROM quizzes WHERE id = ? AND educator_id = ?");
            $stmt->execute([$quizId, $userId]);

            if ($stmt->fetch()) {
                // Update quiz
                $stmt = $pdo->prepare("
                    UPDATE quizzes 
                    SET title = ?, description = ?, time_limit = ?, pass_percentage = ?
                    WHERE id = ? AND educator_id = ?
                ");
                $stmt->execute([$title, $description, $timeLimit, $passPercentage, $quizId, $userId]);

                // Delete existing questions
                $stmt = $pdo->prepare("DELETE FROM quiz_questions WHERE quiz_id = ?");
                $stmt->execute([$quizId]);

                // Add updated questions
                if (isset($_POST['questions']) && is_array($_POST['questions'])) {
                    $order = 1;
                    foreach ($_POST['questions'] as $q) {
                        if (!empty($q['question'])) {
                            $stmt = $pdo->prepare("
                                INSERT INTO quiz_questions 
                                (quiz_id, question, option_a, option_b, option_c, option_d, correct_answer, points, question_order)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                            ");
                            $stmt->execute([
                                $quizId,
                                sanitize($q['question']),
                                sanitize($q['option_a'] ?? ''),
                                sanitize($q['option_b'] ?? ''),
                                sanitize($q['option_c'] ?? ''),
                                sanitize($q['option_d'] ?? ''),
                                strtolower($q['correct_answer'] ?? 'a'),
                                (int)($q['points'] ?? 1),
                                $order++
                            ]);
                        }
                    }
                }

                $success = 'Quiz updated successfully!';
            } else {
                $error = 'Quiz not found or access denied';
            }
        } catch (PDOException $e) {
            error_log("Quiz update error: " . $e->getMessage());
            $error = 'Failed to update quiz';
        }
    }
}

// Handle quiz deletion
if (isset($_GET['delete']) && isset($_GET['confirm'])) {
    $quizId = (int)$_GET['delete'];

    try {
        $stmt = $pdo->prepare("SELECT id FROM quizzes WHERE id = ? AND educator_id = ?");
        $stmt->execute([$quizId, $userId]);

        if ($stmt->fetch()) {
            $stmt = $pdo->prepare("DELETE FROM quizzes WHERE id = ? AND educator_id = ?");
            $stmt->execute([$quizId, $userId]);

            $success = 'Quiz deleted successfully!';
        } else {
            $error = 'Quiz not found or access denied';
        }
    } catch (PDOException $e) {
        error_log("Quiz deletion error: " . $e->getMessage());
        $error = 'Failed to delete quiz';
    }
}

// Get all quizzes for this educator
try {
    $stmt = $pdo->prepare("
        SELECT q.*, l.title as lesson_title,
               (SELECT COUNT(*) FROM quiz_questions WHERE quiz_id = q.id) as question_count,
               (SELECT COUNT(*) FROM quiz_results WHERE quiz_id = q.id) as attempt_count
        FROM quizzes q
        JOIN lessons l ON q.lesson_id = l.id
        WHERE q.educator_id = ?
        ORDER BY q.created_at DESC
    ");
    $stmt->execute([$userId]);
    $quizzes = $stmt->fetchAll();

    // Get educator's lessons for dropdown
    $stmt = $pdo->prepare("SELECT id, title FROM lessons WHERE educator_id = ? ORDER BY title");
    $stmt->execute([$userId]);
    $lessons = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Quizzes fetch error: " . $e->getMessage());
    $error = "Failed to load quizzes";
}

// Get quiz for editing
$editQuiz = null;
$editQuestions = [];
if (isset($_GET['edit'])) {
    $editId = (int)$_GET['edit'];
    $stmt = $pdo->prepare("SELECT * FROM quizzes WHERE id = ? AND educator_id = ?");
    $stmt->execute([$editId, $userId]);
    $editQuiz = $stmt->fetch();

    if ($editQuiz) {
        $stmt = $pdo->prepare("SELECT * FROM quiz_questions WHERE quiz_id = ? ORDER BY question_order");
        $stmt->execute([$editId]);
        $editQuestions = $stmt->fetchAll();
    }
}

$csrfToken = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Quizzes - LearnLift</title>
    <link rel="stylesheet" href="/LearnLift/assets/css/style.css">
    <style>
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 9999;
            align-items: center;
            justify-content: center;
            overflow-y: auto;
        }

        .modal.active {
            display: flex;
        }

        .modal-content {
            background: var(--white);
            padding: var(--spacing-xl);
            border-radius: var(--radius-lg);
            max-width: 800px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
            margin: var(--spacing-xl) 0;
        }

        .question-item {
            border: 2px solid var(--gray-light);
            border-radius: var(--radius-md);
            padding: var(--spacing-md);
            margin-bottom: var(--spacing-md);
            position: relative;
        }

        .question-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: var(--spacing-md);
        }

        .remove-question {
            background: var(--danger);
            color: var(--white);
            border: none;
            padding: var(--spacing-xs) var(--spacing-sm);
            border-radius: var(--radius-sm);
            cursor: pointer;
        }

        .option-group {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: var(--spacing-sm);
        }
    </style>
</head>

<body>
    <nav class="navbar">
        <div class="container navbar-container">
            <a href="/LearnLift/" class="navbar-brand">LearnLift</a>
            <button class="navbar-toggle" aria-label="Toggle navigation">☰</button>
            <ul class="navbar-menu">
                <li><a href="/LearnLift/educator/dashboard.php">Dashboard</a></li>
                <li><a href="/LearnLift/educator/lessons.php">My Lessons</a></li>
                <li><a href="/LearnLift/educator/quizzes.php" class="active">My Quizzes</a></li>
                <li><a href="/LearnLift/educator/students.php">Students</a></li>
                <li><a href="/LearnLift/profile.php">Profile</a></li>
                <li><button class="btn btn-sm btn-outline theme-toggle" title="Toggle Dark Mode" style="margin-right: 10px;">🌙</button></li>
                <li><a href="/LearnLift/api/auth.php?action=logout">Logout</a></li>
            </ul>
        </div>
    </nav>

    <div class="container" style="margin-top: var(--spacing-xl);">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: var(--spacing-xl);">
            <h1>My Quizzes</h1>
            <button onclick="openCreateModal()" class="btn btn-primary">
                ➕ Create New Quiz
            </button>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <?php if ($success): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>

        <?php if (empty($lessons)): ?>
            <div class="alert alert-warning">
                <strong>Note:</strong> You need to create lessons first before you can create quizzes.
                <a href="/LearnLift/educator/lessons.php" class="btn btn-sm btn-primary" style="margin-left: var(--spacing-md);">
                    Create Lesson
                </a>
            </div>
        <?php endif; ?>

        <!-- Quizzes Table -->
        <div class="card">
            <div class="card-body">
                <?php if (empty($quizzes)): ?>
                    <div class="text-center" style="padding: var(--spacing-2xl);">
                        <h3>No Quizzes Yet</h3>
                        <p>Create your first quiz to assess student learning!</p>
                        <?php if (!empty($lessons)): ?>
                            <button onclick="openCreateModal()" class="btn btn-primary mt-3">
                                Create Quiz
                            </button>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Lesson</th>
                                <th>Questions</th>
                                <th>Attempts</th>
                                <th>Time Limit</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($quizzes as $quiz): ?>
                                <tr>
                                    <td>
                                        <strong><?php echo htmlspecialchars($quiz['title']); ?></strong>
                                        <?php if ($quiz['description']): ?>
                                            <div style="font-size: 0.875rem; color: var(--gray);">
                                                <?php echo htmlspecialchars(substr($quiz['description'], 0, 80)); ?>
                                                <?php echo strlen($quiz['description']) > 80 ? '...' : ''; ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($quiz['lesson_title']); ?></td>
                                    <td>
                                        <span class="badge badge-info">
                                            <?php echo $quiz['question_count']; ?> questions
                                        </span>
                                    </td>
                                    <td><?php echo $quiz['attempt_count']; ?> attempts</td>
                                    <td><?php echo $quiz['time_limit'] > 0 ? $quiz['time_limit'] . ' min' : 'No limit'; ?></td>
                                    <td>
                                        <div style="display: flex; gap: var(--spacing-xs);">
                                            <button onclick="editQuiz(<?php echo $quiz['id']; ?>)"
                                                class="btn btn-sm btn-primary" title="Edit">
                                                ✏️
                                            </button>
                                            <button onclick="confirmDelete(<?php echo $quiz['id']; ?>, '<?php echo htmlspecialchars($quiz['title']); ?>')"
                                                class="btn btn-sm btn-danger" title="Delete">
                                                🗑️
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Create Quiz Modal -->
    <div id="createModal" class="modal">
        <div class="modal-content">
            <h2>Create New Quiz</h2>
            <form method="POST" id="createForm">
                <input type="hidden" name="create_quiz" value="1">
                <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">

                <div class="form-group">
                    <label class="form-label">Select Lesson *</label>
                    <select name="lesson_id" class="form-control" required>
                        <option value="">-- Select a lesson --</option>
                        <?php foreach ($lessons as $lesson): ?>
                            <option value="<?php echo $lesson['id']; ?>">
                                <?php echo htmlspecialchars($lesson['title']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label class="form-label">Quiz Title *</label>
                    <input type="text" name="title" class="form-control" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Description</label>
                    <textarea name="description" class="form-control" rows="2"></textarea>
                </div>

                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-label">Time Limit (minutes)</label>
                            <input type="number" name="time_limit" class="form-control" value="0" min="0">
                            <small style="color: var(--gray);">0 = No time limit</small>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label class="form-label">Pass Percentage</label>
                            <input type="number" name="pass_percentage" class="form-control" value="70" min="0" max="100">
                        </div>
                    </div>
                </div>

                <hr>
                <h3>Questions</h3>
                <div id="questionsContainer"></div>

                <button type="button" onclick="addQuestion()" class="btn btn-outline btn-block mb-3">
                    ➕ Add Question
                </button>

                <div style="display: flex; gap: var(--spacing-md); margin-top: var(--spacing-lg);">
                    <button type="submit" class="btn btn-primary">Create Quiz</button>
                    <button type="button" onclick="closeCreateModal()" class="btn btn-outline">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <script src="/LearnLift/assets/js/main.js"></script>
    <script>
        let questionCount = 0;

        function openCreateModal() {
            document.getElementById('createModal').classList.add('active');
            document.getElementById('questionsContainer').innerHTML = '';
            questionCount = 0;
            addQuestion();
        }

        function closeCreateModal() {
            document.getElementById('createModal').classList.remove('active');
        }

        function addQuestion() {
            questionCount++;
            const container = document.getElementById('questionsContainer');
            const questionHtml = `
                <div class="question-item" id="question-${questionCount}">
                    <div class="question-header">
                        <strong>Question ${questionCount}</strong>
                        <button type="button" class="remove-question" onclick="removeQuestion(${questionCount})">
                            Remove
                        </button>
                    </div>
                    
                    <div class="form-group">
                        <label class="form-label">Question Text *</label>
                        <textarea name="questions[${questionCount}][question]" class="form-control" rows="2" required></textarea>
                    </div>
                    
                    <div class="option-group">
                        <div class="form-group">
                            <label class="form-label">Option A *</label>
                            <input type="text" name="questions[${questionCount}][option_a]" class="form-control" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Option B *</label>
                            <input type="text" name="questions[${questionCount}][option_b]" class="form-control" required>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Option C</label>
                            <input type="text" name="questions[${questionCount}][option_c]" class="form-control">
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label">Option D</label>
                            <input type="text" name="questions[${questionCount}][option_d]" class="form-control">
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label class="form-label">Correct Answer *</label>
                                <select name="questions[${questionCount}][correct_answer]" class="form-control" required>
                                    <option value="a">A</option>
                                    <option value="b">B</option>
                                    <option value="c">C</option>
                                    <option value="d">D</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label class="form-label">Points</label>
                                <input type="number" name="questions[${questionCount}][points]" class="form-control" value="1" min="1">
                            </div>
                        </div>
                    </div>
                </div>
            `;
            container.insertAdjacentHTML('beforeend', questionHtml);
        }

        function removeQuestion(id) {
            const element = document.getElementById('question-' + id);
            if (element) {
                element.remove();
            }
        }

        function editQuiz(id) {
            window.location.href = '?edit=' + id;
        }

        function confirmDelete(id, title) {
            if (confirm(`Are you sure you want to delete "${title}"?\n\nThis will also delete all questions and student results.\n\nThis action cannot be undone.`)) {
                window.location.href = '?delete=' + id + '&confirm=1';
            }
        }

        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.classList.remove('active');
            }
        }

        <?php if ($editQuiz): ?>
            // Open edit modal with existing data
            document.addEventListener('DOMContentLoaded', function() {
                // Populate edit form (simplified - you'd need a full edit modal)
                alert('Edit functionality: Quiz ID <?php echo $editQuiz['id']; ?>. Full edit modal can be added similarly to create.');
            });
        <?php endif; ?>
    </script>
    <script src="/LearnLift/assets/js/main.js"></script>
</body>

</html>