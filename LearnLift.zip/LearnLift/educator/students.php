<?php

/**
 * Educator Student Progress Viewer
 * LearnLift - Offline-First Education Platform
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireEducator();

$userId = getCurrentUserId();

// Get individual student details if requested
$selectedStudent = null;
$studentQuizResults = [];
$studentStats = [];

if (isset($_GET['student_id'])) {
    $studentId = (int)$_GET['student_id'];

    try {
        // Get student info
        $stmt = $pdo->prepare("SELECT id, name, email, created_at FROM users WHERE id = ? AND role = 'student'");
        $stmt->execute([$studentId]);
        $selectedStudent = $stmt->fetch();

        if ($selectedStudent) {
            // Get quiz results for this educator's quizzes
            $stmt = $pdo->prepare("
                SELECT qr.*, q.title as quiz_title, l.title as lesson_title
                FROM quiz_results qr
                JOIN quizzes q ON qr.quiz_id = q.id
                JOIN lessons l ON q.lesson_id = l.id
                WHERE qr.student_id = ? AND q.educator_id = ?
                ORDER BY qr.submitted_at DESC
            ");
            $stmt->execute([$studentId, $userId]);
            $studentQuizResults = $stmt->fetchAll();

            // Calculate student statistics
            $stmt = $pdo->prepare("
                SELECT 
                    COUNT(*) as total_quizzes,
                    AVG(percentage) as avg_score,
                    MAX(percentage) as best_score,
                    MIN(percentage) as lowest_score
                FROM quiz_results qr
                JOIN quizzes q ON qr.quiz_id = q.id
                WHERE qr.student_id = ? AND q.educator_id = ?
            ");
            $stmt->execute([$studentId, $userId]);
            $studentStats = $stmt->fetch();

            // Get downloaded lessons
            $stmt = $pdo->prepare("
                SELECT l.title, dl.downloaded_at
                FROM downloaded_lessons dl
                JOIN lessons l ON dl.lesson_id = l.id
                WHERE dl.student_id = ? AND l.educator_id = ?
                ORDER BY dl.downloaded_at DESC
            ");
            $stmt->execute([$studentId, $userId]);
            $downloadedLessons = $stmt->fetchAll();
        }
    } catch (PDOException $e) {
        error_log("Student details error: " . $e->getMessage());
    }
}

// Get all students who have interacted with this educator's content
try {
    $stmt = $pdo->prepare("
        SELECT DISTINCT u.id, u.name, u.email,
               (SELECT COUNT(*) FROM quiz_results qr 
                JOIN quizzes q ON qr.quiz_id = q.id 
                WHERE qr.student_id = u.id AND q.educator_id = ?) as quiz_count,
               (SELECT AVG(percentage) FROM quiz_results qr 
                JOIN quizzes q ON qr.quiz_id = q.id 
                WHERE qr.student_id = u.id AND q.educator_id = ?) as avg_score,
               (SELECT MAX(qr.submitted_at) FROM quiz_results qr 
                JOIN quizzes q ON qr.quiz_id = q.id 
                WHERE qr.student_id = u.id AND q.educator_id = ?) as last_activity
        FROM users u
        WHERE u.role = 'student' 
        AND (
            EXISTS (
                SELECT 1 FROM quiz_results qr 
                JOIN quizzes q ON qr.quiz_id = q.id 
                WHERE qr.student_id = u.id AND q.educator_id = ?
            )
            OR EXISTS (
                SELECT 1 FROM downloaded_lessons dl
                JOIN lessons l ON dl.lesson_id = l.id
                WHERE dl.student_id = u.id AND l.educator_id = ?
            )
        )
        ORDER BY last_activity DESC
    ");
    $stmt->execute([$userId, $userId, $userId, $userId, $userId]);
    $students = $stmt->fetchAll();

    // Get recent quiz results across all students
    $stmt = $pdo->prepare("
        SELECT qr.*, q.title as quiz_title, u.name as student_name
        FROM quiz_results qr
        JOIN quizzes q ON qr.quiz_id = q.id
        JOIN users u ON qr.student_id = u.id
        WHERE q.educator_id = ?
        ORDER BY qr.submitted_at DESC
        LIMIT 20
    ");
    $stmt->execute([$userId]);
    $recentResults = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Students fetch error: " . $e->getMessage());
    $error = "Failed to load student data";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Progress - LearnLift</title>
    <link rel="stylesheet" href="/LearnLift/assets/css/style.css">
    <style>
        .student-card {
            cursor: pointer;
            transition: var(--transition);
        }

        .student-card:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }

        .stat-box {
            text-align: center;
            padding: var(--spacing-lg);
            background: var(--gray-lighter);
            border-radius: var(--radius-md);
        }

        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            color: var(--primary);
        }

        .progress-bar {
            width: 100%;
            height: 8px;
            background: var(--gray-lighter);
            border-radius: var(--radius-sm);
            overflow: hidden;
        }

        .progress-fill {
            height: 100%;
            background: var(--gradient-primary);
            transition: width 0.3s;
        }
    </style>
</head>

<body>
    <nav class="navbar">
        <div class="container navbar-container">
            <a href="/LearnLift/" class="navbar-brand">LearnLift</a>
            <button class="navbar-toggle" aria-label="Toggle navigation">☰</button>
            <ul class="navbar-menu">
                <li><a href="/LearnLift/educator/dashboard.php">Dashboard</a></li>
                <li><a href="/LearnLift/educator/lessons.php">My Lessons</a></li>
                <li><a href="/LearnLift/educator/quizzes.php">My Quizzes</a></li>
                <li><a href="/LearnLift/educator/students.php" class="active">Students</a></li>
                <li><a href="/LearnLift/profile.php">Profile</a></li>
                <li><button class="btn btn-sm btn-outline theme-toggle" title="Toggle Dark Mode" style="margin-right: 10px;">🌙</button></li>
                <li><a href="/LearnLift/api/auth.php?action=logout">Logout</a></li>
            </ul>
        </div>
    </nav>

    <div class="container" style="margin-top: var(--spacing-xl);">
        <?php if ($selectedStudent): ?>
            <!-- Individual Student View -->
            <div class="mb-4">
                <a href="/LearnLift/educator/students.php" class="btn btn-outline">← Back to All Students</a>
            </div>

            <div class="card mb-4">
                <div class="card-header">
                    <h2 class="card-title"><?php echo htmlspecialchars($selectedStudent['name']); ?></h2>
                    <p style="color: var(--gray); margin: 0;">
                        <?php echo htmlspecialchars($selectedStudent['email']); ?> •
                        Joined <?php echo formatDate($selectedStudent['created_at']); ?>
                    </p>
                </div>
            </div>

            <!-- Student Statistics -->
            <div class="row mb-4">
                <div class="col-3">
                    <div class="stat-box">
                        <div class="stat-value"><?php echo $studentStats['total_quizzes'] ?? 0; ?></div>
                        <div style="color: var(--gray); font-size: 0.875rem;">Quizzes Taken</div>
                    </div>
                </div>
                <div class="col-3">
                    <div class="stat-box">
                        <div class="stat-value"><?php echo round($studentStats['avg_score'] ?? 0, 1); ?>%</div>
                        <div style="color: var(--gray); font-size: 0.875rem;">Average Score</div>
                    </div>
                </div>
                <div class="col-3">
                    <div class="stat-box">
                        <div class="stat-value"><?php echo round($studentStats['best_score'] ?? 0, 1); ?>%</div>
                        <div style="color: var(--gray); font-size: 0.875rem;">Best Score</div>
                    </div>
                </div>
                <div class="col-3">
                    <div class="stat-box">
                        <div class="stat-value"><?php echo count($downloadedLessons ?? []); ?></div>
                        <div style="color: var(--gray); font-size: 0.875rem;">Lessons Downloaded</div>
                    </div>
                </div>
            </div>

            <!-- Quiz Results -->
            <div class="card mb-4">
                <div class="card-header">
                    <h3 class="card-title">Quiz Results</h3>
                </div>
                <div class="card-body">
                    <?php if (empty($studentQuizResults)): ?>
                        <p class="text-center" style="color: var(--gray);">No quiz results yet</p>
                    <?php else: ?>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Quiz</th>
                                    <th>Lesson</th>
                                    <th>Score</th>
                                    <th>Percentage</th>
                                    <th>Time Taken</th>
                                    <th>Submitted</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($studentQuizResults as $result): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($result['quiz_title']); ?></td>
                                        <td><?php echo htmlspecialchars($result['lesson_title']); ?></td>
                                        <td><?php echo (int)$result['score']; ?>/<?php echo $result['total_points']; ?></td>
                                        <td>
                                            <div style="display: flex; align-items: center; gap: var(--spacing-sm);">
                                                <span class="badge <?php echo $result['percentage'] >= 70 ? 'badge-success' : 'badge-warning'; ?>">
                                                    <?php echo round($result['percentage'], 1); ?>%
                                                </span>
                                                <div class="progress-bar" style="flex: 1;">
                                                    <div class="progress-fill" style="width: <?php echo $result['percentage']; ?>%;"></div>
                                                </div>
                                            </div>
                                        </td>
                                        <td><?php echo gmdate("i:s", $result['time_taken']); ?></td>
                                        <td><?php echo timeAgo($result['submitted_at']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Downloaded Lessons -->
            <?php if (!empty($downloadedLessons)): ?>
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Downloaded Lessons</h3>
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Lesson</th>
                                    <th>Downloaded</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($downloadedLessons as $lesson): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($lesson['title']); ?></td>
                                        <td><?php echo timeAgo($lesson['downloaded_at']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>

        <?php else: ?>
            <!-- All Students View -->
            <h1>Student Progress</h1>
            <p class="mb-4">Track student engagement and quiz performance</p>

            <?php if (empty($students)): ?>
                <div class="card text-center">
                    <div class="card-body" style="padding: var(--spacing-2xl);">
                        <h3>No Student Activity Yet</h3>
                        <p>Students will appear here once they take quizzes or download your lessons.</p>
                    </div>
                </div>
            <?php else: ?>
                <!-- Students Grid -->
                <div class="row mb-4">
                    <?php foreach ($students as $student): ?>
                        <div class="col-4">
                            <div class="card student-card" onclick="window.location.href='?student_id=<?php echo $student['id']; ?>'">
                                <div class="card-body">
                                    <h4><?php echo htmlspecialchars($student['name']); ?></h4>
                                    <p style="font-size: 0.875rem; color: var(--gray); margin-bottom: var(--spacing-md);">
                                        <?php echo htmlspecialchars($student['email']); ?>
                                    </p>

                                    <div style="display: flex; justify-content: space-between; margin-bottom: var(--spacing-sm);">
                                        <span style="color: var(--gray);">Quizzes:</span>
                                        <strong><?php echo $student['quiz_count']; ?></strong>
                                    </div>

                                    <div style="display: flex; justify-content: space-between; margin-bottom: var(--spacing-sm);">
                                        <span style="color: var(--gray);">Avg Score:</span>
                                        <strong><?php echo round($student['avg_score'] ?? 0, 1); ?>%</strong>
                                    </div>

                                    <?php if ($student['last_activity']): ?>
                                        <div style="font-size: 0.75rem; color: var(--gray); margin-top: var(--spacing-md);">
                                            Last active: <?php echo timeAgo($student['last_activity']); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Recent Quiz Results -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Recent Quiz Results</h3>
                    </div>
                    <div class="card-body">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Student</th>
                                    <th>Quiz</th>
                                    <th>Score</th>
                                    <th>Percentage</th>
                                    <th>Submitted</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recentResults as $result): ?>
                                    <tr>
                                        <td>
                                            <a href="?student_id=<?php echo $result['student_id']; ?>">
                                                <?php echo htmlspecialchars($result['student_name']); ?>
                                            </a>
                                        </td>
                                        <td><?php echo htmlspecialchars($result['quiz_title']); ?></td>
                                        <td><?php echo $result['score']; ?>/<?php echo $result['total_points']; ?></td>
                                        <td>
                                            <span class="badge <?php echo $result['percentage'] >= 70 ? 'badge-success' : 'badge-warning'; ?>">
                                                <?php echo round($result['percentage'], 1); ?>%
                                            </span>
                                        </td>
                                        <td><?php echo timeAgo($result['submitted_at']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <script src="/LearnLift/assets/js/main.js"></script>
    <script src="/LearnLift/assets/js/main.js"></script>
</body>

</html>