<?php

/**
 * Authentication Middleware
 * LearnLift - Offline-First Education Platform
 */

require_once __DIR__ . '/functions.php';

/**
 * Require authentication
 */
function requireAuth()
{
    if (!isLoggedIn()) {
        redirect('/LearnLift/auth.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
    }
}

/**
 * Require specific role
 */
function requireRole($role)
{
    requireAuth();
    if (!hasRole($role)) {
        setFlashMessage('error', 'Access denied. Insufficient permissions.');
        redirect('/LearnLift/index.php');
    }
}

/**
 * Require any of the specified roles
 */
function requireAnyRole($roles)
{
    requireAuth();
    if (!hasAnyRole($roles)) {
        setFlashMessage('error', 'Access denied. Insufficient permissions.');
        redirect('/LearnLift/index.php');
    }
}

/**
 * Require student role
 */
function requireStudent()
{
    requireRole('student');
}

/**
 * Require educator role
 */
function requireEducator()
{
    requireRole('educator');
}

/**
 * Require admin role
 */
function requireAdmin()
{
    requireRole('admin');
}

/**
 * Require educator or admin role
 */
function requireEducatorOrAdmin()
{
    requireAnyRole(['educator', 'admin']);
}
