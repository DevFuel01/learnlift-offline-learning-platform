<?php

/**
 * Landing Page
 * LearnLift - Offline-First Education Platform
 */

require_once __DIR__ . '/includes/functions.php';

// Redirect if already logged in
if (isLoggedIn()) {
    $role = getCurrentUserRole();
    redirect("/LearnLift/$role/dashboard.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LearnLift - Learn Anywhere, Anytime</title>
    <meta name="description" content="Offline-first education platform for students in low-internet environments">
    <link rel="stylesheet" href="/LearnLift/assets/css/style.css">
    <style>
        .hero {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: var(--white);
            padding: var(--spacing-2xl) 0;
            text-align: center;
            min-height: 60vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .hero-content h1 {
            font-size: 3.5rem;
            margin-bottom: var(--spacing-lg);
            color: var(--white);
        }

        .hero-content p {
            font-size: 1.25rem;
            margin-bottom: var(--spacing-xl);
            opacity: 0.9;
        }

        .hero-buttons {
            display: flex;
            gap: var(--spacing-md);
            justify-content: center;
            flex-wrap: wrap;
        }

        .feature-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: var(--spacing-xl);
            padding: var(--spacing-2xl) 0;
        }

        .feature-card {
            text-align: center;
            padding: var(--spacing-xl);
        }

        .feature-icon {
            font-size: 3rem;
            margin-bottom: var(--spacing-md);
        }

        .section {
            padding: var(--spacing-2xl) 0;
        }

        .section-title {
            text-align: center;
            margin-bottom: var(--spacing-xl);
        }

        .bg-light {
            background-color: var(--gray-lighter);
        }
    </style>
</head>

<body>
    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <div class="hero-content">
                <h1>Learn Anywhere, Anytime</h1>
                <p>Access quality education even without internet. Download lessons, take quizzes offline, and sync when you're back online.</p>
                <div class="hero-buttons">
                    <a href="/LearnLift/auth.php" class="btn btn-lg" style="background: var(--white); color: var(--primary);">Get Started</a>
                    <a href="#features" class="btn btn-lg btn-outline" style="border-color: var(--white); color: var(--white);">Learn More</a>
                    <button class="btn btn-lg btn-outline theme-toggle" style="border-color: var(--white); color: var(--white);" title="Toggle Dark Mode">🌙</button>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section id="features" class="section">
        <div class="container">
            <h2 class="section-title">Why LearnLift?</h2>
            <div class="feature-grid">
                <div class="feature-card card">
                    <div class="feature-icon">📚</div>
                    <h3>Offline Learning</h3>
                    <p>Download lessons and access them anytime, even without internet connection.</p>
                </div>

                <div class="feature-card card">
                    <div class="feature-icon">✅</div>
                    <h3>Offline Quizzes</h3>
                    <p>Take quizzes offline and automatically sync your results when you're back online.</p>
                </div>

                <div class="feature-card card">
                    <div class="feature-icon">📅</div>
                    <h3>Study Planner</h3>
                    <p>Organize your learning with a simple study planner that works offline.</p>
                </div>

                <div class="feature-card card">
                    <div class="feature-icon">👨‍🏫</div>
                    <h3>For Educators</h3>
                    <p>Create and manage lessons, design quizzes, and track student progress.</p>
                </div>

                <div class="feature-card card">
                    <div class="feature-icon">🔄</div>
                    <h3>Auto Sync</h3>
                    <p>Your progress automatically syncs when internet connection is restored.</p>
                </div>

                <div class="feature-card card">
                    <div class="feature-icon">🔒</div>
                    <h3>Secure & Private</h3>
                    <p>Your data is protected with industry-standard security measures.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- How It Works Section -->
    <section class="section bg-light">
        <div class="container">
            <h2 class="section-title">How It Works</h2>
            <div class="row">
                <div class="col-4">
                    <div class="card text-center">
                        <h3>1. Register</h3>
                        <p>Create your free account as a student or educator.</p>
                    </div>
                </div>
                <div class="col-4">
                    <div class="card text-center">
                        <h3>2. Download</h3>
                        <p>Browse and download lessons to access offline.</p>
                    </div>
                </div>
                <div class="col-4">
                    <div class="card text-center">
                        <h3>3. Learn</h3>
                        <p>Study offline, take quizzes, and track your progress.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="section">
        <div class="container text-center">
            <h2>Ready to Start Learning?</h2>
            <p class="mb-4">Join thousands of students learning without barriers.</p>
            <a href="/LearnLift/auth.php" class="btn btn-primary btn-lg">Get Started Free</a>
        </div>
    </section>

    <!-- Footer -->
    <footer style="background: var(--dark); color: var(--white); padding: var(--spacing-xl) 0; text-align: center;">
        <div class="container">
            <p>&copy; 2025 LearnLift. Empowering education for all.</p>
        </div>
    </footer>

    <script src="/LearnLift/assets/js/main.js"></script>
</body>

</html>