<?php

/**
 * User Profile Management
 * LearnLift - Offline-First Education Platform
 */

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

requireAuth();

$userId = getCurrentUserId();
$role = getCurrentUserRole();
$error = '';
$success = '';

// Fetch current user data
try {
    $stmt = $pdo->prepare("SELECT name, email, role FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
} catch (PDOException $e) {
    error_log("Profile fetch error: " . $e->getMessage());
    $error = "Failed to load profile data.";
}

// Handle Profile Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $name = sanitize($_POST['name'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $currentPassword = $_POST['current_password'] ?? '';
    $newPassword = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    $csrfToken = $_POST['csrf_token'] ?? '';

    if (!verifyCSRFToken($csrfToken)) {
        $error = 'Invalid security token';
    } elseif (empty($name) || empty($email)) {
        $error = 'Name and email are required';
    } elseif (!validateEmail($email)) {
        $error = 'Invalid email format';
    } else {
        try {
            // Check password if changing sensitive info or setting new password
            // For simple profile updates (name/email), we usually require password verification for security
            // but for "Basic" we might skip it for name. 
            // However, checking email uniqueness is critical.

            // Check email uniqueness
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
            $stmt->execute([$email, $userId]);
            if ($stmt->fetch()) {
                $error = 'Email already in use by another account';
            } else {
                // If changing password
                if (!empty($newPassword)) {
                    if (empty($currentPassword)) {
                        $error = 'Current password is required to set a new password';
                    } elseif ($newPassword !== $confirmPassword) {
                        $error = 'New passwords do not match';
                    } elseif (strlen($newPassword) < 6) {
                        $error = 'New password must be at least 6 characters';
                    } else {
                        // Verify current password
                        $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ?");
                        $stmt->execute([$userId]);
                        $storedHash = $stmt->fetchColumn();

                        if (!password_verify($currentPassword, $storedHash)) {
                            $error = 'Incorrect current password';
                        } else {
                            // Update everything
                            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                            $stmt = $pdo->prepare("UPDATE users SET name = ?, email = ?, password = ? WHERE id = ?");
                            $stmt->execute([$name, $email, $hashedPassword, $userId]);
                            $success = 'Profile and password updated successfully!';

                            // Update session name if changed
                            $_SESSION['user_name'] = $name;
                            $_SESSION['user_email'] = $email; // though session usually just stores ID
                        }
                    }
                } else {
                    // Update only details
                    $stmt = $pdo->prepare("UPDATE users SET name = ?, email = ? WHERE id = ?");
                    $stmt->execute([$name, $email, $userId]);
                    $success = 'Profile updated successfully!';

                    // Update session name if changed
                    $_SESSION['user_name'] = $name;
                }

                // Refresh data
                if (!$error) {
                    $user['name'] = $name;
                    $user['email'] = $email;
                }
            }
        } catch (PDOException $e) {
            error_log("Profile update error: " . $e->getMessage());
            $error = "Failed to update profile";
        }
    }
}

$csrfToken = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - LearnLift</title>
    <link rel="stylesheet" href="/LearnLift/assets/css/style.css">
</head>

<body>
    <nav class="navbar">
        <div class="container navbar-container">
            <a href="/LearnLift/" class="navbar-brand">LearnLift</a>
            <button class="navbar-toggle" aria-label="Toggle navigation">☰</button>
            <ul class="navbar-menu">
                <?php if ($role === 'student'): ?>
                    <li><a href="/LearnLift/student/dashboard.php">Dashboard</a></li>
                    <li><a href="/LearnLift/student/lessons.php">Lessons</a></li>
                    <li><a href="/LearnLift/student/planner.php">Study Planner</a></li>
                <?php elseif ($role === 'educator'): ?>
                    <li><a href="/LearnLift/educator/dashboard.php">Dashboard</a></li>
                    <li><a href="/LearnLift/educator/lessons.php">My Lessons</a></li>
                    <li><a href="/LearnLift/educator/quizzes.php">My Quizzes</a></li>
                    <li><a href="/LearnLift/educator/students.php">Students</a></li>
                <?php elseif ($role === 'admin'): ?>
                    <li><a href="/LearnLift/admin/dashboard.php">Dashboard</a></li>
                    <li><a href="/LearnLift/admin/users.php">Users</a></li>
                    <li><a href="/LearnLift/admin/lessons.php">Lessons</a></li>
                    <li><a href="/LearnLift/admin/quizzes.php">Quizzes</a></li>
                    <li><a href="/LearnLift/admin/analytics.php">Analytics</a></li>
                <?php endif; ?>
                <li><a href="/LearnLift/profile.php" class="active">Profile</a></li>
                <li><span id="online-status" class="status-indicator"></span></li>
                <li><button class="btn btn-sm btn-outline theme-toggle" title="Toggle Dark Mode" style="margin-right: 10px;">🌙</button></li>
                <li><a href="/LearnLift/api/auth.php?action=logout">Logout</a></li>
            </ul>
        </div>
    </nav>

    <div class="container" style="margin-top: var(--spacing-xl);">
        <div class="row">
            <div class="col-8" style="margin: 0 auto;">
                <div class="card">
                    <div class="card-header">
                        <h2 class="card-title">My Profile</h2>
                    </div>
                    <div class="card-body">
                        <?php if ($error): ?>
                            <div class="alert alert-danger"><?php echo $error; ?></div>
                        <?php endif; ?>

                        <?php if ($success): ?>
                            <div class="alert alert-success"><?php echo $success; ?></div>
                        <?php endif; ?>

                        <form method="POST">
                            <input type="hidden" name="update_profile" value="1">
                            <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">

                            <div class="form-group">
                                <label class="form-label">Role</label>
                                <input type="text" class="form-control" value="<?php echo ucfirst($user['role']); ?>" disabled style="background: var(--gray-lighter);">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Full Name</label>
                                <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($user['name']); ?>" required>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Email Address</label>
                                <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                            </div>

                            <hr style="margin: var(--spacing-lg) 0; border: 0; border-top: 1px solid var(--gray-lighter);">
                            <h3 style="margin-bottom: var(--spacing-md); font-size: 1.25rem;">Change Password <small style="color: var(--gray); font-size: 0.875rem; font-weight: normal;">(Leave blank to keep current)</small></h3>

                            <div class="form-group">
                                <label class="form-label">Current Password</label>
                                <input type="password" name="current_password" class="form-control" placeholder="Required only if changing password">
                            </div>

                            <div class="form-group">
                                <label class="form-label">New Password</label>
                                <input type="password" name="new_password" class="form-control" minlength="6" placeholder="Minimum 6 characters">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Confirm New Password</label>
                                <input type="password" name="confirm_password" class="form-control" placeholder="Re-enter new password">
                            </div>

                            <div class="mt-4">
                                <button type="submit" class="btn btn-primary btn-block">Update Profile</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="/LearnLift/assets/js/main.js"></script>
</body>

</html>