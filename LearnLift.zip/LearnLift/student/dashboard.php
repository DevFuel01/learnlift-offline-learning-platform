<?php

/**
 * Student Dashboard
 * LearnLift - Offline-First Education Platform
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireStudent();

$userId = getCurrentUserId();
$userName = getCurrentUserName();

// Get statistics
try {
    // Count available lessons
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM lessons WHERE is_published = 1");
    $stmt->execute();
    $availableLessons = $stmt->fetch()['count'];

    // Count downloaded lessons
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM downloaded_lessons WHERE student_id = ?");
    $stmt->execute([$userId]);
    $downloadedLessons = $stmt->fetch()['count'];

    // Count completed quizzes
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM quiz_results WHERE student_id = ?");
    $stmt->execute([$userId]);
    $completedQuizzes = $stmt->fetch()['count'];

    // Get average score
    $stmt = $pdo->prepare("SELECT AVG(percentage) as avg_score FROM quiz_results WHERE student_id = ?");
    $stmt->execute([$userId]);
    $avgScore = round($stmt->fetch()['avg_score'] ?? 0, 1);

    // Get recent lessons
    $stmt = $pdo->prepare("
        SELECT l.*, u.name as educator_name
        FROM lessons l
        JOIN users u ON l.educator_id = u.id
        WHERE l.is_published = 1
        ORDER BY l.created_at DESC
        LIMIT 5
    ");
    $stmt->execute();
    $recentLessons = $stmt->fetchAll();

    // Get today's study plans
    $stmt = $pdo->prepare("
        SELECT * FROM study_plans
        WHERE student_id = ? AND task_date = CURDATE()
        ORDER BY is_completed ASC, created_at DESC
    ");
    $stmt->execute([$userId]);
    $todayTasks = $stmt->fetchAll();

    // Get recent quiz results
    $stmt = $pdo->prepare("
        SELECT qr.*, q.title as quiz_title, l.title as lesson_title
        FROM quiz_results qr
        JOIN quizzes q ON qr.quiz_id = q.id
        JOIN lessons l ON q.lesson_id = l.id
        WHERE qr.student_id = ?
        ORDER BY qr.submitted_at DESC
        LIMIT 5
    ");
    $stmt->execute([$userId]);
    $recentResults = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Dashboard error: " . $e->getMessage());
    $error = "Failed to load dashboard data";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard - LearnLift</title>
    <link rel="stylesheet" href="/LearnLift/assets/css/style.css">
    <style>
        .dashboard-header {
            background: var(--gradient-primary);
            color: var(--white);
            padding: var(--spacing-xl) 0;
            margin-bottom: var(--spacing-xl);
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: var(--spacing-lg);
            margin-bottom: var(--spacing-xl);
        }

        .stat-card {
            background: var(--white);
            padding: var(--spacing-lg);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-md);
            text-align: center;
        }

        .stat-value {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--primary);
            margin-bottom: var(--spacing-sm);
        }

        .stat-label {
            color: var(--gray);
            font-size: 0.875rem;
            text-transform: uppercase;
        }

        .lesson-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: var(--spacing-md);
            border-bottom: 1px solid var(--gray-lighter);
        }

        .lesson-item:last-child {
            border-bottom: none;
        }

        .lesson-info h4 {
            margin-bottom: var(--spacing-xs);
        }

        .lesson-meta {
            font-size: 0.875rem;
            color: var(--gray);
        }

        .task-item {
            display: flex;
            align-items: center;
            gap: var(--spacing-md);
            padding: var(--spacing-md);
            border-bottom: 1px solid var(--gray-lighter);
        }

        .task-item:last-child {
            border-bottom: none;
        }

        .task-checkbox {
            width: 24px;
            height: 24px;
            cursor: pointer;
        }

        .task-completed {
            text-decoration: line-through;
            opacity: 0.6;
        }
    </style>
</head>

<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="container navbar-container">
            <a href="/LearnLift/" class="navbar-brand">LearnLift</a>
            <button class="navbar-toggle" aria-label="Toggle navigation">☰</button>
            <ul class="navbar-menu">
                <li><a href="/LearnLift/student/dashboard.php" class="active">Dashboard</a></li>
                <li><a href="/LearnLift/student/lessons.php">Lessons</a></li>
                <li><a href="/LearnLift/student/planner.php">Study Planner</a></li>
                <li><a href="/LearnLift/profile.php">Profile</a></li>
                <li><span id="online-status" class="status-indicator"></span></li>
                <li><button class="btn btn-sm btn-outline theme-toggle" title="Toggle Dark Mode" style="margin-right: 10px;">🌙</button></li>
                <li><a href="/LearnLift/api/auth.php?action=logout">Logout</a></li>
            </ul>
        </div>
    </nav>

    <!-- Header -->
    <div class="dashboard-header">
        <div class="container">
            <h1>Welcome back, <?php echo htmlspecialchars($userName); ?>! 👋</h1>
            <p>Continue your learning journey</p>
        </div>
    </div>

    <div class="container">
        <!-- Sync Status -->
        <div id="sync-status" style="display: none;"></div>

        <!-- Statistics -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-value"><?php echo $availableLessons; ?></div>
                <div class="stat-label">Available Lessons</div>
            </div>

            <div class="stat-card">
                <div class="stat-value"><?php echo $downloadedLessons; ?></div>
                <div class="stat-label">Downloaded Lessons</div>
            </div>

            <div class="stat-card">
                <div class="stat-value"><?php echo $completedQuizzes; ?></div>
                <div class="stat-label">Quizzes Completed</div>
            </div>

            <div class="stat-card">
                <div class="stat-value"><?php echo $avgScore; ?>%</div>
                <div class="stat-label">Average Score</div>
            </div>
        </div>

        <div class="row">
            <!-- Recent Lessons -->
            <div class="col-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Recent Lessons</h3>
                    </div>
                    <div class="card-body">
                        <?php if (empty($recentLessons)): ?>
                            <p class="text-center" style="color: var(--gray);">No lessons available yet</p>
                        <?php else: ?>
                            <?php foreach ($recentLessons as $lesson): ?>
                                <div class="lesson-item">
                                    <div class="lesson-info">
                                        <h4><?php echo htmlspecialchars($lesson['title']); ?></h4>
                                        <div class="lesson-meta">
                                            By <?php echo htmlspecialchars($lesson['educator_name']); ?> •
                                            <?php echo timeAgo($lesson['created_at']); ?>
                                        </div>
                                    </div>
                                    <div class="lesson-actions" style="display: flex; gap: 10px; align-items: center;">
                                        <a href="/LearnLift/student/lessons.php?id=<?php echo $lesson['id']; ?>" class="btn btn-sm btn-primary">View</a>
                                        <?php
                                        // Check for quiz
                                        $stmt_q = $pdo->prepare("SELECT id FROM quizzes WHERE lesson_id = ? LIMIT 1");
                                        $stmt_q->execute([$lesson['id']]);
                                        $quiz_info = $stmt_q->fetch();

                                        if ($quiz_info) {
                                            $stmt_r = $pdo->prepare("SELECT id FROM quiz_results WHERE quiz_id = ? AND student_id = ? LIMIT 1");
                                            $stmt_r->execute([$quiz_info['id'], $userId]);
                                            $res_info = $stmt_r->fetch();

                                            if ($res_info) {
                                                echo '<a href="/LearnLift/student/quiz.php?id=' . $quiz_info['id'] . '" class="btn btn-sm btn-outline-success">✓ Quiz Done</a>';
                                            } else {
                                                echo '<a href="/LearnLift/student/quiz.php?id=' . $quiz_info['id'] . '" class="btn btn-sm btn-secondary">Take Quiz</a>';
                                            }
                                        }
                                        ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    <div class="card-footer">
                        <a href="/LearnLift/student/lessons.php" class="btn btn-outline btn-block">View All Lessons</a>
                    </div>
                </div>
            </div>

            <!-- Today's Tasks -->
            <div class="col-6">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Today's Study Plan</h3>
                    </div>
                    <div class="card-body">
                        <?php if (empty($todayTasks)): ?>
                            <p class="text-center" style="color: var(--gray);">No tasks for today</p>
                        <?php else: ?>
                            <?php foreach ($todayTasks as $task): ?>
                                <div class="task-item">
                                    <input type="checkbox" class="task-checkbox"
                                        <?php echo $task['is_completed'] ? 'checked disabled' : ''; ?>
                                        onchange="toggleTask(<?php echo $task['id']; ?>, this.checked)">
                                    <div class="<?php echo $task['is_completed'] ? 'task-completed' : ''; ?>">
                                        <strong><?php echo htmlspecialchars($task['task_title']); ?></strong>
                                        <?php if ($task['task_description']): ?>
                                            <div style="font-size: 0.875rem; color: var(--gray);">
                                                <?php echo htmlspecialchars($task['task_description']); ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                    <div class="card-footer">
                        <a href="/LearnLift/student/planner.php" class="btn btn-outline btn-block">Manage Study Plan</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Quiz Results -->
        <div class="card mt-4">
            <div class="card-header">
                <h3 class="card-title">Recent Quiz Results</h3>
            </div>
            <div class="card-body">
                <?php if (empty($recentResults)): ?>
                    <p class="text-center" style="color: var(--gray);">No quiz results yet</p>
                <?php else: ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Quiz</th>
                                <th>Lesson</th>
                                <th>Score</th>
                                <th>Percentage</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recentResults as $result): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($result['quiz_title']); ?></td>
                                    <td><?php echo htmlspecialchars($result['lesson_title']); ?></td>
                                    <td><?php echo (int)$result['score']; ?>/<?php echo $result['total_points']; ?></td>
                                    <td>
                                        <span class="badge <?php echo $result['percentage'] >= 70 ? 'badge-success' : 'badge-warning'; ?>">
                                            <?php echo round($result['percentage'], 1); ?>%
                                        </span>
                                    </td>
                                    <td><?php echo formatDateTime($result['submitted_at']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>

        <!-- Offline Stats -->
        <div class="card mt-4">
            <div class="card-header">
                <h3 class="card-title">Offline Data</h3>
            </div>
            <div class="card-body">
                <div id="offline-stats">
                    <p>Loading offline statistics...</p>
                </div>
                <button onclick="window.SyncManager.triggerManualSync()" class="btn btn-primary mt-3">
                    Sync Now
                </button>
            </div>
        </div>
    </div>

    <script src="/LearnLift/assets/js/main.js"></script>
    <script src="/LearnLift/assets/js/offline.js"></script>
    <script src="/LearnLift/assets/js/sync.js"></script>
    <script>
        // Toggle task completion
        async function toggleTask(taskId, isCompleted) {
            try {
                const response = await fetch('/LearnLift/api/planner.php?id=' + taskId, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        is_completed: isCompleted ? 1 : 0
                    })
                });

                const result = await response.json();

                if (result.success) {
                    location.reload();
                } else {
                    alert('Failed to update task');
                }
            } catch (error) {
                console.error('Error:', error);
                alert('Failed to update task');
            }
        }
    </script>
</body>

</html>