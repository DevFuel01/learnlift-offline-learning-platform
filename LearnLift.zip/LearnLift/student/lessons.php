<?php

/**
 * Student Lessons Page
 * LearnLift - Offline-First Education Platform
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireStudent();

$userId = getCurrentUserId();

// Get all published lessons
try {
    $stmt = $pdo->prepare("
        SELECT l.*, u.name as educator_name,
               dl.id as is_downloaded
        FROM lessons l
        JOIN users u ON l.educator_id = u.id
        LEFT JOIN downloaded_lessons dl ON l.id = dl.lesson_id AND dl.student_id = ?
        WHERE l.is_published = 1
        ORDER BY l.created_at DESC
    ");
    $stmt->execute([$userId]);
    $lessons = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Lessons error: " . $e->getMessage());
    $error = "Failed to load lessons";
}

// Handle lesson view
$selectedLesson = null;
if (isset($_GET['id'])) {
    $lessonId = (int)$_GET['id'];
    try {
        $stmt = $pdo->prepare("
            SELECT l.*, u.name as educator_name,
                   dl.id as is_downloaded
            FROM lessons l
            JOIN users u ON l.educator_id = u.id
            LEFT JOIN downloaded_lessons dl ON l.id = dl.lesson_id AND dl.student_id = ?
            WHERE l.id = ? AND l.is_published = 1
        ");
        $stmt->execute([$userId, $lessonId]);
        $selectedLesson = $stmt->fetch();

        // Get quiz for this lesson
        if ($selectedLesson) {
            $stmt = $pdo->prepare("SELECT * FROM quizzes WHERE lesson_id = ? LIMIT 1");
            $stmt->execute([$lessonId]);
            $quiz = $stmt->fetch();
        }
    } catch (PDOException $e) {
        error_log("Lesson view error: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lessons - LearnLift</title>
    <link rel="stylesheet" href="/LearnLift/assets/css/style.css">
    <style>
        .lessons-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: var(--spacing-lg);
        }

        .lesson-card {
            position: relative;
        }

        .lesson-badge {
            position: absolute;
            top: var(--spacing-md);
            right: var(--spacing-md);
        }

        .lesson-actions {
            display: flex;
            gap: var(--spacing-sm);
            margin-top: var(--spacing-md);
        }

        .lesson-content {
            line-height: 1.8;
            margin: var(--spacing-lg) 0;
        }
    </style>
</head>

<body>
    <!-- Navigation -->
    <nav class="navbar">
        <div class="container navbar-container">
            <a href="/LearnLift/" class="navbar-brand">LearnLift</a>
            <button class="navbar-toggle" aria-label="Toggle navigation">☰</button>
            <ul class="navbar-menu">
                <li><a href="/LearnLift/student/dashboard.php">Dashboard</a></li>
                <li><a href="/LearnLift/student/lessons.php" class="active">Lessons</a></li>
                <li><a href="/LearnLift/student/planner.php">Study Planner</a></li>
                <li><a href="/LearnLift/profile.php">Profile</a></li>
                <li><span id="online-status" class="status-indicator"></span></li>
                <li><button class="btn btn-sm btn-outline theme-toggle" title="Toggle Dark Mode" style="margin-right: 10px;">🌙</button></li>
                <li><a href="/LearnLift/api/auth.php?action=logout">Logout</a></li>
            </ul>
        </div>
    </nav>

    <div class="container" style="margin-top: var(--spacing-xl);">
        <?php if ($selectedLesson): ?>
            <!-- Lesson Detail View -->
            <div class="mb-4">
                <a href="/LearnLift/student/lessons.php" class="btn btn-outline">← Back to Lessons</a>
            </div>

            <div class="card">
                <div class="card-header">
                    <h1 class="card-title"><?php echo htmlspecialchars($selectedLesson['title']); ?></h1>
                    <p style="color: var(--gray); margin: 0;">
                        By <?php echo htmlspecialchars($selectedLesson['educator_name']); ?> •
                        <?php echo formatDate($selectedLesson['created_at']); ?>
                    </p>
                </div>

                <div class="card-body">
                    <?php if ($selectedLesson['description']): ?>
                        <div class="alert alert-info">
                            <strong>Description:</strong> <?php echo nl2br(htmlspecialchars($selectedLesson['description'])); ?>
                        </div>
                    <?php endif; ?>

                    <div class="lesson-content">
                        <?php echo nl2br(htmlspecialchars($selectedLesson['content'])); ?>
                    </div>

                    <?php if ($selectedLesson['file_path']): ?>
                        <div class="alert alert-success">
                            <strong>📎 Attachment:</strong>
                            <a href="/LearnLift/<?php echo htmlspecialchars($selectedLesson['file_path']); ?>"
                                target="_blank" class="btn btn-sm btn-success">
                                Download File (<?php echo formatFileSize($selectedLesson['file_size'] ?? 0); ?>)
                            </a>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="card-footer">
                    <div class="lesson-actions">
                        <?php if ($selectedLesson['is_downloaded']): ?>
                            <button class="btn btn-success" disabled>
                                ✓ Downloaded for Offline
                            </button>
                        <?php else: ?>
                            <button onclick="downloadLesson(<?php echo $selectedLesson['id']; ?>)"
                                class="btn btn-primary" id="download-btn-<?php echo $selectedLesson['id']; ?>">
                                📥 Download for Offline
                            </button>
                        <?php endif; ?>

                        <?php if ($quiz): ?>
                            <?php
                            // Check if quiz already taken
                            $stmt = $pdo->prepare("SELECT id FROM quiz_results WHERE quiz_id = ? AND student_id = ? LIMIT 1");
                            $stmt->execute([$quiz['id'], $userId]);
                            $hasTaken = $stmt->fetch();
                            ?>
                            <a href="/LearnLift/student/quiz.php?id=<?php echo $quiz['id']; ?>"
                                class="btn <?php echo $hasTaken ? 'btn-outline' : 'btn-secondary'; ?>">
                                <?php echo $hasTaken ? 'View Quiz Result' : 'Take Quiz'; ?>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <!-- Lessons List View -->
            <h1>Available Lessons</h1>
            <p class="mb-4">Browse and download lessons to study offline</p>

            <?php if (empty($lessons)): ?>
                <div class="card text-center">
                    <div class="card-body">
                        <h3>No Lessons Available</h3>
                        <p>Check back later for new learning materials!</p>
                    </div>
                </div>
            <?php else: ?>
                <div class="lessons-grid">
                    <?php foreach ($lessons as $lesson): ?>
                        <div class="card lesson-card">
                            <?php if ($lesson['is_downloaded']): ?>
                                <span class="lesson-badge badge badge-success">Downloaded</span>
                            <?php endif; ?>

                            <div class="card-header">
                                <h3 class="card-title"><?php echo htmlspecialchars($lesson['title']); ?></h3>
                            </div>

                            <div class="card-body">
                                <p><?php echo htmlspecialchars(substr($lesson['description'] ?? '', 0, 150)); ?>
                                    <?php echo strlen($lesson['description'] ?? '') > 150 ? '...' : ''; ?>
                                </p>

                                <div style="font-size: 0.875rem; color: var(--gray); margin-top: var(--spacing-md);">
                                    <div>👨‍🏫 <?php echo htmlspecialchars($lesson['educator_name']); ?></div>
                                    <div>📅 <?php echo formatDate($lesson['created_at']); ?></div>
                                    <?php if ($lesson['file_path']): ?>
                                        <div>📎 Has attachment</div>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="card-footer">
                                <a href="/LearnLift/student/lessons.php?id=<?php echo $lesson['id']; ?>"
                                    class="btn btn-primary btn-block">
                                    View Lesson
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <script src="/LearnLift/assets/js/main.js"></script>
    <script src="/LearnLift/assets/js/offline.js"></script>
    <script>
        async function downloadLesson(lessonId) {
            const btn = document.getElementById('download-btn-' + lessonId);
            btn.disabled = true;
            btn.textContent = 'Downloading...';

            try {
                // Fetch lesson data
                const response = await fetch('/LearnLift/api/lessons.php?id=' + lessonId);
                const lesson = await response.json();

                if (lesson.success) {
                    // Save to IndexedDB
                    await window.OfflineDB.saveDownloadedLesson(lessonId, lesson.data);

                    // Mark as downloaded in database
                    await fetch('/LearnLift/api/lessons.php?action=mark_downloaded&id=' + lessonId, {
                        method: 'POST'
                    });

                    // Cache the lesson file if exists
                    if (lesson.data.file_path) {
                        if ('serviceWorker' in navigator) {
                            const sw = await navigator.serviceWorker.ready;
                            sw.active.postMessage({
                                type: 'CACHE_LESSON',
                                url: '/LearnLift/' + lesson.data.file_path
                            });
                        }
                    }

                    window.LearnLift.showToast('Lesson downloaded for offline access!', 'success');
                    setTimeout(() => location.reload(), 1000);
                } else {
                    throw new Error(lesson.error || 'Download failed');
                }
            } catch (error) {
                console.error('Download error:', error);
                window.LearnLift.showToast('Failed to download lesson', 'danger');
                btn.disabled = false;
                btn.textContent = '📥 Download for Offline';
            }
        }
    </script>
    <script src="/LearnLift/assets/js/main.js"></script>
</body>

</html>