<?php

/**
 * Student Study Planner
 * LearnLift - Offline-First Education Platform
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireStudent();

$userId = getCurrentUserId();

// Handle task creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_task'])) {
    $taskTitle = sanitize($_POST['task_title'] ?? '');
    $taskDescription = sanitize($_POST['task_description'] ?? '');
    $taskDate = $_POST['task_date'] ?? date('Y-m-d');
    $csrfToken = $_POST['csrf_token'] ?? '';

    if (!verifyCSRFToken($csrfToken)) {
        $error = 'Invalid security token';
    } elseif (empty($taskTitle)) {
        $error = 'Task title is required';
    } else {
        try {
            $stmt = $pdo->prepare("
                INSERT INTO study_plans (student_id, task_title, task_description, task_date)
                VALUES (?, ?, ?, ?)
            ");
            $stmt->execute([$userId, $taskTitle, $taskDescription, $taskDate]);
            $success = 'Task created successfully!';
        } catch (PDOException $e) {
            error_log("Task creation error: " . $e->getMessage());
            $error = 'Failed to create task';
        }
    }
}

// Get study plans
try {
    $stmt = $pdo->prepare("
        SELECT * FROM study_plans
        WHERE student_id = ?
        ORDER BY task_date DESC, created_at DESC
    ");
    $stmt->execute([$userId]);
    $allTasks = $stmt->fetchAll();

    // Group by date
    $tasksByDate = [];
    foreach ($allTasks as $task) {
        $date = $task['task_date'];
        if (!isset($tasksByDate[$date])) {
            $tasksByDate[$date] = [];
        }
        $tasksByDate[$date][] = $task;
    }
} catch (PDOException $e) {
    error_log("Planner error: " . $e->getMessage());
    $error = "Failed to load study plans";
}

$csrfToken = generateCSRFToken();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Study Planner - LearnLift</title>
    <link rel="stylesheet" href="/LearnLift/assets/css/style.css">
    <style>
        .date-section {
            margin-bottom: var(--spacing-xl);
        }

        .date-header {
            background: var(--gradient-primary);
            color: var(--white);
            padding: var(--spacing-md) var(--spacing-lg);
            border-radius: var(--radius-md);
            margin-bottom: var(--spacing-md);
        }

        .date-header.today {
            background: var(--gradient-success);
        }

        .task-list {
            display: flex;
            flex-direction: column;
            gap: var(--spacing-sm);
        }

        .task-item {
            display: flex;
            align-items: flex-start;
            gap: var(--spacing-md);
            padding: var(--spacing-md);
            background: var(--white);
            border-radius: var(--radius-md);
            box-shadow: var(--shadow-sm);
            transition: var(--transition);
        }

        .task-item:hover {
            box-shadow: var(--shadow-md);
        }

        .task-checkbox {
            width: 24px;
            height: 24px;
            margin-top: 2px;
            cursor: pointer;
        }

        .task-content {
            flex: 1;
        }

        .task-completed {
            opacity: 0.6;
        }

        .task-completed .task-title {
            text-decoration: line-through;
        }

        .task-actions {
            display: flex;
            gap: var(--spacing-xs);
        }
    </style>
</head>

<body>
    <nav class="navbar">
        <div class="container navbar-container">
            <a href="/LearnLift/" class="navbar-brand">LearnLift</a>
            <button class="navbar-toggle" aria-label="Toggle navigation">☰</button>
            <ul class="navbar-menu">
                <li><a href="/LearnLift/student/dashboard.php">Dashboard</a></li>
                <li><a href="/LearnLift/student/lessons.php">Lessons</a></li>
                <li><a href="/LearnLift/student/planner.php" class="active">Study Planner</a></li>
                <li><a href="/LearnLift/profile.php">Profile</a></li>
                <li><span id="online-status" class="status-indicator"></span></li>
                <li><button class="btn btn-sm btn-outline theme-toggle" title="Toggle Dark Mode" style="margin-right: 10px;">🌙</button></li>
                <li><a href="/LearnLift/api/auth.php?action=logout">Logout</a></li>
            </ul>
        </div>
    </nav>

    <div class="container" style="margin-top: var(--spacing-xl);">
        <h1>Study Planner 📅</h1>
        <p class="mb-4">Organize your learning tasks and track your progress</p>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>

        <div class="row">
            <div class="col-8">
                <!-- Tasks by Date -->
                <?php if (empty($tasksByDate)): ?>
                    <div class="card text-center">
                        <div class="card-body">
                            <h3>No Tasks Yet</h3>
                            <p>Create your first study task to get started!</p>
                        </div>
                    </div>
                <?php else: ?>
                    <?php foreach ($tasksByDate as $date => $tasks): ?>
                        <div class="date-section">
                            <div class="date-header <?php echo $date === date('Y-m-d') ? 'today' : ''; ?>">
                                <strong><?php echo formatDate($date, 'l, F j, Y'); ?></strong>
                                <?php if ($date === date('Y-m-d')): ?>
                                    <span class="badge badge-success" style="margin-left: var(--spacing-sm);">Today</span>
                                <?php endif; ?>
                                <span style="margin-left: var(--spacing-md); opacity: 0.9;">
                                    <?php
                                    $completed = count(array_filter($tasks, fn($t) => $t['is_completed']));
                                    echo "$completed / " . count($tasks) . " completed";
                                    ?>
                                </span>
                            </div>

                            <div class="task-list">
                                <?php foreach ($tasks as $task): ?>
                                    <div class="task-item <?php echo $task['is_completed'] ? 'task-completed' : ''; ?>">
                                        <input type="checkbox"
                                            class="task-checkbox"
                                            <?php echo $task['is_completed'] ? 'checked disabled' : ''; ?>
                                            onchange="toggleTask(<?php echo $task['id']; ?>, this.checked)">

                                        <div class="task-content">
                                            <div class="task-title">
                                                <strong><?php echo htmlspecialchars($task['task_title']); ?></strong>
                                            </div>
                                            <?php if ($task['task_description']): ?>
                                                <div style="font-size: 0.875rem; color: var(--gray); margin-top: var(--spacing-xs);">
                                                    <?php echo nl2br(htmlspecialchars($task['task_description'])); ?>
                                                </div>
                                            <?php endif; ?>
                                            <?php if ($task['completed_at']): ?>
                                                <div style="font-size: 0.75rem; color: var(--success); margin-top: var(--spacing-xs);">
                                                    ✓ Completed <?php echo timeAgo($task['completed_at']); ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>

                                        <div class="task-actions">
                                            <button onclick="deleteTask(<?php echo $task['id']; ?>)"
                                                class="btn btn-sm btn-danger" title="Delete">
                                                🗑️
                                            </button>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <div class="col-4">
                <!-- Create Task Form -->
                <div class="card" style="position: sticky; top: var(--spacing-lg);">
                    <div class="card-header">
                        <h3 class="card-title">Add New Task</h3>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="create_task" value="1">
                            <input type="hidden" name="csrf_token" value="<?php echo $csrfToken; ?>">

                            <div class="form-group">
                                <label class="form-label">Task Title *</label>
                                <input type="text" name="task_title" class="form-control"
                                    placeholder="e.g., Complete Math Quiz" required>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Description</label>
                                <textarea name="task_description" class="form-control" rows="3"
                                    placeholder="Optional details..."></textarea>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Date *</label>
                                <input type="date" name="task_date" class="form-control"
                                    value="<?php echo date('Y-m-d'); ?>" required>
                            </div>

                            <button type="submit" class="btn btn-primary btn-block">
                                Add Task
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Stats Card -->
                <div class="card mt-3">
                    <div class="card-header">
                        <h4 class="card-title">Statistics</h4>
                    </div>
                    <div class="card-body">
                        <?php
                        $totalTasks = count($allTasks);
                        $completedTasks = count(array_filter($allTasks, fn($t) => $t['is_completed']));
                        $completionRate = $totalTasks > 0 ? round(($completedTasks / $totalTasks) * 100) : 0;
                        ?>
                        <p><strong>Total Tasks:</strong> <?php echo $totalTasks; ?></p>
                        <p><strong>Completed:</strong> <?php echo $completedTasks; ?></p>
                        <p><strong>Completion Rate:</strong> <?php echo $completionRate; ?>%</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="/LearnLift/assets/js/main.js"></script>
    <script src="/LearnLift/assets/js/offline.js"></script>
    <script>
        async function toggleTask(taskId, isCompleted) {
            try {
                // Try online first
                if (navigator.onLine) {
                    const response = await fetch('/LearnLift/api/planner.php?id=' + taskId, {
                        method: 'PUT',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            is_completed: isCompleted ? 1 : 0
                        })
                    });

                    const result = await response.json();
                    if (result.success) {
                        location.reload();
                    } else {
                        throw new Error(result.error);
                    }
                } else {
                    // Save offline
                    await window.OfflineDB.updateStudyPlanOffline(taskId, {
                        is_completed: isCompleted
                    });
                    window.LearnLift.showToast('Task updated offline', 'success');
                    location.reload();
                }
            } catch (error) {
                console.error('Error:', error);
                alert('Failed to update task');
                location.reload();
            }
        }

        async function deleteTask(taskId) {
            if (!confirm('Are you sure you want to delete this task?')) {
                return;
            }

            try {
                const response = await fetch('/LearnLift/api/planner.php?id=' + taskId, {
                    method: 'DELETE'
                });

                const result = await response.json();
                if (result.success) {
                    window.LearnLift.showToast('Task deleted', 'success');
                    location.reload();
                } else {
                    throw new Error(result.error);
                }
            } catch (error) {
                console.error('Error:', error);
                alert('Failed to delete task');
            }
        }
    </script>
    <script src="/LearnLift/assets/js/main.js"></script>
</body>

</html>