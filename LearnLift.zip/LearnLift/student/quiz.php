<?php

/**
 * Student Quiz Page
 * LearnLift - Offline-First Education Platform
 */

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

requireStudent();

$userId = getCurrentUserId();
$quizId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get quiz details
try {
    $stmt = $pdo->prepare("
        SELECT q.*, l.title as lesson_title, l.id as lesson_id
        FROM quizzes q
        JOIN lessons l ON q.lesson_id = l.id
        WHERE q.id = ?
    ");
    $stmt->execute([$quizId]);
    $quiz = $stmt->fetch();

    if (!$quiz) {
        redirect('/LearnLift/student/lessons.php');
    }

    // Get questions
    $stmt = $pdo->prepare("
        SELECT id, question, option_a, option_b, option_c, option_d, points, question_order
        FROM quiz_questions
        WHERE quiz_id = ?
        ORDER BY question_order ASC, id ASC
    ");
    $stmt->execute([$quizId]);
    $questions = $stmt->fetchAll();

    // Check if already taken
    $stmt = $pdo->prepare("
        SELECT * FROM quiz_results
        WHERE quiz_id = ? AND student_id = ?
        ORDER BY submitted_at DESC
        LIMIT 1
    ");
    $stmt->execute([$quizId, $userId]);
    $previousResult = $stmt->fetch();
} catch (PDOException $e) {
    error_log("Quiz error: " . $e->getMessage());
    die("Error loading quiz");
}

// Handle quiz submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_quiz'])) {
    $answers = $_POST['answers'] ?? [];
    $timeTaken = (int)($_POST['time_taken'] ?? 0);

    // Calculate score
    $score = 0;
    $totalPoints = 0;

    foreach ($questions as $question) {
        $totalPoints += $question['points'];
        $studentAnswer = $answers[$question['id']] ?? '';

        // Get correct answer
        $stmt = $pdo->prepare("SELECT correct_answer FROM quiz_questions WHERE id = ?");
        $stmt->execute([$question['id']]);
        $correctAnswer = $stmt->fetchColumn();

        if (strtolower($studentAnswer) === strtolower($correctAnswer)) {
            $score += $question['points'];
        }
    }

    $percentage = $totalPoints > 0 ? ($score / $totalPoints) * 100 : 0;

    try {
        $stmt = $pdo->prepare("
            INSERT INTO quiz_results (quiz_id, student_id, answers, score, total_points, percentage, time_taken)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $quizId,
            $userId,
            json_encode($answers),
            $score,
            $totalPoints,
            $percentage,
            $timeTaken
        ]);

        $resultId = $pdo->lastInsertId();
        redirect("/LearnLift/student/quiz.php?id=$quizId&result=$resultId");
    } catch (PDOException $e) {
        error_log("Quiz submission error: " . $e->getMessage());
        $error = "Failed to submit quiz";
    }
}

// Show result if requested
$showResult = false;
$result = null;
if (isset($_GET['result'])) {
    $resultId = (int)$_GET['result'];
    $stmt = $pdo->prepare("SELECT * FROM quiz_results WHERE id = ? AND student_id = ?");
    $stmt->execute([$resultId, $userId]);
    $result = $stmt->fetch();
    $showResult = true;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($quiz['title']); ?> - LearnLift</title>
    <link rel="stylesheet" href="/LearnLift/assets/css/style.css">
    <style>
        .quiz-header {
            background: var(--gradient-primary);
            color: var(--white);
            padding: var(--spacing-xl);
            border-radius: var(--radius-lg);
            margin-bottom: var(--spacing-xl);
        }

        .question-card {
            margin-bottom: var(--spacing-lg);
        }

        .question-number {
            background: var(--primary);
            color: var(--white);
            width: 40px;
            height: 40px;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            margin-right: var(--spacing-md);
        }

        .option-label {
            display: flex;
            align-items: center;
            padding: var(--spacing-md);
            border: 2px solid var(--gray-light);
            border-radius: var(--radius-md);
            cursor: pointer;
            transition: var(--transition);
            margin-bottom: var(--spacing-sm);
        }

        .option-label:hover {
            border-color: var(--primary);
            background-color: var(--gray-lighter);
        }

        .option-label input[type="radio"] {
            margin-right: var(--spacing-md);
        }

        .timer {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--primary);
        }

        .result-card {
            text-align: center;
            padding: var(--spacing-2xl);
        }

        .result-score {
            font-size: 4rem;
            font-weight: 700;
            background: var(--gradient-primary);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
    </style>
</head>

<body>
    <nav class="navbar">
        <div class="container navbar-container">
            <a href="/LearnLift/" class="navbar-brand">LearnLift</a>
            <ul class="navbar-menu">
                <li><a href="/LearnLift/student/dashboard.php">Dashboard</a></li>
                <li><a href="/LearnLift/student/lessons.php">Lessons</a></li>
                <li><span id="online-status" class="status-indicator"></span></li>
            </ul>
        </div>
    </nav>

    <div class="container" style="margin-top: var(--spacing-xl);">
        <?php if (($showResult && $result) || ($previousResult && !isset($_GET['result']))): ?>
            <!-- Quiz Result / Already Taken View -->
            <?php
            $displayResult = $result ?: $previousResult;
            ?>
            <div class="card result-card">
                <?php if ($result): ?>
                    <h1>Quiz Completed! 🎉</h1>
                <?php else: ?>
                    <h1>Quiz Already Completed</h1>
                <?php endif; ?>

                <div class="result-score"><?php echo round($displayResult['percentage'], 1); ?>%</div>
                <h3>Score: <?php echo (int)$displayResult['score']; ?> / <?php echo $displayResult['total_points']; ?></h3>

                <?php if ($displayResult['percentage'] >= $quiz['pass_percentage']): ?>
                    <div class="alert alert-success mt-4">
                        <strong>Congratulations!</strong> You passed this quiz!
                    </div>
                <?php else: ?>
                    <div class="alert alert-warning mt-4">
                        <strong>Keep practicing!</strong> You need <?php echo $quiz['pass_percentage']; ?>% to pass.
                    </div>
                <?php endif; ?>

                <div class="mt-4">
                    <p><strong>Time Taken:</strong> <?php echo gmdate("i:s", $displayResult['time_taken']); ?></p>
                    <p><strong>Submitted:</strong> <?php echo formatDateTime($displayResult['submitted_at']); ?></p>
                </div>

                <div class="mt-4">
                    <a href="/LearnLift/student/lessons.php?id=<?php echo $quiz['lesson_id']; ?>"
                        class="btn btn-primary">Back to Lesson</a>
                    <a href="/LearnLift/student/dashboard.php" class="btn btn-outline">Dashboard</a>
                </div>
            </div>
        <?php else: ?>
            <!-- Quiz Taking Interface -->
            <div class="quiz-header">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <h1><?php echo htmlspecialchars($quiz['title']); ?></h1>
                        <p style="margin: 0; opacity: 0.9;">
                            Lesson: <?php echo htmlspecialchars($quiz['lesson_title']); ?>
                        </p>
                    </div>
                    <?php if ($quiz['time_limit'] > 0): ?>
                        <div class="timer" id="timer">
                            <?php echo $quiz['time_limit']; ?>:00
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <?php if ($quiz['description']): ?>
                <div class="alert alert-info">
                    <?php echo nl2br(htmlspecialchars($quiz['description'])); ?>
                </div>
            <?php endif; ?>

            <form method="POST" id="quiz-form" onsubmit="return submitQuiz(event)">
                <input type="hidden" name="submit_quiz" value="1">
                <input type="hidden" name="time_taken" id="time_taken" value="0">

                <?php foreach ($questions as $index => $question): ?>
                    <div class="card question-card">
                        <div class="card-body">
                            <div style="display: flex; align-items: flex-start;">
                                <span class="question-number"><?php echo $index + 1; ?></span>
                                <div style="flex: 1;">
                                    <h4><?php echo htmlspecialchars($question['question']); ?></h4>
                                    <p style="color: var(--gray); font-size: 0.875rem;">
                                        <?php echo $question['points']; ?> point<?php echo $question['points'] > 1 ? 's' : ''; ?>
                                    </p>

                                    <div class="mt-3">
                                        <label class="option-label">
                                            <input type="radio" name="answers[<?php echo $question['id']; ?>]"
                                                value="a" required>
                                            <span><strong>A.</strong> <?php echo htmlspecialchars($question['option_a']); ?></span>
                                        </label>

                                        <label class="option-label">
                                            <input type="radio" name="answers[<?php echo $question['id']; ?>]"
                                                value="b" required>
                                            <span><strong>B.</strong> <?php echo htmlspecialchars($question['option_b']); ?></span>
                                        </label>

                                        <?php if ($question['option_c']): ?>
                                            <label class="option-label">
                                                <input type="radio" name="answers[<?php echo $question['id']; ?>]"
                                                    value="c" required>
                                                <span><strong>C.</strong> <?php echo htmlspecialchars($question['option_c']); ?></span>
                                            </label>
                                        <?php endif; ?>

                                        <?php if ($question['option_d']): ?>
                                            <label class="option-label">
                                                <input type="radio" name="answers[<?php echo $question['id']; ?>]"
                                                    value="d" required>
                                                <span><strong>D.</strong> <?php echo htmlspecialchars($question['option_d']); ?></span>
                                            </label>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>

                <div class="card">
                    <div class="card-body text-center">
                        <button type="submit" class="btn btn-primary btn-lg">Submit Quiz</button>
                        <a href="/LearnLift/student/lessons.php?id=<?php echo $quiz['lesson_id']; ?>"
                            class="btn btn-outline btn-lg">Cancel</a>
                    </div>
                </div>
            </form>
        <?php endif; ?>
    </div>

    <script src="/LearnLift/assets/js/main.js"></script>
    <script src="/LearnLift/assets/js/offline.js"></script>
    <script>
        let startTime = Date.now();
        let timerInterval;

        <?php if ($quiz['time_limit'] > 0 && !$showResult): ?>
            // Timer countdown with persistence
            const quizId = <?php echo $quizId; ?>;
            const storageKey = `quiz_timer_end_${quizId}`;
            let endTime = localStorage.getItem(storageKey);

            if (!endTime) {
                // Initialize end time if not set
                const duration = <?php echo $quiz['time_limit'] * 60; ?>;
                endTime = Date.now() + (duration * 1000);
                localStorage.setItem(storageKey, endTime);
            } else {
                endTime = parseInt(endTime);
            }

            function updateTimer() {
                const now = Date.now();
                const timeLeft = Math.max(0, Math.floor((endTime - now) / 1000));

                const minutes = Math.floor(timeLeft / 60);
                const seconds = timeLeft % 60;

                const timerElement = document.getElementById('timer');
                if (timerElement) {
                    timerElement.textContent =
                        `${minutes}:${seconds.toString().padStart(2, '0')}`;
                }

                if (timeLeft <= 0) {
                    clearInterval(timerInterval);
                    localStorage.removeItem(storageKey);
                    alert('Time is up! Submitting quiz...');
                    document.getElementById('quiz-form').submit();
                }
            }

            updateTimer();
            timerInterval = setInterval(updateTimer, 1000);
        <?php endif; ?>

        function submitQuiz(event) {
            const timeTaken = Math.floor((Date.now() - startTime) / 1000);
            document.getElementById('time_taken').value = timeTaken;

            // Clear timer persistence on submission
            localStorage.removeItem(`quiz_timer_end_<?php echo $quizId; ?>`);

            // Check if online
            if (!navigator.onLine) {
                event.preventDefault();
                saveQuizOffline();
                return false;
            }

            return confirm('Are you sure you want to submit your quiz?');
        }

        async function saveQuizOffline() {
            const form = document.getElementById('quiz-form');
            const formData = new FormData(form);
            const answers = {};

            for (let [key, value] of formData.entries()) {
                if (key.startsWith('answers[')) {
                    const questionId = key.match(/\d+/)[0];
                    answers[questionId] = value;
                }
            }

            const timeTaken = Math.floor((Date.now() - startTime) / 1000);

            // Calculate score (simplified - you'd need question data)
            const score = 0;
            const totalPoints = <?php echo array_sum(array_column($questions, 'points')); ?>;
            const percentage = 0;

            try {
                await window.OfflineDB.saveQuizAnswersOffline(
                    <?php echo $quizId; ?>,
                    answers,
                    score,
                    totalPoints,
                    percentage,
                    timeTaken
                );

                // Clear timer persistence on offline save
                localStorage.removeItem(`quiz_timer_end_<?php echo $quizId; ?>`);

                window.LearnLift.showToast('Quiz saved offline! Will sync when online.', 'success');
                setTimeout(() => {
                    window.location.href = '/LearnLift/student/dashboard.php';
                }, 2000);
            } catch (error) {
                console.error('Failed to save offline:', error);
                alert('Failed to save quiz. Please try again.');
            }
        }
    </script>
</body>

</html>